import com.neomaverick.platformer.*

/**
 * Proof-of-fairness search: finds a button sequence that gets from a start x to the portal,
 * scoring progress and punishing lost hearts. The game is deterministic once the random
 * generator is seeded, so every candidate is replayed from the start.
 */
data class Mac(val bits: Int, val n: Int)
class Res(val x: Float, val hearts: Int, val dead: Boolean, val clear: Boolean, val frames: Int)

val MOVES = intArrayOf(1, 1, 1, 1 or 4, 1 or 4, 0, 2, 2 or 4, 4)

fun teleport(r: Rig, x: Float) {
    r.h.x = x; r.h.y = 0f
    while (!r.w.solidAt(Math.floorDiv(r.h.x.toInt(), 16), Math.floorDiv(r.h.y.toInt(), 16))) r.h.y += 16f
    r.h.y = Math.floorDiv(r.h.y.toInt(), 16) * 16f
    r.w.snapCamera()
}

var GOAL = 1e9f
var HEART_COST = 500f
/** When set, success = this many gems found, and progress = closeness to (TX, TY). */
var GEMS_NEEDED = 0
var TX = 0f
var TY = 0f

fun replay(seq: List<Mac>, startX: Float, shots: String? = null, setup: ((Rig) -> Unit)? = null): Res {
    Rnd.seed(7L)
    val r = Rig()
    r.startPlay()
    teleport(r, startX)
    setup?.invoke(r)
    var f = 0
    var shot = 0
    loop@ for (m in seq) {
        for (k in 0 until m.n) {
            r.key(KEY_RIGHT, m.bits and 1 != 0)
            r.key(KEY_LEFT, m.bits and 2 != 0)
            r.key(KEY_JUMP, m.bits and 4 != 0)
            r.step()
            f++
            if (shots != null && f % 30 == 0) { r.shot("%s_%03d".format(shots, shot)); shot++ }
            if (r.game.state != Game.PLAY || r.h.dead || r.w.clearing) break@loop
            if (GEMS_NEEDED == 0 && r.h.x >= GOAL && r.h.onGround) return Res(r.h.x, r.h.hearts, false, true, f)
            if (GEMS_NEEDED > 0 && r.game.gemsFound.size >= GEMS_NEEDED) return Res(r.h.x, r.h.hearts, false, true, f)
        }
    }
    val prog = if (GEMS_NEEDED > 0) 4000f - Math.hypot((r.h.x - TX).toDouble(), (r.h.y - 13f - TY).toDouble()).toFloat() else r.h.x
    return Res(prog, r.h.hearts, r.h.dead || r.game.state == Game.DYING, r.w.clearing, f)
}

fun score(res: Res, h0: Int) = res.x - HEART_COST * (h0 - res.hearts) - (if (res.dead) 1e5f else 0f) + (if (res.clear) 1e6f else 0f)

fun search(startX: Float, maxFrames: Int = 2400, setup: ((Rig) -> Unit)? = null): List<Mac>? {
    val rnd = java.util.Random(1)
    val seq = ArrayList<Mac>()
    var prefixHearts = 3
    var backtracks = 0
    while (true) {
        var best: List<Mac>? = null
        var bestS = -Float.MAX_VALUE
        var bestRes: Res? = null
        for (c in 0 until 48) {
            val cand = ArrayList(seq)
            repeat(5) { cand.add(Mac(MOVES[rnd.nextInt(MOVES.size)], 4 + rnd.nextInt(22))) }
            val res = replay(cand, startX, setup = setup)
            val s = score(res, 3)
            if (s > bestS) { bestS = s; best = cand; bestRes = res }
        }
        val b = bestRes!!
        if (b.clear && b.hearts >= prefixHearts) { println("\nsearch: CLEAR in ${b.frames} frames, hearts left ${b.hearts}, backtracks $backtracks"); return best }
        if (b.dead || b.hearts < prefixHearts) {
            // no candidate gets on without a hit: step back a little and try other moves
            backtracks++
            if (backtracks > 300) { println("\nsearch: gave up at x=${"%.0f".format(b.x)}"); return null }
            repeat(minOf(seq.size, 1 + rnd.nextInt(4))) { seq.removeAt(seq.size - 1) }
            continue
        }
        seq.add(best!![seq.size]); seq.add(best[seq.size])
        val total = seq.sumOf { it.n }
        print("\r  frames ${total}  best x=${"%.0f".format(b.x)} hearts=${b.hearts} backtracks=$backtracks   ")
        if (total > maxFrames) { println("\nsearch: too long, stopped at x=${"%.0f".format(b.x)}"); return null }
    }
}

fun searchMain(args: Array<String>) {
    val x = args.getOrNull(1)?.toFloat() ?: 2312f
    GOAL = args.getOrNull(2)?.toFloat() ?: 1e9f
    HEART_COST = args.getOrNull(3)?.toFloat() ?: 500f
    val tag = args.getOrNull(4) ?: "proof"
    val t0 = System.currentTimeMillis()
    val seq = search(x, maxFrames = 4000)
    println("took ${(System.currentTimeMillis() - t0) / 1000}s")
    if (seq != null) {
        val res = replay(seq, x, shots = tag)
        println("replay: clear=${res.clear} hearts=${res.hearts} frames=${res.frames}")
        println(seq.joinToString(" ") { "${it.bits}x${it.n}" })
    }
}

fun gemMain(args: Array<String>) {
    // gem <startX> <gemTileX> <gemTileY> <feather 0/1>
    val x = args[1].toFloat()
    TX = args[2].toInt() * 16 + 8f; TY = (args[3].toInt() + 1) * 16f - 8f
    val feather = args.getOrNull(4) == "1"
    GEMS_NEEDED = 1
    HEART_COST = 20000f
    val setup: (Rig) -> Unit = { r -> if (feather) r.h.hasFeather = true }
    val t0 = System.currentTimeMillis()
    val seq = search(x, maxFrames = 3000, setup = setup)
    println("took ${(System.currentTimeMillis() - t0) / 1000}s")
    if (seq != null) {
        val res = replay(seq, x, shots = "gem${args[2]}", setup = setup)
        println("gem replay: got=${res.clear} hearts=${res.hearts} frames=${res.frames}")
    }
}
