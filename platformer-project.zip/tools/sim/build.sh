#!/bin/bash
# compile the game against the drawing stubs, then the harness
cd /home/claude/platformer/sim
rm -rf appcls simcls && mkdir appcls simcls
java -cp "$(cat ../kc/cp)" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -jvm-target 17 -language-version 1.9 -api-version 1.9 -cp /opt/gradle/lib/kotlin-stdlib-2.0.21.jar:stubcls -d appcls ../src/app/src/main/java/com/neomaverick/platformer/*.kt 2>&1 | grep -E "error" | head -20
java -cp "$(cat ../kc/cp)" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -jvm-target 17 -cp /opt/gradle/lib/kotlin-stdlib-2.0.21.jar:stubcls:appcls -d simcls ${@:-PSim.kt} 2>&1 | grep -E "error" | head -20
echo built
