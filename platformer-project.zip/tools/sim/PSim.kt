import android.graphics.Bitmap
import android.graphics.Canvas
import com.neomaverick.platformer.*
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

val OUT = File("/home/claude/platformer/sim/frames")

fun save(img: BufferedImage, name: String, scale: Int = 2) {
    OUT.mkdirs()
    val o = BufferedImage(img.width * scale, img.height * scale, BufferedImage.TYPE_INT_RGB)
    val g = o.createGraphics()
    g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR)
    g.drawImage(img, 0, 0, o.width, o.height, null)
    g.dispose()
    ImageIO.write(o, "png", File(OUT, "$name.png"))
}

fun Any.fld(name: String): Any? {
    var c: Class<*>? = this.javaClass
    while (c != null) {
        try { val f = c.getDeclaredField(name); f.isAccessible = true; return f.get(this) } catch (e: NoSuchFieldException) { c = c.superclass }
    }
    error("no field $name")
}

class Rig(val vw: Int = 585, val vh: Int = 270) {
    val ctx = object : android.content.Context() {}
    val gfx = Gfx(ctx.resources)
    val audio = Audio(ctx)
    val input = Input()
    val game = Game(gfx, audio, ctx.getSharedPreferences("game", 0), input)
    val frame: Bitmap = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(frame)
    init { game.resize(vw, vh) }
    val w get() = game.world
    val h get() = game.world.hero
    fun step(n: Int = 1) { repeat(n) { game.update(STEP) } }
    fun shot(name: String, scale: Int = 2) { game.render(canvas); save(frame.img, name, scale) }
    fun key(k: Int, d: Boolean) = input.key(k, d)
    fun tap(x: Float = 300f, y: Float = 100f) { input.down(9, x, y); step(1); input.up(9) }
    fun startPlay() { step(30); tap(); step(70); check(game.state == Game.PLAY) { "not playing: ${game.state}" } }
}

fun measureJump(label: String, setup: (Rig) -> Unit, act: (Rig, Int) -> Unit, frames: Int = 120): FloatArray {
    val r = Rig()
    r.startPlay()
    r.w.enemies.clear()
    setup(r)
    r.step(5)
    val y0 = r.h.y
    val x0 = r.h.x
    var minY = y0
    var landX = x0
    var airFrames = 0
    var left = false
    for (f in 0 until frames) {
        act(r, f)
        r.step()
        if (r.h.y < minY) minY = r.h.y
        if (!r.h.onGround) { airFrames++; left = true } else if (left) { landX = r.h.x; break }
    }
    val res = floatArrayOf(y0 - minY, landX - x0, airFrames / 60f)
    println(String.format("%-28s height %6.1f px (%4.2f tiles)   distance %6.1f px   air %.2fs", label, res[0], res[0] / 16f, res[1], res[2]))
    return res
}

fun main(args: Array<String>) {
    val mode = args.firstOrNull() ?: "all"
    if (mode == "all" || mode == "shots") {
        val r = Rig()
        r.step(30)
        r.shot("01_title")
        r.tap()
        r.step(12)
        r.shot("02_iris")
        r.step(60)
        r.shot("03_start")
        r.key(KEY_RIGHT, true)
        r.step(50)
        r.shot("04_run")
        r.key(KEY_JUMP, true)
        r.step(14)
        r.shot("05_jump")
        r.key(KEY_JUMP, false)
        r.step(40)
        r.key(KEY_RIGHT, false)
        r.step(20)
        r.shot("06_after")
        println("hero at ${r.h.x}, ${r.h.y} ground=${r.h.onGround} state=${r.game.state}")
    }
    if (mode == "all" || mode == "physics") {
        measureJump("tap jump (standing)", {}, { r, f -> r.key(KEY_JUMP, f == 0) })
        measureJump("held jump (standing)", {}, { r, f -> r.key(KEY_JUMP, f < 60) })
        measureJump("running held jump", { r -> r.key(KEY_RIGHT, true); r.step(60) }, { r, f -> r.key(KEY_JUMP, f < 60) })
        measureJump("running tap jump", { r -> r.key(KEY_RIGHT, true); r.step(60) }, { r, f -> r.key(KEY_JUMP, f in 0..2) })
        measureJump("double jump (feather)", { r -> r.h.hasFeather = true }, { r, f -> r.key(KEY_JUMP, f < 20 || f in 30..70) })
    }
    if (mode == "debug") debugRun(args[1].toInt(), args[2].toInt())
    if (mode == "all" || mode == "auto") autoplay(180, if (args.size > 1) args[1].toInt() else 0)
    if (mode == "plat") platTest()
    if (mode == "search") searchMain(args)
    if (mode == "show") showcase()
    if (mode == "gem") gemMain(args)
    if (mode == "island") islandTest()
    if (mode == "map") {
        val r = Rig(3424, 384)
        r.step(30); r.tap(); r.step(80)
        r.w.camX = 0; r.w.camY = 0
        r.game.resize(3424, 384)
        r.w.camX = 0; r.w.camY = 0
        val bmp = android.graphics.Bitmap.createBitmap(3424, 384, android.graphics.Bitmap.Config.ARGB_8888)
        r.w.render(android.graphics.Canvas(bmp))
        val img = bmp.img
        for (k in 0 until 4) save(img.getSubimage(k * 856, 0, 856, 384), "map_%d".format(k), 1)
    }
    if (mode == "wide") {
        val r = Rig(624, 288)
        r.step(30); r.shot("wide_title")
        r.tap(); r.step(80)
        r.key(KEY_RIGHT, true); r.step(40); r.key(KEY_RIGHT, false); r.step(10)
        r.shot("wide_play")
        r.h.hasSun = true; r.step(2); r.shot("wide_fire")
    }
    if (mode == "speed") { val t0 = System.currentTimeMillis(); repeat(5) { replay(listOf(Mac(1, 600)), 2312f) }; println("5 replays of 600 frames: ${System.currentTimeMillis() - t0} ms") }
    if (mode == "gaunt") gauntTest(args.getOrNull(1)?.toFloat() ?: 2312f, args.getOrNull(2)?.toInt() ?: 0)
    if (mode == "god") autoplay(240, if (args.size > 1) args[1].toInt() else 0, true)
}

// ------------------------------------------------------------------ autopilot
class Pilot(val r: Rig, val godMode: Boolean = false) {
    var holdJump = 0
    var lastX = 0f
    var stuckT = 0
    var target: Platform? = null

    fun groundAt(px: Float, row: Int): Boolean {
        val w = r.w
        val tx = Math.floorDiv(px.toInt(), 16)
        return w.solidAt(tx, row) || w.oneWayAt(tx, row)
    }

    fun gapCheck(h: Hero): Boolean {
        val row = Math.floorDiv((h.y + 1f).toInt(), 16)
        return !groundAt(h.right + 5f, row) && !groundAt(h.right + 5f, row + 1)
    }

    /** Ground (tiles) within reach ahead, for a jump off a ledge or a platform. */
    fun groundAhead(h: Hero, row: Int, from: Int = 2, to: Int = 5) = (from..to).any { k -> (-3..2).any { dr -> groundAt(h.x + k * 16f + 8f, row + dr) } }

    fun step() {
        val h = r.h
        val w = r.w
        var right = true
        var left = false
        var jump = false
        val row = Math.floorDiv((h.y + 1f).toInt(), 16)
        if (h.onGround) {
            if (target != null && h.platform === target) target = null
            val gapAhead = gapCheck(h)
            val dropOk = gapAhead && h.platform == null && (2..9).any { dr -> groundAt(h.right + 8f, row + dr) }
            val wallAhead = (1..2).any { k -> w.solidAt(Math.floorDiv((h.right + 6f).toInt(), 16), row - k) }
            val enemy = w.enemies.firstOrNull { it.alive && it.active && kotlin.math.abs(it.y - h.y) < 30f &&
                (if (it.type == G.E_HEDGEHOG && it.dir > 0) it.x - h.x in 16f..40f else it.x - h.x in -4f..58f) }
            // spikes: jump at the last moment, and only when the far side is clear of hedgehogs
            var spikeTx = -1
            for (px in 0..40 step 2) { val tx = Math.floorDiv((h.right + px).toInt(), 16); if (w.tileAt(tx, row) == World.SPIKES) { spikeTx = tx; break } }
            var spikes = false
            var spikeWait = false
            if (spikeTx >= 0) {
                var end = spikeTx
                while (w.tileAt(end, row) == World.SPIKES) end++
                val endX = end * 16f
                val dist = spikeTx * 16f - h.right
                val blocked = w.enemies.any { it.alive && it.type == G.E_HEDGEHOG && it.x in endX - 10f..endX + 56f && kotlin.math.abs(it.y - h.y) < 20f }
                if (blocked) spikeWait = dist < 24f
                else if (dist <= 8f) spikes = true
            }
            val riding = h.platform
            if (riding != null) {
                // on a raft: wait for the next raft to come close, or for ground in reach
                val next = w.platforms.firstOrNull { it !== riding && it.x - h.x in 10f..70f && it.y in h.y - 40f..h.y + 40f && it.dx <= 0.3f }
                val ground = groundAhead(h, row, 2, 4)
                if (next != null) { jump = true; target = next }
                else if (ground && h.right > riding.x + riding.w - 10f) jump = true
                else { right = h.right < riding.x + riding.w - 8f }
            } else if (dropOk) {
                // step off
            } else if (gapAhead) {
                val plat = w.platforms.firstOrNull { it.x - h.x in 0f..60f && it.y in h.y - 50f..h.y + 30f && it.dx <= 0.3f }
                if (plat != null) { jump = true; target = plat }
                else if (groundAhead(h, row) && w.platforms.none { it.x - h.x in -40f..120f }) jump = true
                else right = false
            } else if (spikeWait) right = false
            else if (wallAhead || spikes || enemy != null) jump = true
            val flyer = w.enemies.firstOrNull { it.alive && it.type == G.E_HORNET && it.x - h.x in -12f..64f && h.y - it.y in 20f..110f }
            if (flyer != null && riding == null && !gapAhead) { right = false; jump = false }
        } else {
            // in the air: steer onto the target raft
            val t = target
            if (t != null) {
                val c = t.x + t.w / 2f + t.dx * 10f
                right = h.x < c - 6f
                left = h.x > c + 6f
            } else if (h.vy > 0f) {
                // falling toward spikes: steer to the nearer safe side
                fun landTile(px: Float): Int {
                    val tx = Math.floorDiv(px.toInt(), 16)
                    var ty = Math.floorDiv(h.y.toInt(), 16)
                    while (ty < w.rows && !w.solidAt(tx, ty) && !w.oneWayAt(tx, ty)) ty++
                    return if (ty < w.rows) w.tileAt(tx, ty) else -1
                }
                fun bad(off: Float) = landTile(h.left + 2f + off) == World.SPIKES || landTile(h.right - 2f + off) == World.SPIKES
                if (bad(h.vx * 0.1f) || bad(0f)) {
                    var dr = 0; while (dr < 80 && bad(dr.toFloat())) dr += 2
                    var dl = 0; while (dl < 80 && bad(-dl.toFloat())) dl += 2
                    right = dr <= dl; left = !right
                }
            }
        }
        if (godMode) h.invuln = 1f
        if (jump && holdJump == 0) holdJump = if (target != null) 16 else 30
        r.key(KEY_RIGHT, right)
        r.key(KEY_LEFT, left)
        if (holdJump > 0) { r.key(KEY_JUMP, true); holdJump--; if (holdJump == 0) r.key(KEY_JUMP, false) }
        if (r.h.hasSun && Rnd.chance(0.04f)) { r.key(KEY_FIRE, true); r.key(KEY_FIRE, false) }
        if (kotlin.math.abs(h.x - lastX) < 0.2f && right) stuckT++ else stuckT = 0
        lastX = h.x
        if (stuckT > 90) { holdJump = 22; stuckT = 0 }
    }
}

fun autoplay(seconds: Int, shotsEvery: Int, god: Boolean = false) {
    val r = Rig()
    r.startPlay()
    val p = Pilot(r, god)
    var deaths = 0
    var lastLives = r.game.lives
    var maxX = 0f
    var shot = 0
    for (f in 0 until seconds * 60) {
        if (r.game.state == Game.PLAY) p.step()
        r.step()
        if (r.game.lives != lastLives) { println("  life lost at frame $f, hero x=${"%.0f".format(r.h.x)} (tile ${(r.h.x / 16).toInt()}) lives=${r.game.lives}"); lastLives = r.game.lives; deaths++ }
        if (r.game.state == Game.DYING && r.game.stateT < STEP * 1.5f) { println("  died at x=${"%.0f".format(r.h.x)} y=${"%.0f".format(r.h.y)} tile ${(r.h.x / 16).toInt()},${(r.h.y / 16).toInt()} pit=${r.h.pitDeath}"); r.shot("death_%02d".format(deaths)) }
        if (r.h.x > maxX) maxX = r.h.x
        if (shotsEvery > 0 && f % shotsEvery == 0) { r.shot("auto_%03d".format(shot)); shot++ }
        if (r.game.state == Game.CLEAR && r.game.stateT > 5f) { r.shot("auto_clear"); break }
        if (r.game.state == Game.GAMEOVER) { r.shot("auto_gameover"); break }
    }
    println("autoplay: state=${r.game.state} maxX=${"%.0f".format(maxX)} (tile ${(maxX / 16).toInt()} of ${r.w.cols}) time=${"%.1f".format(r.game.runTime)} coins=${r.game.coins} score=${r.game.score} deaths=$deaths gems=${r.game.gemsFound.size}")
}

fun debugRun(seconds: Int, every: Int) {
    val r = Rig()
    r.startPlay()
    val p = Pilot(r)
    for (f in 0 until seconds * 60) {
        if (r.game.state == Game.PLAY) p.step()
        r.step()
        if (f % every == 0) println("f=$f x=${"%.1f".format(r.h.x)} y=${"%.1f".format(r.h.y)} vx=${"%.0f".format(r.h.vx)} vy=${"%.0f".format(r.h.vy)} gnd=${r.h.onGround} right=${r.input.right} jumpHeld=${r.input.jumpHeld} hold=${p.holdJump} hearts=${r.h.hearts} state=${r.game.state}")
    }
    r.shot("debug_end")
}

fun platTest() {
    val r = Rig()
    r.startPlay()
    r.w.enemies.clear()
    r.h.x = 1900f; r.h.y = 256f
    r.w.snapCamera()
    val p = Pilot(r)
    for (f in 0 until 900) {
        if (r.game.state == Game.PLAY) p.step()
        r.step()
        val pl = r.w.platforms
        if (f % 6 == 0) println("f=$f hero x=${"%.0f".format(r.h.x)} y=${"%.0f".format(r.h.y)} gnd=${r.h.onGround} onPlat=${pl.indexOf(r.h.platform)} R=${r.input.right} J=${r.input.jumpHeld} | M1 x=${"%.0f".format(pl[0].x)} dx=${"%.2f".format(pl[0].dx)} | M2 x=${"%.0f".format(pl[1].x)} dx=${"%.2f".format(pl[1].dx)} | V y=${"%.0f".format(pl[2].y)} state=${r.game.state}")
        if (r.game.state != Game.PLAY) break
        if (f % 30 == 0) r.shot("plat_%03d".format(f / 30))
    }
}

fun gauntTest(startX: Float, shotsEvery: Int) {
    val r = Rig()
    r.startPlay()
    r.h.x = startX; r.h.y = 256f
    while (!r.w.solidAt(Math.floorDiv(r.h.x.toInt(), 16), Math.floorDiv(r.h.y.toInt(), 16))) r.h.y += 16f
    r.h.y = Math.floorDiv(r.h.y.toInt(), 16) * 16f
    while (r.w.solidAt(Math.floorDiv(r.h.x.toInt(), 16), Math.floorDiv(r.h.y.toInt() - 1, 16))) r.h.y -= 16f
    r.w.snapCamera()
    val p = Pilot(r)
    var hearts = r.h.hearts
    for (f in 0 until 60 * 40) {
        if (r.game.state == Game.PLAY) p.step()
        r.step()
        val h = r.h
        if (h.hearts != hearts || (r.game.state == Game.DYING && r.game.stateT < STEP * 1.5f)) {
            val near = r.w.enemies.filter { it.alive && kotlin.math.abs(it.x - h.x) < 60f }.joinToString { "${it.type}@(${"%.0f".format(it.x)},${"%.0f".format(it.y)}) vy=${"%.0f".format(it.vy)} gnd=${it.onGround}" }
            println("f=$f hearts ${hearts}->${h.hearts} hero (${"%.1f".format(h.x)},${"%.1f".format(h.y)}) v=(${"%.0f".format(h.vx)},${"%.0f".format(h.vy)}) gnd=${h.onGround} spikes=${r.w.spikesUnder(h)} near: $near")
            r.shot("gaunt_hit_%04d".format(f))
            hearts = h.hearts
        }
        if (shotsEvery > 0 && f % shotsEvery == 0) r.shot("gaunt_%04d".format(f))
        if (System.getenv("TRACE") != null) { val a = System.getenv("TRACE").split("-"); if (f in a[0].toInt()..a[1].toInt()) println("  f=$f x=${"%.1f".format(h.x)} y=${"%.1f".format(h.y)} vx=${"%.0f".format(h.vx)} vy=${"%.0f".format(h.vy)} gnd=${h.onGround} R=${r.input.right} L=${r.input.left} J=${r.input.jumpHeld} knock=${"%.2f".format(h.knockT)} | " + r.w.enemies.filter { it.alive && kotlin.math.abs(it.x - h.x) < 80f }.joinToString { "${it.type}@${"%.0f".format(it.x)},${"%.0f".format(it.y)}" }) }
        if (r.game.state != Game.PLAY) { println("state ${r.game.state} at f=$f x=${"%.0f".format(h.x)}"); if (r.game.state == Game.CLEAR) { r.step(400); r.shot("gaunt_clear") }; break }
    }
}

fun showcase() {
    // a. all powers + throwing sun orbs at a beetle
    run {
        val r = Rig(); r.startPlay()
        teleport(r, 330f)
        r.h.hasFeather = true; r.h.hasSun = true; r.h.shield = true
        r.input.fireEnabled = true
        r.step(20)
        r.key(KEY_FIRE, true); r.step(1); r.key(KEY_FIRE, false); r.step(8)
        r.shot("show_a_orbs")
        r.step(6); r.key(KEY_FIRE, true); r.step(1); r.key(KEY_FIRE, false); r.step(10)
        r.shot("show_a_orbs2")
        // double jump
        r.key(KEY_JUMP, true); r.step(16); r.key(KEY_JUMP, false); r.step(2); r.key(KEY_JUMP, true); r.step(4)
        r.shot("show_b_djump")
        r.key(KEY_JUMP, false)
    }
    // c. star power
    run {
        val r = Rig(); r.startPlay()
        teleport(r, 600f)
        r.h.starT = 8f
        r.key(KEY_RIGHT, true); r.step(40)
        r.shot("show_c_star")
        r.step(3)
        r.shot("show_c_star2")
    }
    // d. secret cave inside the hill
    run {
        val r = Rig(); r.startPlay()
        r.h.x = 1700f; r.h.y = 256f; r.w.snapCamera()
        r.key(KEY_LEFT, true); r.step(30); r.key(KEY_LEFT, false); r.step(30)
        r.shot("show_d_cave")
        println("cave hero at ${r.h.x},${r.h.y} fakeAlpha=${r.w.fakeAlpha}")
    }
    // e. cloud island
    run {
        val r = Rig(); r.startPlay()
        r.h.x = 2350f; r.h.y = 96f; r.w.snapCamera()
        r.step(30)
        r.shot("show_e_island")
    }
    // f. spring launch from the ground
    run {
        val r = Rig(); r.startPlay()
        teleport(r, 2470f)
        r.w.enemies.clear()
        r.key(KEY_RIGHT, true); r.step(30)
        r.shot("show_f_spring0")
        r.step(14)
        r.shot("show_f_spring1")
        r.key(KEY_RIGHT, false); r.step(30)
        r.shot("show_f_spring2")
        println("after spring hero at ${r.h.x},${r.h.y} gnd=${r.h.onGround}")
    }
    // g. pause menu, then death and game over
    run {
        val r = Rig(); r.startPlay()
        r.key(KEY_PAUSE, true); r.step(1); r.key(KEY_PAUSE, false); r.step(10)
        r.shot("show_g_pause")
        r.key(KEY_PAUSE, true); r.step(1); r.key(KEY_PAUSE, false); r.step(5)
        r.game.lives = 1
        r.w.killHero(false)
        r.step(30); r.shot("show_h_die")
        r.step(260); r.shot("show_i_gameover")
        println("state after death: ${r.game.state}")
    }
}

fun islandTest() {
    val r = Rig(); r.startPlay()
    r.h.x = 2470f; r.h.y = 256f; r.w.snapCamera()
    r.w.enemies.clear()
    r.key(KEY_RIGHT, true)
    var f = 0
    while (r.h.onGround && f < 120) { r.step(); f++ }
    r.key(KEY_RIGHT, false)
    println("launched at f=$f x=${r.h.x} vy=${r.h.vy}")
    // rise straight up, then drift left onto the island
    while (r.h.vy < -60f) { r.step(); f++ }
    println("near apex x=${r.h.x} y=${r.h.y}")
    r.key(KEY_LEFT, true)
    while (!r.h.onGround && f < 600) { r.step(); f++ }
    println("landed x=${r.h.x} y=${r.h.y}")
    while (r.game.gemsFound.isEmpty() && f < 900) { r.step(); f++ }
    r.key(KEY_LEFT, false)
    println("gems=${r.game.gemsFound.size} at f=$f x=${r.h.x} y=${r.h.y}")
    // and the star block above
    r.step(10)
    r.h.x = 147 * 16 + 8f; r.step(5)
    r.key(KEY_JUMP, true); r.step(20); r.key(KEY_JUMP, false); r.step(40)
    r.shot("island_star")
    println("items: " + r.w.items.filter { it.kind == Item.STAR }.joinToString { "star@${it.x},${it.y}" } + " starT=${r.h.starT}")
}
