package android.media;
import android.content.Context;
public class SoundPool {
  public static final java.util.List<Integer> played = new java.util.ArrayList<>();
  public interface OnLoadCompleteListener { void onLoadComplete(SoundPool p, int id, int status); }
  public static class Builder { public Builder setMaxStreams(int n) { return this; } public Builder setAudioAttributes(AudioAttributes a) { return this; } public SoundPool build() { return new SoundPool(); } }
  private OnLoadCompleteListener l; private int next = 1; private final java.util.Map<Integer, Integer> res = new java.util.HashMap<>();
  public void setOnLoadCompleteListener(OnLoadCompleteListener l) { this.l = l; }
  public int load(Context c, int r, int pri) { int id = next++; res.put(id, r); if (l != null) l.onLoadComplete(this, id, 0); return id; }
  public int play(int id, float lv, float rv, int pri, int loop, float rate) { played.add(res.get(id)); return id; }
  public void release() {} public final void autoPause() {} public final void autoResume() {}
}
