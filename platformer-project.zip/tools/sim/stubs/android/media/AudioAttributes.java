
package android.media;
public final class AudioAttributes { public static final int USAGE_MEDIA = 1, USAGE_ALARM = 4, CONTENT_TYPE_MUSIC = 2, USAGE_GAME = 14, CONTENT_TYPE_SONIFICATION = 4;
  public static class Builder { public Builder setUsage(int u) { return this; } public Builder setContentType(int c) { return this; } public AudioAttributes build() { return new AudioAttributes(); } } }
