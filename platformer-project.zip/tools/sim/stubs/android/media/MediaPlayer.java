package android.media;
import android.content.Context; import android.net.Uri;
public class MediaPlayer { public static int lastRes = 0; public static MediaPlayer create(Context c, int resid) { lastRes = resid; return new MediaPlayer(); }
  public void setAudioAttributes(AudioAttributes a) {} public void setDataSource(Context c, Uri u) {}
  boolean loop; public void setLooping(boolean l) { loop = l; } public boolean isLooping() { return loop; }
  public void prepare() {} public void setVolume(float l, float r) {} public void start() {} public void pause() {} public void stop() {} public void release() {} }
