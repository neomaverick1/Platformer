package android.content.res;
import android.util.DisplayMetrics;
public class Resources {
  final DisplayMetrics dm = new DisplayMetrics();
  { dm.density = 2.625f; dm.widthPixels = 1080; dm.heightPixels = 2340; }
  public DisplayMetrics getDisplayMetrics() { return dm; }
  /** Finds the res/font file whose generated R id matches. */
  public android.graphics.Typeface getFont(int id) {
    try {
      for (java.lang.reflect.Field f : Class.forName("com.rise.alarm.R$font").getFields()) {
        if (f.getInt(null) == id) {
          for (String ext : new String[]{".ttf", ".otf"}) {
            java.io.File file = new java.io.File("/home/claude/rise/src/app/src/main/res/font/" + f.getName() + ext);
            if (file.exists()) return android.graphics.Typeface.fromFile(file);
          }
        }
      }
    } catch (Exception e) { System.err.println("getFont: " + e); }
    return android.graphics.Typeface.DEFAULT;
  }
  public int getIdentifier(String n, String t, String p) { return 0; }
  public int getDimensionPixelSize(int id) { return 0; }
}
