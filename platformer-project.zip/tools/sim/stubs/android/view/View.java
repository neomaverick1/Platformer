
package android.view;
import android.content.Context; import android.content.res.Resources; import android.graphics.Canvas;
import android.graphics.drawable.Drawable; import android.util.AttributeSet;
public class View { public void setElevation(float e) {} public float getElevation() { return 0; } public void setCameraDistance(float d) {} public float getCameraDistance() { return 0; } public void setPivotY(float p) {} public float getPivotY() { return 0; } public void setPivotX(float p) {} public float getPivotX() { return 0; } public void setRotationX(float r) {} public float getRotationX() { return 0; } public void setRotationY(float r) {} public float getRotationY() { return 0; } public void getLocationInWindow(int[] o) {} public static final int IMPORTANT_FOR_ACCESSIBILITY_NO = 2; public void setImportantForAccessibility(int m) {} public int getImportantForAccessibility() { return 0; } public int getPaddingLeft() { return 0; } public int getPaddingTop() { return 0; } public int getPaddingRight() { return 0; } public int getPaddingBottom() { return 0; }
  public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;
  public static final int SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096, SYSTEM_UI_FLAG_FULLSCREEN = 4, SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2,
    SYSTEM_UI_FLAG_LAYOUT_STABLE = 256, SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512, SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024;
  @Deprecated public void setSystemUiVisibility(int v) {} @Deprecated public int getSystemUiVisibility() { return 0; }
  public void setFocusableInTouchMode(boolean b) {} public final boolean isFocusableInTouchMode() { return false; }
  public void setKeepScreenOn(boolean b) {} public boolean getKeepScreenOn() { return false; }
  Context ctx_; public View(Context c) { ctx_ = c; } public View(Context c, AttributeSet a) { ctx_ = c; } public View(Context c, AttributeSet a, int s) { ctx_ = c; }
  public interface OnClickListener { void onClick(View v); }
  public interface OnLongClickListener { boolean onLongClick(View v); }
  public interface OnTouchListener { boolean onTouch(View v, MotionEvent e); }
  public void setOnClickListener(OnClickListener l) {} public void setOnLongClickListener(OnLongClickListener l) {}
  public void setOnTouchListener(OnTouchListener l) {}
  public void setLongClickable(boolean b) {} public boolean isLongClickable() { return true; }
  public interface OnAttachStateChangeListener { void onViewAttachedToWindow(View v); void onViewDetachedFromWindow(View v); }
  public void addOnAttachStateChangeListener(OnAttachStateChangeListener l) {}
  public boolean performClick() { return true; }
  public boolean performHapticFeedback(int c) { return true; }
  public ViewPropertyAnimator animate() { return null; }
  public boolean isShown() { return true; } public boolean canScrollVertically(int d) { return false; }
  public interface OnScrollChangeListener { void onScrollChange(View v, int x, int y, int ox, int oy); }
  public void setOnScrollChangeListener(OnScrollChangeListener l) {}
  public ViewTreeObserver getViewTreeObserver() { return null; }
  public void setVisibility(int v) {} public int getVisibility() { return 0; }
  public void setAlpha(float a) {} public float getAlpha() { return 0; }
  public void setScaleX(float a) {} public float getScaleX() { return 0; }
  public void setScaleY(float a) {} public float getScaleY() { return 0; }
  public void setRotation(float a) {} public float getRotation() { return 0; }
  public void setTranslationX(float a) {} public float getTranslationX() { return 0; }
  public void setTranslationY(float a) {} public float getTranslationY() { return 0; }
  public void setBackground(Drawable d) {} public Drawable getBackground() { return null; }
  public void setPadding(int l, int t, int r, int b) {}
  public void setBackgroundColor(int c) {}
  public void setLayoutParams(ViewGroup.LayoutParams p) {} public ViewGroup.LayoutParams getLayoutParams() { return null; }
  public boolean post(Runnable r) { return true; } public boolean postDelayed(Runnable r, long d) { return true; }
  public boolean removeCallbacks(Runnable r) { return true; }
  public void invalidate() {} public static int generateViewId() { return 1; } public int getId() { return 0; } public void setId(int id) {} public Object getTag() { return null; } public void setTag(Object o) {} public Object getTag(int k) { return null; } public void setTag(int k, Object o) {}
  public void getLocationOnScreen(int[] l) {} public View getRootView() { return null; } public void requestLayout() {} public void postInvalidateOnAnimation() {} public void setWillNotDraw(boolean b) {}
  public static final int LAYER_TYPE_HARDWARE = 2; public void setLayerType(int t, android.graphics.Paint p) {}
  public android.view.ViewParent getParent() { return null; } public android.view.animation.Animation getAnimation() { return null; } int w_, h_; public final int getWidth() { return w_; } public final int getHeight() { return h_; } public void simLayout(int w, int h) { w_ = w; h_ = h; onSizeChanged(w, h, 0, 0); } public void simDraw(android.graphics.Canvas c) { onDraw(c); }
  public Resources getResources() { return ctx_.getResources(); } public final Context getContext() { return ctx_; }
  public void setContentDescription(CharSequence c) {} public CharSequence getContentDescription() { return null; }
  public void setClickable(boolean b) {} public boolean isClickable() { return false; }
  public void setFocusable(boolean b) {} public final boolean isFocusable() { return false; }
  public void setEnabled(boolean b) {} public boolean isEnabled() { return true; }
  public final <T extends View> T findViewById(int id) { return null; }
  public boolean requestFocus() { return true; } public void clearFocus() {}
  protected void onDraw(Canvas c) {} protected void onSizeChanged(int w, int h, int ow, int oh) {} public boolean isAttachedToWindow() { return true; } public void setVerticalScrollBarEnabled(boolean b) {} public boolean isVerticalScrollBarEnabled() { return false; }
  public boolean onTouchEvent(MotionEvent e) { return false; }
  protected void onMeasure(int w, int h) {} protected final void setMeasuredDimension(int w, int h) {} protected void onAttachedToWindow() {} protected void onDetachedFromWindow() {}
}
