package android.graphics;

/** Real Android colour maths (HSV conversion matches Skia, including its hue rules). */
public class Color {
  public static final int BLACK = 0xFF000000, DKGRAY = 0xFF444444, GRAY = 0xFF888888, LTGRAY = 0xFFCCCCCC, WHITE = 0xFFFFFFFF,
      RED = 0xFFFF0000, GREEN = 0xFF00FF00, BLUE = 0xFF0000FF, YELLOW = 0xFFFFFF00, CYAN = 0xFF00FFFF, MAGENTA = 0xFFFF00FF, TRANSPARENT = 0;
  public static int hueOutOfRange = 0;

  public static int alpha(int c) { return c >>> 24; }
  public static int red(int c) { return (c >> 16) & 0xFF; }
  public static int green(int c) { return (c >> 8) & 0xFF; }
  public static int blue(int c) { return c & 0xFF; }
  public static int rgb(int r, int g, int b) { return 0xFF000000 | (r << 16) | (g << 8) | b; }
  public static int argb(int a, int r, int g, int b) { return (a << 24) | (r << 16) | (g << 8) | b; }

  public static void colorToHSV(int c, float[] hsv) {
    float r = red(c) / 255f, g = green(c) / 255f, b = blue(c) / 255f;
    float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
    float h = 0f;
    if (d > 0f) {
      if (max == r) h = 60f * (((g - b) / d) % 6f);
      else if (max == g) h = 60f * (((b - r) / d) + 2f);
      else h = 60f * (((r - g) / d) + 4f);
      if (h < 0f) h += 360f;
    }
    hsv[0] = h; hsv[1] = max == 0f ? 0f : d / max; hsv[2] = max;
  }

  public static int HSVToColor(float[] hsv) { return HSVToColor(0xFF, hsv); }

  public static int HSVToColor(int alpha, float[] hsv) {
    if (Float.isNaN(hsv[0]) || Float.isNaN(hsv[1]) || Float.isNaN(hsv[2])) throw new IllegalArgumentException("NaN color");
    float s = Math.max(0f, Math.min(1f, hsv[1])), v = Math.max(0f, Math.min(1f, hsv[2]));
    int vb = Math.round(v * 255f);
    if (s <= 0f) return (alpha << 24) | (vb << 16) | (vb << 8) | vb;
    if (hsv[0] < 0f || hsv[0] >= 360f) hueOutOfRange++;
    float hx = (hsv[0] < 0f || hsv[0] >= 360f) ? 0f : hsv[0] / 60f;   // Skia: out-of-range hue becomes red
    float w = (float) Math.floor(hx), f = hx - w;
    int p = Math.round((1f - s) * v * 255f), q = Math.round((1f - s * f) * v * 255f), t = Math.round((1f - s * (1f - f)) * v * 255f);
    int r, g, b;
    switch ((int) w) {
      case 0: r = vb; g = t; b = p; break;
      case 1: r = q; g = vb; b = p; break;
      case 2: r = p; g = vb; b = t; break;
      case 3: r = p; g = q; b = vb; break;
      case 4: r = t; g = p; b = vb; break;
      default: r = vb; g = p; b = q; break;
    }
    return (alpha << 24) | (r << 16) | (g << 8) | b;
  }

  public static int parseColor(String s) {
    if (s.startsWith("#")) {
      long v = Long.parseLong(s.substring(1), 16);
      if (s.length() == 7) v |= 0xFF000000L;
      else if (s.length() != 9) throw new IllegalArgumentException("Unknown color");
      return (int) v;
    }
    switch (s.toLowerCase()) {
      case "black": return BLACK; case "white": return WHITE; case "red": return RED; case "green": return GREEN;
      case "blue": return BLUE; case "yellow": return YELLOW; case "cyan": return CYAN; case "magenta": return MAGENTA;
      case "gray": case "grey": return GRAY; case "transparent": return TRANSPARENT;
    }
    throw new IllegalArgumentException("Unknown color");
  }

  static double lin(int c) { double v = c / 255.0; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
  public static float luminance(int c) { return (float) (0.2126 * lin(red(c)) + 0.7152 * lin(green(c)) + 0.0722 * lin(blue(c))); }
}
