package android.graphics;
import java.awt.geom.AffineTransform;
import java.awt.MultipleGradientPaint;
public class Shader {
  public enum TileMode { CLAMP, REPEAT, MIRROR }
  protected AffineTransform local = new AffineTransform();
  public void setLocalMatrix(Matrix m) { local = m == null ? new AffineTransform() : new AffineTransform(m.tx); }
  /** The java.awt paint for this shader (user space). */
  public java.awt.Paint awt() { return new java.awt.Color(0, 0, 0, 0); }

  static MultipleGradientPaint.CycleMethod cyc(TileMode m) {
    return m == TileMode.REPEAT ? MultipleGradientPaint.CycleMethod.REPEAT : m == TileMode.MIRROR ? MultipleGradientPaint.CycleMethod.REFLECT : MultipleGradientPaint.CycleMethod.NO_CYCLE;
  }
  static void check(int[] c, float[] p) {
    if (c == null || c.length < 2) throw new IllegalArgumentException("needs >= 2 number of colors");
    if (p != null && c.length != p.length) throw new IllegalArgumentException("color and position arrays must be of equal length");
  }
  /** Android allows repeated stops; java.awt needs strictly increasing fractions in [0,1]. */
  static float[] fracs(int n, float[] p) {
    float[] f = new float[n];
    for (int i = 0; i < n; i++) f[i] = p == null ? i / (float) (n - 1) : Math.max(0f, Math.min(1f, p[i]));
    final float e = 1e-4f;
    for (int i = 1; i < n; i++) if (f[i] <= f[i - 1]) f[i] = f[i - 1] + e;
    if (f[n - 1] > 1f) { f[n - 1] = 1f; for (int i = n - 2; i >= 0; i--) if (f[i] >= f[i + 1]) f[i] = f[i + 1] - e; }
    return f;
  }
  static java.awt.Color[] cols(int[] c) { java.awt.Color[] o = new java.awt.Color[c.length]; for (int i = 0; i < c.length; i++) o[i] = new java.awt.Color(c[i], true); return o; }
}
