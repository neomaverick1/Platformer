package android.graphics;
public class DashPathEffect extends PathEffect { public final float[] intervals; public final float phase; public DashPathEffect(float[] i, float p) { if (i.length < 2) throw new ArrayIndexOutOfBoundsException(); intervals = i.clone(); phase = p; } }
