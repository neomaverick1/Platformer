package android.graphics;
import java.awt.geom.Point2D;
import java.awt.RadialGradientPaint;
import java.awt.MultipleGradientPaint;
public class RadialGradient extends Shader {
  final float x, y, r; final int[] c; final float[] s; final TileMode m;
  public RadialGradient(float x, float y, float r, int[] c, float[] s, Shader.TileMode m) {
    if (r <= 0f || Float.isNaN(r)) throw new IllegalArgumentException("ending radius must be > 0");
    check(c, s); this.x = x; this.y = y; this.r = r; this.c = c.clone(); this.s = s == null ? null : s.clone(); this.m = m;
  }
  public RadialGradient(float x, float y, float r, int c0, int c1, Shader.TileMode m) { this(x, y, r, new int[]{c0, c1}, null, m); }
  public java.awt.Paint awt() {
    Point2D.Float ctr = new Point2D.Float(x, y);
    return new RadialGradientPaint(ctr, r, ctr, fracs(c.length, s), cols(c), cyc(m), MultipleGradientPaint.ColorSpaceType.SRGB, local);
  }
}
