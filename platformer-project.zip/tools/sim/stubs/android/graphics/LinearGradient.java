package android.graphics;
import java.awt.geom.Point2D;
import java.awt.LinearGradientPaint;
import java.awt.MultipleGradientPaint;
public class LinearGradient extends Shader {
  final float x0, y0, x1, y1; final int[] c; final float[] p; final TileMode m;
  public LinearGradient(float x0, float y0, float x1, float y1, int[] c, float[] p, Shader.TileMode m) {
    check(c, p); this.x0 = x0; this.y0 = y0; this.x1 = x1; this.y1 = y1; this.c = c.clone(); this.p = p == null ? null : p.clone(); this.m = m;
  }
  public LinearGradient(float x0, float y0, float x1, float y1, int c0, int c1, Shader.TileMode m) { this(x0, y0, x1, y1, new int[]{c0, c1}, null, m); }
  public java.awt.Paint awt() {
    float ex = x1, ey = y1;
    if (ex == x0 && ey == y0) ex += 0.01f;
    return new LinearGradientPaint(new Point2D.Float(x0, y0), new Point2D.Float(ex, ey), fracs(c.length, p), cols(c), cyc(m),
        MultipleGradientPaint.ColorSpaceType.SRGB, local);
  }
}
