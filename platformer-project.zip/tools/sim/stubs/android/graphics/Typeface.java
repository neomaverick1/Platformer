package android.graphics;

import java.awt.Font;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/** Desktop stand-in: a family name + style that resolves to a real font file. */
public class Typeface {
  public static final int NORMAL = 0, BOLD = 1, ITALIC = 2, BOLD_ITALIC = 3;
  static final String INTER = "/usr/share/fonts/opentype/inter/";
  static final Map<String, Font> FILES = new HashMap<>();

  public final String family;
  public final int style;
  final File file;          // a font resource (res/font), or null for a system family

  public Typeface() { this("sans-serif", NORMAL, null); }
  Typeface(String family, int style, File file) { this.family = family; this.style = style; this.file = file; }

  public static final Typeface DEFAULT = new Typeface("sans-serif", NORMAL, null);
  public static final Typeface DEFAULT_BOLD = new Typeface("sans-serif", BOLD, null);
  public static final Typeface SANS_SERIF = new Typeface("sans-serif", NORMAL, null);
  public static final Typeface SERIF = new Typeface("serif", NORMAL, null);
  public static final Typeface MONOSPACE = new Typeface("monospace", NORMAL, null);

  public int getStyle() { return style; }
  public static Typeface create(String f, int s) { return new Typeface(f == null ? "sans-serif" : f, s, null); }
  public static Typeface create(Typeface f, int s) { if (f == null) f = DEFAULT; return new Typeface(f.family, s, f.file); }
  public static Typeface fromFile(File f) { return new Typeface(f.getName(), NORMAL, f); }

  static Font load(String path) {
    return FILES.computeIfAbsent(path, p -> {
      try { return Font.createFont(p.endsWith(".pfb") ? Font.TYPE1_FONT : Font.TRUETYPE_FONT, new File(p)); }
      catch (Exception e) { System.err.println("font " + p + ": " + e); return new Font("SansSerif", Font.PLAIN, 1); }
    });
  }

  /** The java.awt font for this typeface at [size] px. */
  public Font awt(float size) {
    boolean bold = (style & BOLD) != 0, italic = (style & ITALIC) != 0;
    Font base;
    int synth = Font.PLAIN;
    if (file != null) {
      base = load(file.getPath());
      if (bold) synth |= Font.BOLD;
      if (italic) synth |= Font.ITALIC;
    } else {
      String w;
      switch (family) {
        case "sans-serif-black": w = italic ? "Inter-BlackItalic" : "Inter-Black"; break;
        case "sans-serif-medium": w = bold ? "Inter-Bold" : "Inter-Medium"; break;
        case "sans-serif-light": w = bold ? "Inter-SemiBold" : "Inter-Light"; break;
        case "sans-serif-thin": w = bold ? "Inter-Medium" : "Inter-Thin"; break;
        case "serif": base = load("/home/claude/rise/src/app/src/main/res/font/liberation_serif.ttf"); w = null; if (bold) synth |= Font.BOLD; if (italic) synth |= Font.ITALIC; return base.deriveFont(synth, size);
        case "monospace": base = load("/home/claude/rise/src/app/src/main/res/font/liberation_mono.ttf"); w = null; if (bold) synth |= Font.BOLD; if (italic) synth |= Font.ITALIC; return base.deriveFont(synth, size);
        default: w = bold ? (italic ? "Inter-BoldItalic" : "Inter-Bold") : (italic ? "Inter-Italic" : "Inter-Regular");
      }
      base = load(INTER + w + ".otf");
    }
    return base.deriveFont(synth, size);
  }

  public String toString() { return "Typeface(" + family + "," + style + ")"; }
}
