package android.graphics;
import java.awt.geom.AffineTransform;
public class Matrix {
  public final AffineTransform tx = new AffineTransform();
  public void reset() { tx.setToIdentity(); }
  public void setRotate(float d, float px, float py) { tx.setToRotation(Math.toRadians(d), px, py); }
  public void setRotate(float d) { tx.setToRotation(Math.toRadians(d)); }
  public void setTranslate(float x, float y) { tx.setToTranslation(x, y); }
  public void setScale(float sx, float sy) { tx.setToScale(sx, sy); }
  public boolean postTranslate(float x, float y) { AffineTransform t = AffineTransform.getTranslateInstance(x, y); t.concatenate(tx); tx.setTransform(t); return true; }
  public boolean postRotate(float d, float px, float py) { AffineTransform t = AffineTransform.getRotateInstance(Math.toRadians(d), px, py); t.concatenate(tx); tx.setTransform(t); return true; }
  public boolean preRotate(float d, float px, float py) { tx.rotate(Math.toRadians(d), px, py); return true; }
}
