package android.graphics;
import java.awt.image.BufferedImage;
import java.io.File;
/** Loads res/drawable-nodpi PNGs by looking the id up in the generated R class. */
public class BitmapFactory {
  public static class Options { public boolean inScaled = true; public Bitmap.Config inPreferredConfig; }
  public static int decoded = 0;
  public static Bitmap decodeResource(android.content.res.Resources r, int id, Options o) {
    try {
      for (java.lang.reflect.Field f : Class.forName("com.neomaverick.platformer.R$drawable").getFields()) {
        if (f.getInt(null) == id) {
          File file = new File("/home/claude/platformer/src/app/src/main/res/drawable-nodpi/" + f.getName() + ".png");
          BufferedImage src = javax.imageio.ImageIO.read(file);
          BufferedImage img = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB_PRE);
          img.createGraphics().drawImage(src, 0, 0, null);
          decoded++;
          return new Bitmap(img);
        }
      }
    } catch (Exception e) { throw new RuntimeException(e); }
    return null;
  }
  public static Bitmap decodeResource(android.content.res.Resources r, int id) { return decodeResource(r, id, null); }
}
