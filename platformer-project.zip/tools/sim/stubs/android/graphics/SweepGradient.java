package android.graphics;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
/** Angle gradient around (x, y), clockwise from 3 o'clock like Android. */
public class SweepGradient extends Shader {
  final float x, y; final int[] c; final float[] f;
  public SweepGradient(float x, float y, int[] c, float[] p) { check(c, p); this.x = x; this.y = y; this.c = c.clone(); this.f = fracs(c.length, p); }
  public SweepGradient(float x, float y, int c0, int c1) { this(x, y, new int[]{c0, c1}, null); }
  int at(float t) {
    if (t <= f[0]) return c[0];
    for (int i = 1; i < c.length; i++) if (t <= f[i]) {
      float k = (t - f[i - 1]) / (f[i] - f[i - 1]);
      int a = c[i - 1], b = c[i];
      int aa = (int) ((a >>> 24) + ((b >>> 24) - (a >>> 24)) * k), rr = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * k);
      int gg = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * k), bb = (int) ((a & 255) + ((b & 255) - (a & 255)) * k);
      return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }
    return c[c.length - 1];
  }
  public java.awt.Paint awt() {
    final SweepGradient sg = this;
    final AffineTransform loc = new AffineTransform(local);
    return new java.awt.Paint() {
      public int getTransparency() { return TRANSLUCENT; }
      public PaintContext createContext(ColorModel cm, Rectangle db, Rectangle2D ub, AffineTransform xform, RenderingHints h) {
        AffineTransform full = new AffineTransform(xform); full.concatenate(loc);
        AffineTransform inv;
        try { inv = full.createInverse(); } catch (NoninvertibleTransformException e) { inv = new AffineTransform(); }
        final AffineTransform iv = inv;
        return new PaintContext() {
          public void dispose() {}
          public ColorModel getColorModel() { return ColorModel.getRGBdefault(); }
          public Raster getRaster(int px, int py, int w, int hh) {
            WritableRaster r = ColorModel.getRGBdefault().createCompatibleWritableRaster(w, hh);
            int[] row = new int[w];
            Point2D.Float s = new Point2D.Float(), d = new Point2D.Float();
            for (int j = 0; j < hh; j++) {
              for (int i = 0; i < w; i++) {
                s.setLocation(px + i + 0.5f, py + j + 0.5f); iv.transform(s, d);
                double a = Math.atan2(d.y - sg.y, d.x - sg.x); if (a < 0) a += Math.PI * 2;
                row[i] = sg.at((float) (a / (Math.PI * 2)));
              }
              r.setDataElements(0, j, w, 1, row);
            }
            return r;
          }
        };
      }
    };
  }
}
