package android.graphics;

import java.awt.Font;
import java.awt.font.FontRenderContext;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Desktop stand-in for android.graphics.Paint that keeps every setting so Canvas can draw with it. */
public class Paint {
  public static final int ANTI_ALIAS_FLAG = 1;
  public static int badAlpha = 0;
  public enum Style { FILL, STROKE, FILL_AND_STROKE }
  public enum Cap { BUTT, ROUND, SQUARE }
  public enum Join { MITER, ROUND, BEVEL }
  public enum Align { LEFT, CENTER, RIGHT }

  int color = 0xFF000000;
  Style style = Style.FILL;
  Cap cap = Cap.BUTT;
  Join join = Join.MITER;
  float strokeWidth = 0f;
  Align align = Align.LEFT;
  float textSize = 12f;
  Typeface typeface = null;
  float letterSpacing = 0f;
  ColorFilter colorFilter;
  Shader shader;
  PathEffect pathEffect;
  Xfermode xfermode;
  float shadowR = 0f, shadowDx = 0f, shadowDy = 0f;
  int shadowColor = 0;
  boolean aa = false;

  public Paint() {}
  public Paint(int flags) { aa = (flags & ANTI_ALIAS_FLAG) != 0; }

  public void setStyle(Style s) { style = s; } public Style getStyle() { return style; }
  public void setStrokeCap(Cap c) { cap = c; } public Cap getStrokeCap() { return cap; }
  public void setStrokeJoin(Join j) { join = j; } public Join getStrokeJoin() { return join; }
  public void setStrokeWidth(float w) { if (w >= 0f) strokeWidth = w; } public float getStrokeWidth() { return strokeWidth; }
  public void setColor(int c) { color = c; } public int getColor() { return color; }
  public void setAlpha(int a) { if (a < 0 || a > 255) badAlpha++; a = Math.max(0, Math.min(255, a)); color = (color & 0x00FFFFFF) | (a << 24); }
  public int getAlpha() { return color >>> 24; }
  public void setTextAlign(Align a) { align = a; } public Align getTextAlign() { return align; }
  public void setTextSize(float s) { if (s > 0f) textSize = s; } public float getTextSize() { return textSize; }
  public Typeface setTypeface(Typeface t) { typeface = t; return t; } public Typeface getTypeface() { return typeface; }
  public void setLetterSpacing(float s) { letterSpacing = s; } public float getLetterSpacing() { return letterSpacing; }
  public ColorFilter setColorFilter(ColorFilter f) { colorFilter = f; return f; } public ColorFilter getColorFilter() { return colorFilter; }
  public Shader setShader(Shader s) { shader = s; return s; } public Shader getShader() { return shader; }
  public PathEffect setPathEffect(PathEffect e) { pathEffect = e; return e; } public PathEffect getPathEffect() { return pathEffect; }
  public Xfermode setXfermode(Xfermode x) { xfermode = x; return x; } public Xfermode getXfermode() { return xfermode; }
  public void setShadowLayer(float r, float dx, float dy, int c) { shadowR = r; shadowDx = dx; shadowDy = dy; shadowColor = c; }
  public void clearShadowLayer() { shadowR = 0f; }
  public void setAntiAlias(boolean b) { aa = b; } public boolean isAntiAlias() { return aa; }
  public void setFilterBitmap(boolean b) {} public boolean isFilterBitmap() { return false; }
  public void setDither(boolean b) {} public boolean isDither() { return false; }

  boolean isAdd() { return xfermode instanceof PorterDuffXfermode && ((PorterDuffXfermode) xfermode).mode == PorterDuff.Mode.ADD; }

  // ---------------- text ----------------
  static final FontRenderContext FRC = new FontRenderContext(null, true, true);
  static Font FALLBACK, FALLBACK_BOLD;
  static final Map<Integer, float[]> EMOJI = new HashMap<>();
  static final Map<Integer, BufferedImage> EMOJI_IMG = new HashMap<>();
  static {
    FALLBACK = Typeface.load("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
    FALLBACK_BOLD = Typeface.load("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf");
    try {
      String js = new String(Files.readAllBytes(Paths.get("/home/claude/rise/sim/emoji/index.json")));
      Matcher m = Pattern.compile("\"([0-9a-f]+)\":\\s*\\{\\s*\"left\":\\s*(-?[0-9.]+),\\s*\"top\":\\s*(-?[0-9.]+),\\s*\"adv\":\\s*(-?[0-9.]+)").matcher(js);
      while (m.find()) {
        int cp = Integer.parseInt(m.group(1), 16);
        EMOJI.put(cp, new float[]{Float.parseFloat(m.group(2)), Float.parseFloat(m.group(3)), Float.parseFloat(m.group(4))});
        EMOJI_IMG.put(cp, javax.imageio.ImageIO.read(new java.io.File("/home/claude/rise/sim/emoji/" + m.group(1) + ".png")));
      }
    } catch (Exception e) { System.err.println("emoji index: " + e); }
  }

  /** A run of text in one font, or one emoji picture. */
  static final class Seg { String text; Font font; int emoji = -1; float adv; TextLayout tl; }

  Font mainFont() {
    Typeface tf = typeface == null ? Typeface.DEFAULT : typeface;
    Font f = tf.awt(textSize);
    if (letterSpacing != 0f) { Map<TextAttribute, Object> m = new HashMap<>(); m.put(TextAttribute.TRACKING, letterSpacing); f = f.deriveFont(m); }
    return f;
  }

  List<Seg> segments(String s) {
    List<Seg> out = new ArrayList<>();
    Font main = mainFont();
    boolean bold = typeface != null && (typeface.style & Typeface.BOLD) != 0;
    Font fb = (bold ? FALLBACK_BOLD : FALLBACK).deriveFont(textSize);
    if (letterSpacing != 0f) { Map<TextAttribute, Object> m = new HashMap<>(); m.put(TextAttribute.TRACKING, letterSpacing); fb = fb.deriveFont(m); }
    StringBuilder cur = new StringBuilder(); Font curF = null;
    int i = 0;
    while (i < s.length()) {
      int cp = s.codePointAt(i); i += Character.charCount(cp);
      if (cp == 0xFE0F || cp == 0xFE0E || cp == 0x200D) continue;
      if (EMOJI.containsKey(cp) && (cp >= 0x1F000 || cp == 0x26A1 || cp == 0x2604)) {
        if (cur.length() > 0) { out.add(textSeg(cur.toString(), curF)); cur.setLength(0); }
        Seg e = new Seg(); e.emoji = cp; e.adv = EMOJI.get(cp)[2] / 109f * textSize; out.add(e);
        continue;
      }
      Font f = main.canDisplay(cp) ? main : fb;
      if (curF != null && f != curF && cur.length() > 0) { out.add(textSeg(cur.toString(), curF)); cur.setLength(0); }
      curF = f; cur.appendCodePoint(cp);
    }
    if (cur.length() > 0) out.add(textSeg(cur.toString(), curF));
    return out;
  }

  static Seg textSeg(String t, Font f) {
    Seg s = new Seg(); s.text = t; s.font = f; s.tl = new TextLayout(t, f, FRC); s.adv = s.tl.getAdvance(); return s;
  }

  public float measureText(String s) {
    if (s == null || s.isEmpty()) return 0f;
    float w = 0f; for (Seg g : segments(s)) w += g.adv; return w;
  }
  public float ascent() { return -mainFont().getLineMetrics("Hg", FRC).getAscent(); }
  public float descent() { return mainFont().getLineMetrics("Hg", FRC).getDescent(); }
}
