package android.graphics;
import java.awt.image.BufferedImage;
/** Desktop stand-in backed by a BufferedImage. */
public class Bitmap {
  public enum Config { ALPHA_8, RGB_565, ARGB_4444, ARGB_8888 }
  public final BufferedImage img;
  public Bitmap(BufferedImage i) { img = i; }
  public static Bitmap createBitmap(int w, int h, Config c) {
    if (w <= 0 || h <= 0) throw new IllegalArgumentException("width and height must be > 0");
    return new Bitmap(new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB_PRE));
  }
  public int getWidth() { return img.getWidth(); } public int getHeight() { return img.getHeight(); }
  public void setPixels(int[] p, int off, int stride, int x, int y, int w, int h) { img.setRGB(x, y, w, h, p, off, stride); }
  public void eraseColor(int c) { for (int y = 0; y < img.getHeight(); y++) for (int x = 0; x < img.getWidth(); x++) img.setRGB(x, y, c); }
  public void recycle() {}
}
