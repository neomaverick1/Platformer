package android.graphics;
import java.awt.geom.*;
public class Path {
  public enum Direction { CW, CCW }
  public enum FillType { WINDING, EVEN_ODD, INVERSE_WINDING, INVERSE_EVEN_ODD }
  public final Path2D.Float p = new Path2D.Float();
  FillType ft = FillType.WINDING;
  boolean started = false;
  public void reset() { p.reset(); ft = FillType.WINDING; started = false; p.setWindingRule(Path2D.WIND_NON_ZERO); }
  public void rewind() { p.reset(); started = false; }
  public void moveTo(float x, float y) { p.moveTo(x, y); started = true; }
  public void lineTo(float x, float y) { if (!started) moveTo(0, 0); p.lineTo(x, y); }
  public void quadTo(float x1, float y1, float x2, float y2) { if (!started) moveTo(0, 0); p.quadTo(x1, y1, x2, y2); }
  public void cubicTo(float x1, float y1, float x2, float y2, float x3, float y3) { if (!started) moveTo(0, 0); p.curveTo(x1, y1, x2, y2, x3, y3); }
  public void close() { if (started) p.closePath(); }
  public void setFillType(FillType f) { ft = f; p.setWindingRule(f == FillType.EVEN_ODD || f == FillType.INVERSE_EVEN_ODD ? Path2D.WIND_EVEN_ODD : Path2D.WIND_NON_ZERO); }
  public FillType getFillType() { return ft; }
  public void addRect(float l, float t, float r, float b, Direction d) { p.append(new Rectangle2D.Float(Math.min(l, r), Math.min(t, b), Math.abs(r - l), Math.abs(b - t)), false); started = true; }
  public void addCircle(float x, float y, float r, Direction d) { p.append(new Ellipse2D.Float(x - r, y - r, 2 * r, 2 * r), false); started = true; }
  public void addOval(RectF o, Direction d) { p.append(new Ellipse2D.Float(o.left, o.top, o.width(), o.height()), false); started = true; }
  public void addRoundRect(RectF r, float rx, float ry, Direction d) { p.append(new RoundRectangle2D.Float(r.left, r.top, r.width(), r.height(), 2 * rx, 2 * ry), false); started = true; }
  public boolean isEmpty() { return p.getCurrentPoint() == null; }
}
