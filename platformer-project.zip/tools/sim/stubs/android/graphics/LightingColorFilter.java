package android.graphics;
public class LightingColorFilter extends ColorFilter {
  public final int mul, add;
  public LightingColorFilter(int mul, int add) { this.mul = mul; this.add = add; }
  int apply(int argb) {
    int a = argb >>> 24;
    int r = Math.min(255, ((argb >> 16) & 255) * ((mul >> 16) & 255) / 255 + ((add >> 16) & 255));
    int g = Math.min(255, ((argb >> 8) & 255) * ((mul >> 8) & 255) / 255 + ((add >> 8) & 255));
    int b = Math.min(255, (argb & 255) * (mul & 255) / 255 + (add & 255));
    return (a << 24) | (r << 16) | (g << 8) | b;
  }
}
