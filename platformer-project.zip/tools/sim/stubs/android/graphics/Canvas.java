package android.graphics;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Composite;
import java.awt.CompositeContext;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.util.ArrayDeque;
import java.util.List;

/**
 * Desktop stand-in for android.graphics.Canvas drawing into a BufferedImage with Java2D.
 * new Canvas() with no image draws nothing (the fast simulator), but still counts NaN coordinates.
 */
public class Canvas {
  public static int nanDraws = 0;
  static void chk(float... v) { for (float f : v) if (Float.isNaN(f) || Float.isInfinite(f)) { nanDraws++; return; } }

  BufferedImage img;
  Graphics2D g;
  final int W, H;
  final ArrayDeque<St> stack = new ArrayDeque<>();
  int nullDepth = 0;

  static final class St { AffineTransform tx; Shape clip; boolean layer; BufferedImage prevImg; Graphics2D prevG; float alpha = 1f; boolean add; }

  public Canvas() { W = 0; H = 0; }
  public Canvas(Bitmap b) { this(b.img); }
  public void drawBitmap(Bitmap b, Rect s, Rect d, Paint p) {
    if (g == null || b == null) return;
    int sx0 = s == null ? 0 : s.left, sy0 = s == null ? 0 : s.top;
    int sx1 = s == null ? b.getWidth() : s.right, sy1 = s == null ? b.getHeight() : s.bottom;
    Composite old = g.getComposite();
    float a = p == null ? 1f : p.getAlpha() / 255f;
    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
    java.awt.image.BufferedImage srcImg = b.img;
    if (p != null && p.colorFilter instanceof LightingColorFilter) {
      LightingColorFilter lf = (LightingColorFilter) p.colorFilter;
      int w = sx1 - sx0, h = sy1 - sy0;
      if (w > 0 && h > 0) {
        java.awt.image.BufferedImage t = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
          int sxp = sx0 + xx, syp = sy0 + yy;
          if (sxp < 0 || syp < 0 || sxp >= b.img.getWidth() || syp >= b.img.getHeight()) continue;
          t.setRGB(xx, yy, lf.apply(b.img.getRGB(sxp, syp)));
        }
        srcImg = t; sx1 = w; sy1 = h; sx0 = 0; sy0 = 0;
      }
    }
    g.drawImage(srcImg, d.left, d.top, d.right, d.bottom, sx0, sy0, sx1, sy1, null);
    g.setComposite(old);
  }
  public void drawBitmap(Bitmap b, float x, float y, Paint p) { drawBitmap(b, null, new Rect((int) x, (int) y, (int) x + b.getWidth(), (int) y + b.getHeight()), p); }
  public Canvas(BufferedImage im) { img = im; W = im.getWidth(); H = im.getHeight(); g = mk(img); }
  public BufferedImage image() { return img; }

  static Graphics2D mk(BufferedImage im) {
    Graphics2D g = im.createGraphics();
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
    return g;
  }

  // ---------------- state ----------------
  public int save() {
    St s = new St();
    if (g != null) { s.tx = g.getTransform(); s.clip = g.getClip(); }
    stack.push(s);
    return stack.size();
  }
  public int saveLayerAlpha(float l, float t, float r, float b, int a) { return layer(l, t, r, b, Math.max(0, Math.min(255, a)) / 255f, false); }
  public int saveLayer(float l, float t, float r, float b, Paint p) { return layer(l, t, r, b, p == null ? 1f : p.getAlpha() / 255f, p != null && p.isAdd()); }
  int layer(float l, float t, float r, float b, float a, boolean add) {
    chk(l, t, r, b);
    St s = new St(); s.layer = true; s.alpha = a; s.add = add;
    if (g != null) {
      s.tx = g.getTransform(); s.clip = g.getClip(); s.prevImg = img; s.prevG = g;
      img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB_PRE);
      g = mk(img); g.setTransform(s.tx);
      if (s.clip != null) g.setClip(s.clip);
      g.clip(new Rectangle2D.Float(Math.min(l, r), Math.min(t, b), Math.abs(r - l), Math.abs(b - t)));
    }
    stack.push(s);
    return stack.size();
  }
  public void restore() {
    if (stack.isEmpty()) throw new IllegalStateException("Underflow in restore - more restores than saves");
    St s = stack.pop();
    if (g == null) return;
    if (s.layer) {
      g.dispose();
      Graphics2D pg = s.prevG;
      pg.setTransform(new AffineTransform()); pg.setClip(null);
      pg.setComposite(s.add ? new AddComposite(s.alpha) : AlphaComposite.getInstance(AlphaComposite.SRC_OVER, s.alpha));
      pg.drawImage(img, 0, 0, null);
      pg.setComposite(AlphaComposite.SrcOver);
      img = s.prevImg; g = pg;
    }
    g.setTransform(s.tx); g.setClip(s.clip);
  }
  public int getSaveCount() { return stack.size() + 1; }

  public void translate(float x, float y) { chk(x, y); if (g != null) g.translate(x, y); }
  public void scale(float sx, float sy, float px, float py) { chk(sx, sy, px, py); if (g != null) { g.translate(px, py); g.scale(sx, sy); g.translate(-px, -py); } }
  public void scale(float sx, float sy) { chk(sx, sy); if (g != null) g.scale(sx, sy); }
  public void rotate(float d) { chk(d); if (g != null) g.rotate(Math.toRadians(d)); }
  public void rotate(float d, float px, float py) { chk(d, px, py); if (g != null) g.rotate(Math.toRadians(d), px, py); }
  public boolean clipRect(float l, float t, float r, float b) { chk(l, t, r, b); if (g != null) g.clip(new Rectangle2D.Float(Math.min(l, r), Math.min(t, b), Math.abs(r - l), Math.abs(b - t))); return true; }
  public boolean clipPath(Path p) { if (g != null) g.clip(p.p); return true; }

  // ---------------- drawing ----------------
  public void drawColor(int c) { if (g == null) return; Paint p = new Paint(); p.setColor(c); AffineTransform t = g.getTransform(); g.setTransform(new AffineTransform()); paintShape(new Rectangle(0, 0, W, H), p, true); g.setTransform(t); }
  public void drawCircle(float cx, float cy, float r, Paint p) { chk(cx, cy, r); if (g != null && r > 0f) shape(new Ellipse2D.Float(cx - r, cy - r, 2 * r, 2 * r), p); }
  public void drawOval(RectF o, Paint p) { chk(o.left, o.top, o.right, o.bottom); if (g != null) shape(new Ellipse2D.Float(o.left, o.top, o.width(), o.height()), p); }
  public void drawRect(float l, float t, float r, float b, Paint p) { chk(l, t, r, b); if (g != null) shape(new Rectangle2D.Float(Math.min(l, r), Math.min(t, b), Math.abs(r - l), Math.abs(b - t)), p); }
  public void drawRect(RectF r, Paint p) { drawRect(r.left, r.top, r.right, r.bottom, p); }
  public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p) { chk(l, t, r, b, rx, ry); if (g != null) shape(new RoundRectangle2D.Float(Math.min(l, r), Math.min(t, b), Math.abs(r - l), Math.abs(b - t), 2 * rx, 2 * ry), p); }
  public void drawRoundRect(RectF r, float rx, float ry, Paint p) { drawRoundRect(r.left, r.top, r.right, r.bottom, rx, ry, p); }
  public void drawArc(RectF o, float s, float sw, boolean c, Paint p) {
    chk(o.left, o.top, o.right, o.bottom, s, sw);
    if (g == null) return;
    if (sw >= 360f || sw <= -360f) { if (c) shape(new Ellipse2D.Float(o.left, o.top, o.width(), o.height()), p); else shape(new Arc2D.Float(o.left, o.top, o.width(), o.height(), 0, 360, Arc2D.OPEN), p); return; }
    shape(new Arc2D.Float(o.left, o.top, o.width(), o.height(), -s, -sw, c ? Arc2D.PIE : Arc2D.OPEN), p);
  }
  public void drawPath(Path pa, Paint p) { if (g != null) shape(pa.p, p); }
  public void drawLine(float a, float b, float c, float d, Paint p) {
    chk(a, b, c, d);
    if (g == null) return;
    paintShape(new Line2D.Float(a, b, c, d), p, false);
  }
  public void drawPoint(float x, float y, Paint p) {
    chk(x, y);
    if (g == null) return;
    float w = Math.max(1f, p.strokeWidth) / 2f;
    Shape s = p.cap == Paint.Cap.ROUND ? new Ellipse2D.Float(x - w, y - w, 2 * w, 2 * w) : new Rectangle2D.Float(x - w, y - w, 2 * w, 2 * w);
    paintShape(s, p, true);
  }

  public void drawText(String t, float x, float y, Paint p) {
    chk(x, y);
    if (g == null || t == null || t.isEmpty()) return;
    List<Paint.Seg> segs = p.segments(t);
    float total = 0f; for (Paint.Seg s : segs) total += s.adv;
    float ox = p.align == Paint.Align.CENTER ? x - total / 2f : p.align == Paint.Align.RIGHT ? x - total : x;
    java.awt.geom.Path2D.Float outline = new java.awt.geom.Path2D.Float();
    float cx = ox;
    for (Paint.Seg s : segs) {
      if (s.emoji < 0) outline.append(s.tl.getOutline(AffineTransform.getTranslateInstance(cx, y)), false);
      cx += s.adv;
    }
    if (p.shadowR > 0f) shadow(outline, p);
    if (p.style != Paint.Style.STROKE) paintShape(outline, p, true);
    if (p.style != Paint.Style.FILL) paintShape(outline, p, false);
    // colour emoji pictures (not tinted by the paint colour, faded by its alpha)
    cx = ox;
    for (Paint.Seg s : segs) {
      if (s.emoji >= 0) {
        float[] m = Paint.EMOJI.get(s.emoji);
        float k = p.textSize / 109f;
        BufferedImage im = Paint.EMOJI_IMG.get(s.emoji);
        Composite old = g.getComposite();
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, p.getAlpha() / 255f));
        AffineTransform at = new AffineTransform(); at.translate(cx + m[0] * k, y + m[1] * k); at.scale(k, k);
        g.drawImage(im, at, null);
        g.setComposite(old);
      }
      cx += s.adv;
    }
  }

  // ---------------- helpers ----------------
  void shape(Shape s, Paint p) {
    if (p.shadowR > 0f) shadow(s, p);
    if (p.style != Paint.Style.STROKE) paintShape(s, p, true);
    if (p.style != Paint.Style.FILL) paintShape(s, p, false);
  }

  BasicStroke stroke(Paint p) {
    float w = p.strokeWidth;
    if (w <= 0f) { double sc = Math.sqrt(Math.abs(g.getTransform().getDeterminant())); w = (float) (1.0 / Math.max(1e-6, sc)); }
    int cap = p.cap == Paint.Cap.ROUND ? BasicStroke.CAP_ROUND : p.cap == Paint.Cap.SQUARE ? BasicStroke.CAP_SQUARE : BasicStroke.CAP_BUTT;
    int join = p.join == Paint.Join.ROUND ? BasicStroke.JOIN_ROUND : p.join == Paint.Join.BEVEL ? BasicStroke.JOIN_BEVEL : BasicStroke.JOIN_MITER;
    if (p.pathEffect instanceof DashPathEffect) {
      DashPathEffect d = (DashPathEffect) p.pathEffect;
      float len = 0f; for (float f : d.intervals) len += f;
      float ph = len > 0f ? ((d.phase % len) + len) % len : 0f;
      float[] iv = d.intervals.clone(); for (int i = 0; i < iv.length; i++) if (iv[i] <= 0f) iv[i] = 0.001f;
      return new BasicStroke(w, cap, join, 4f, iv, ph);
    }
    return new BasicStroke(w, cap, join, 4f);
  }

  void setup(Paint p) {
    float extra = 1f;
    if (p.shader != null) { g.setPaint(p.shader.awt()); extra = p.getAlpha() / 255f; }
    else g.setPaint(new java.awt.Color(p.color, true));
    g.setComposite(p.isAdd() ? new AddComposite(extra) : AlphaComposite.getInstance(AlphaComposite.SRC_OVER, extra));
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, p.aa ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
  }

  void paintShape(Shape s, Paint p, boolean fill) {
    setup(p);
    if (fill) g.fill(s);
    else g.fill(stroke(p).createStrokedShape(s));
    g.setComposite(AlphaComposite.SrcOver);
  }

  /** Blurred shadow (Android: shadow alpha = paint alpha if the shadow colour is opaque). */
  void shadow(Shape userShape, Paint p) {
    AffineTransform tx = g.getTransform();
    double sc = Math.sqrt(Math.abs(tx.getDeterminant()));
    Shape dev = tx.createTransformedShape(userShape);
    float r = (float) (p.shadowR * sc);
    float sigma = r * 0.57735f + 0.5f;
    int pad = 2 * (int) Math.ceil(sigma * 3f) + 4;   // room for the glow plus the kernel's dead edge
    Rectangle b = dev.getBounds();
    b.grow(pad, pad);
    Rectangle clip = g.getClip() == null ? new Rectangle(0, 0, W, H) : tx.createTransformedShape(g.getClip()).getBounds().intersection(new Rectangle(0, 0, W, H));
    Rectangle box = b.intersection(clip);
    if (box.isEmpty() || box.width > 4000 || box.height > 4000) return;
    BufferedImage tmp = new BufferedImage(box.width, box.height, BufferedImage.TYPE_INT_ARGB_PRE);
    Graphics2D tg = mk(tmp);
    int sa = p.shadowColor >>> 24;
    int a = sa == 255 ? p.getAlpha() : sa;
    tg.setColor(new java.awt.Color((p.shadowColor & 0xFFFFFF) | (a << 24), true));
    tg.translate(-box.x + p.shadowDx * sc, -box.y + p.shadowDy * sc);
    if (p.style == Paint.Style.STROKE) tg.fill(new BasicStroke((float) (Math.max(1f, p.strokeWidth) * sc)).createStrokedShape(dev)); else tg.fill(dev);
    tg.dispose();
    BufferedImage bl = blur(tmp, sigma);
    AffineTransform keep = g.getTransform();
    Composite oc = g.getComposite();
    Shape oclip = g.getClip();
    g.setTransform(new AffineTransform());
    g.setComposite(p.isAdd() ? new AddComposite(1f) : AlphaComposite.SrcOver);
    g.drawImage(bl, box.x, box.y, null);
    g.setComposite(oc);
    g.setTransform(keep);
    g.setClip(oclip);
  }

  static BufferedImage blur(BufferedImage src, float sigma) {
    int rad = Math.max(1, (int) Math.ceil(sigma * 3f));
    float[] k = new float[rad * 2 + 1];
    float sum = 0f;
    for (int i = -rad; i <= rad; i++) { k[i + rad] = (float) Math.exp(-(i * i) / (2.0 * sigma * sigma)); sum += k[i + rad]; }
    for (int i = 0; i < k.length; i++) k[i] /= sum;
    ConvolveOp h = new ConvolveOp(new Kernel(k.length, 1, k), ConvolveOp.EDGE_ZERO_FILL, null);
    ConvolveOp v = new ConvolveOp(new Kernel(1, k.length, k), ConvolveOp.EDGE_ZERO_FILL, null);
    BufferedImage a = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB_PRE);
    BufferedImage b = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB_PRE);
    h.filter(src, a);
    v.filter(a, b);
    return b;
  }

  /** Porter-Duff ADD (saturating sum), as Android's PorterDuff.Mode.ADD. */
  static final class AddComposite implements Composite {
    final float extra;
    AddComposite(float a) { extra = Math.max(0f, Math.min(1f, a)); }
    public CompositeContext createContext(final ColorModel scm, final ColorModel dcm, RenderingHints hints) {
      return new CompositeContext() {
        public void dispose() {}
        public void compose(Raster src, Raster dstIn, WritableRaster dstOut) {
          int w = Math.min(src.getWidth(), dstIn.getWidth()), h = Math.min(src.getHeight(), dstIn.getHeight());
          Object sp = null, dp = null, op = null;
          int sx0 = src.getMinX(), sy0 = src.getMinY(), dx0 = dstIn.getMinX(), dy0 = dstIn.getMinY(), ox0 = dstOut.getMinX(), oy0 = dstOut.getMinY();
          for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
              sp = src.getDataElements(sx0 + x, sy0 + y, sp);
              dp = dstIn.getDataElements(dx0 + x, dy0 + y, dp);
              int s = scm.getRGB(sp), d = dcm.getRGB(dp);
              float sa = (s >>> 24) / 255f * extra, da = (d >>> 24) / 255f;
              float rr = Math.min(1f, ((s >> 16) & 255) / 255f * sa + ((d >> 16) & 255) / 255f * da);
              float gg = Math.min(1f, ((s >> 8) & 255) / 255f * sa + ((d >> 8) & 255) / 255f * da);
              float bb = Math.min(1f, (s & 255) / 255f * sa + (d & 255) / 255f * da);
              float aa = Math.min(1f, sa + da);
              int out;
              if (aa <= 0f) out = 0;
              else {
                int ia = Math.round(aa * 255f);
                int ir = Math.min(255, Math.round(rr / aa * 255f)), ig = Math.min(255, Math.round(gg / aa * 255f)), ib = Math.min(255, Math.round(bb / aa * 255f));
                out = (ia << 24) | (ir << 16) | (ig << 8) | ib;
              }
              op = dcm.getDataElements(out, op);
              dstOut.setDataElements(ox0 + x, oy0 + y, op);
            }
          }
        }
      };
    }
  }
}
