#!/bin/bash
cd /home/claude/platformer
L=/opt/gradle/lib
rm -rf kc/out
timeout 400 java -cp "$(cat kc/cp)" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -jvm-target 17 -language-version 1.9 -api-version 1.9 -cp $L/kotlin-stdlib-2.0.21.jar:kc/stubcls -d kc/out src/app/src/main/java/com/neomaverick/platformer/*.kt > kc/log.txt 2>&1
echo "exit $?"
grep -E "error:" kc/log.txt | sed 's#src/app/src/main/java/com/neomaverick/platformer/##' | wc -l
grep -E "error:|warning:" kc/log.txt | sed 's#src/app/src/main/java/com/neomaverick/platformer/##' | grep -v "^Picked" | head -${1:-80}
