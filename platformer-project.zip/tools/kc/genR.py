import os, re
res = '/home/claude/platformer/src/app/src/main/res'
def files(d):
    out = set()
    for dd in os.listdir(res):
        if dd == d or dd.startswith(d + '-'):
            out |= {os.path.splitext(f)[0].split('.')[0] for f in os.listdir(os.path.join(res, dd))}
    return out
vals = ''.join(open(os.path.join(res, 'values', f)).read() for f in os.listdir(os.path.join(res, 'values')))
styles = {s.replace('.', '_') for s in re.findall(r'<style name="([^"]+)"', vals)}
strings = set(re.findall(r'<string name="(\w+)"', vals))
n = [0x7f000000]
def cls(name, items):
    out = '  public static final class %s {\n' % name
    for i in sorted(items):
        n[0] += 1
        out += '    public static final int %s = %d;\n' % (i, n[0])
    return out + '  }\n'
src = 'package com.neomaverick.platformer;\npublic final class R {\n' + cls('drawable', files('drawable')) + cls('mipmap', files('mipmap')) + cls('raw', files('raw')) + cls('style', styles) + cls('string', strings) + '}\n'
os.makedirs('/home/claude/platformer/kc/stubs/com/neomaverick/platformer', exist_ok=True)
open('/home/claude/platformer/kc/stubs/com/neomaverick/platformer/R.java', 'w').write(src)
print('R ok')
