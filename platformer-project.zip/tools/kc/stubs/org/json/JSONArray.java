
package org.json;
public class JSONArray { public JSONArray() {} public JSONArray(String s) throws JSONException {}
  public int length() { return 0; } public JSONObject getJSONObject(int i) throws JSONException { return null; }
  public long getLong(int i) throws JSONException { return 0; }
  public JSONArray put(Object o) { return this; } public JSONArray put(long v) { return this; } public JSONArray put(int v) { return this; } }
