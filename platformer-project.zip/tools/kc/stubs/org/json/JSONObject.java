
package org.json;
public class JSONObject { public JSONObject() {} public JSONObject(String s) {}
  public JSONObject put(String k, int v) { return this; } public JSONObject put(String k, long v) { return this; }
  public JSONObject put(String k, boolean v) { return this; } public JSONObject put(String k, Object v) { return this; }
  public int optInt(String k) { return 0; } public int optInt(String k, int d) { return d; }
  public String optString(String k, String d) { return d; } public boolean optBoolean(String k, boolean d) { return d; }
  public boolean has(String k) { return false; } public java.util.Iterator<String> keys() { return null; } }
