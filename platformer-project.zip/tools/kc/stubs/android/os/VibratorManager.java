package android.os;
public abstract class VibratorManager { public abstract Vibrator getDefaultVibrator(); }
