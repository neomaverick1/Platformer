package android.os;
public final class SystemClock { public static long uptimeMillis() { return 0; } public static long elapsedRealtime() { return 0; } }
