
package android.os;
public class Build { public static final String MANUFACTURER = "", MODEL = ""; public static class VERSION { public static final int SDK_INT = 34; public static final String RELEASE = ""; }
  public static class VERSION_CODES { public static final int O = 26, O_MR1 = 27, Q = 29, S = 31, TIRAMISU = 33; } }
