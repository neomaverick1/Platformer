
package android.os;
import android.media.AudioAttributes;
public abstract class Vibrator { public void vibrate(VibrationEffect e, AudioAttributes a) {} public abstract void cancel(); }
