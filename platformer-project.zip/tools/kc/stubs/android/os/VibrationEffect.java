package android.os;
public abstract class VibrationEffect { public static VibrationEffect createWaveform(long[] t, int r) { return null; } }
