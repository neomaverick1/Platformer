package android.view;
public abstract class ActionMode { public interface Callback { boolean onCreateActionMode(ActionMode m, Menu menu); boolean onPrepareActionMode(ActionMode m, Menu menu); boolean onActionItemClicked(ActionMode m, MenuItem i); void onDestroyActionMode(ActionMode m); } }
