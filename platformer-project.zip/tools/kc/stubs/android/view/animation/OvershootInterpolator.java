package android.view.animation;
public class OvershootInterpolator implements android.animation.TimeInterpolator { public OvershootInterpolator(float t) {} public float getInterpolation(float i) { return i; } }
