package android.view.animation;
public class DecelerateInterpolator implements android.animation.TimeInterpolator { public DecelerateInterpolator() {} public float getInterpolation(float i) { return i; } }
