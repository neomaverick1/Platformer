package android.view.animation;
public abstract class Animation {}
