package android.view.animation;
public class AccelerateInterpolator implements android.animation.TimeInterpolator { public AccelerateInterpolator() {} public float getInterpolation(float f) { return f; } }
