package android.view.animation;
public class LinearInterpolator implements android.animation.TimeInterpolator { public LinearInterpolator() {} public float getInterpolation(float f) { return f; } }
