
package android.view;
public class ViewPropertyAnimator {
  public ViewPropertyAnimator alpha(float v) { return this; } public ViewPropertyAnimator scaleX(float v) { return this; }
  public ViewPropertyAnimator scaleY(float v) { return this; } public ViewPropertyAnimator rotation(float v) { return this; }
  public ViewPropertyAnimator translationY(float v) { return this; } public ViewPropertyAnimator setDuration(long d) { return this; }
  public ViewPropertyAnimator withEndAction(Runnable r) { return this; }
  public ViewPropertyAnimator setInterpolator(android.animation.TimeInterpolator i) { return this; } public void start() {}   public void cancel() {} public ViewPropertyAnimator rotationX(float v) { return this; } public ViewPropertyAnimator rotationY(float v) { return this; } public ViewPropertyAnimator translationX(float v) { return this; } public ViewPropertyAnimator setStartDelay(long d) { return this; }
}
