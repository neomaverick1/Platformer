
package android.view;
import android.content.Context; import android.util.AttributeSet;
public abstract class ViewGroup extends View {
  public static final int FOCUS_BLOCK_DESCENDANTS = 393216;
  public ViewGroup(Context c) { super(c); } public ViewGroup(Context c, AttributeSet a) { super(c, a); }
  public void addView(View v) {} public void addView(View v, LayoutParams lp) {} public void removeView(View v) {} public void addView(View v, int index) {} public int indexOfChild(View v) { return 0; } public void removeAllViews() {} public int getChildCount() { return 0; } public boolean getClipToPadding() { return true; } public void setClipToPadding(boolean b) {} public boolean getClipChildren() { return true; } public void setClipChildren(boolean b) {} public View getChildAt(int i) { return null; }
  public int getDescendantFocusability() { return 0; } public void setDescendantFocusability(int f) {}
  public static class LayoutParams { public static final int MATCH_PARENT = -1, WRAP_CONTENT = -2; public int width, height;
    public LayoutParams(int w, int h) {} }
  public static class MarginLayoutParams extends LayoutParams { public int leftMargin, topMargin, rightMargin, bottomMargin;
    public MarginLayoutParams(int w, int h) { super(w, h); } public void setMargins(int l, int t, int r, int b) {}
    public void setMarginStart(int m) {} public int getMarginStart() { return 0; } public void setMarginEnd(int m) {} public int getMarginEnd() { return 0; } }
}
