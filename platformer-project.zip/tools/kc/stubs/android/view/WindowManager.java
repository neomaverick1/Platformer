
package android.view;
public interface WindowManager { void addView(View v, ViewGroup.LayoutParams p); void updateViewLayout(View v, ViewGroup.LayoutParams p); void removeView(View v);
  class LayoutParams extends ViewGroup.LayoutParams {
    public static final int FLAG_KEEP_SCREEN_ON = 128, FLAG_SHOW_WHEN_LOCKED = 524288, FLAG_TURN_SCREEN_ON = 2097152,
      FLAG_NOT_FOCUSABLE = 8, FLAG_LAYOUT_NO_LIMITS = 512, TYPE_APPLICATION_OVERLAY = 2038;
    public int x, y, gravity; public int layoutInDisplayCutoutMode; public static final int LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES = 1; public LayoutParams() { super(0, 0); } public float alpha = 1f;
    public LayoutParams(int w, int h, int type, int flags, int format) { super(w, h); } } }
