
package android.view;
import android.graphics.drawable.Drawable;
public abstract class Window { public WindowInsetsController getInsetsController() { return null; } public void setDecorFitsSystemWindows(boolean b) {}
  public WindowManager.LayoutParams getAttributes() { return null; } public void setAttributes(WindowManager.LayoutParams p) {} public void addFlags(int f) {} public abstract void setBackgroundDrawable(Drawable d);
  public void setStatusBarColor(int c) {} public int getStatusBarColor() { return 0; }
  public void setNavigationBarColor(int c) {} public int getNavigationBarColor() { return 0; }
  public abstract View getDecorView(); }
