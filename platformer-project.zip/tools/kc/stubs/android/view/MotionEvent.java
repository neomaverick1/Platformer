
package android.view;
public final class MotionEvent { public static final int ACTION_DOWN = 0, ACTION_UP = 1, ACTION_MOVE = 2, ACTION_CANCEL = 3, ACTION_POINTER_DOWN = 5, ACTION_POINTER_UP = 6;
  public final int getPointerCount() { return 1; } public final int getActionIndex() { return 0; } public final int getPointerId(int i) { return 0; } public final float getX(int i) { return 0; } public final float getY(int i) { return 0; }
  public final int getActionMasked() { return 0; } public final float getRawX() { return 0; } public final float getX() { return 0; } public final float getY() { return 0; } public final float getRawY() { return 0; } }
