package android.view;
public final class WindowInsets { public static final class Type { public static int systemBars() { return 0; } } }
