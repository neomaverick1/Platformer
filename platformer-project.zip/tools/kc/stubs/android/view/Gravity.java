package android.view;
public class Gravity { public static final int NO_GRAVITY = 0, CENTER = 17, CENTER_VERTICAL = 16, CENTER_HORIZONTAL = 1, TOP = 48, BOTTOM = 80, LEFT = 3, RIGHT = 5, START = 8388611, END = 8388613; }
