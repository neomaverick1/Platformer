package android.widget;
import android.content.Context;
public class ProgressBar extends android.view.View { public ProgressBar(Context c, android.util.AttributeSet a, int s) { super(c); }
 public void setMax(int m) {} public int getMax() { return 0; } public void setProgress(int p) {} public void setProgressTintList(android.content.res.ColorStateList c) {} public android.content.res.ColorStateList getProgressTintList() { return null; } public int getProgress() { return 0; } }
