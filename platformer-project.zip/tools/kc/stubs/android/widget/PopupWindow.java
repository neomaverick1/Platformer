package android.widget;
public class PopupWindow { public PopupWindow(android.view.View v, int w, int h, boolean f) {}
 public void setTouchable(boolean b) {} public boolean isTouchable() { return false; } public void setClippingEnabled(boolean b) {} public boolean isClippingEnabled() { return true; }
 public void showAtLocation(android.view.View parent, int g, int x, int y) {} public void dismiss() {} }
