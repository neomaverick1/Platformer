package android.widget;
import android.content.Context;
public class ScrollView extends FrameLayout { public ScrollView(Context c) { super(c); } public final void smoothScrollBy(int x, int y) {} public final void smoothScrollTo(int x, int y) {} public boolean fullScroll(int d) { return true; } }
