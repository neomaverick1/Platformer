
package android.widget;
import android.content.Context;
public class Spinner extends android.view.ViewGroup { public Spinner(Context c) { super(c); }
  public void setAdapter(SpinnerAdapter a) {} public SpinnerAdapter getAdapter() { return null; }
  public void setSelection(int p) {} public int getSelectedItemPosition() { return 0; } }
