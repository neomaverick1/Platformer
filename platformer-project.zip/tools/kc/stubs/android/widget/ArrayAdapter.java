
package android.widget;
import android.content.Context;
public class ArrayAdapter<T> implements SpinnerAdapter { public ArrayAdapter(Context c, int r, java.util.List<T> o) {} }
