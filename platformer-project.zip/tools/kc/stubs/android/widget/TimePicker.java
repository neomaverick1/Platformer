
package android.widget;
import android.content.Context;
public class TimePicker extends FrameLayout { public TimePicker(Context c) { super(c); }
  public void setIs24HourView(Boolean b) {} public void setHour(int h) {} public int getHour() { return 0; }
  public void setMinute(int m) {} public int getMinute() { return 0; } }
