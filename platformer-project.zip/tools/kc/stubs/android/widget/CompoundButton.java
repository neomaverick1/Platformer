
package android.widget;
import android.content.Context;
public abstract class CompoundButton extends Button { public CompoundButton(Context c) { super(c); }
  public void setChecked(boolean b) {} public boolean isChecked() { return false; }
  public void setOnCheckedChangeListener(OnCheckedChangeListener l) {}
  public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton b, boolean c); } }
