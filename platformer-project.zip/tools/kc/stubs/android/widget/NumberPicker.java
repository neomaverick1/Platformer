
package android.widget;
import android.content.Context;
public class NumberPicker extends LinearLayout { public NumberPicker(Context c) { super(c); }
  public void setMinValue(int v) {} public int getMinValue() { return 0; } public void setMaxValue(int v) {} public int getMaxValue() { return 0; }
  public void setValue(int v) {} public int getValue() { return 0; }
  public void setFormatter(Formatter f) {} public void setOnValueChangedListener(OnValueChangeListener l) {}
  public void setTextColor(int c) {} public int getTextColor() { return 0; }
  public interface Formatter { String format(int v); }
  public interface OnValueChangeListener { void onValueChange(NumberPicker p, int o, int n); } }
