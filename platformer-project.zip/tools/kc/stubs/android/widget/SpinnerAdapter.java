package android.widget;
public interface SpinnerAdapter {}
