package android.widget;
import android.content.Context;
public class HorizontalScrollView extends FrameLayout { public HorizontalScrollView(Context c) { super(c); } public void setHorizontalScrollBarEnabled(boolean b) {} public boolean isHorizontalScrollBarEnabled() { return false; } }
