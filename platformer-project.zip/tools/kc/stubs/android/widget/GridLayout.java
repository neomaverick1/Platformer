
package android.widget;
import android.content.Context; import android.view.ViewGroup;
public class GridLayout extends ViewGroup { public static final int UNDEFINED = Integer.MIN_VALUE;
  public GridLayout(Context c) { super(c); }
  public void setColumnCount(int c) {} public int getColumnCount() { return 0; }
  public static Spec spec(int start) { return null; } public static Spec spec(int start, float weight) { return null; }
  public static class Spec {}
  public static class LayoutParams extends ViewGroup.MarginLayoutParams { public LayoutParams() { super(0, 0); }
    public LayoutParams(Spec r, Spec c) { super(0, 0); } } }
