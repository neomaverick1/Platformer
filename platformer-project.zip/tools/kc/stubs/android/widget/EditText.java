
package android.widget;
import android.content.Context; import android.text.Editable;
public class EditText extends TextView { public EditText(Context c) { super(c); } public void setFilters(android.text.InputFilter[] f) {} public android.text.InputFilter[] getFilters() { return null; } public EditText(Context c, android.util.AttributeSet a) { super(c, a); }
  @Override public Editable getText() { return null; } }
