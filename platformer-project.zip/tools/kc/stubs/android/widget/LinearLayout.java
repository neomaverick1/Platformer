
package android.widget;
import android.content.Context; import android.view.ViewGroup;
public class LinearLayout extends ViewGroup { public static final int HORIZONTAL = 0, VERTICAL = 1;
  public LinearLayout(Context c) { super(c); }
  public void setOrientation(int o) {} public int getOrientation() { return 0; }
  public void setGravity(int g) {} public int getGravity() { return 0; }
  public static class LayoutParams extends ViewGroup.MarginLayoutParams { public float weight; public int gravity = -1;
    public LayoutParams(int w, int h) { super(w, h); } public LayoutParams(int w, int h, float weight) { super(w, h); } } }
