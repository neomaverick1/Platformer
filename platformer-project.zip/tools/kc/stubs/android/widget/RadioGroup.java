
package android.widget;
import android.content.Context;
public class RadioGroup extends LinearLayout { public RadioGroup(Context c) { super(c); }
  public void check(int id) {} public int getCheckedRadioButtonId() { return 0; }
  public void setOnCheckedChangeListener(OnCheckedChangeListener l) {}
  public interface OnCheckedChangeListener { void onCheckedChanged(RadioGroup g, int id); } }
