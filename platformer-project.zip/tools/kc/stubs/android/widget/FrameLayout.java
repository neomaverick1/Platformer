package android.widget;
import android.content.Context; import android.view.ViewGroup;
public class FrameLayout extends ViewGroup { public FrameLayout(Context c) { super(c); }
  public static class LayoutParams extends ViewGroup.MarginLayoutParams { public int gravity = -1; public LayoutParams(int w, int h) { super(w, h); } public LayoutParams(int w, int h, int g) { super(w, h); } } }
