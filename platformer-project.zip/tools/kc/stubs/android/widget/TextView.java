
package android.widget;
import android.content.Context; import android.graphics.Typeface; import android.util.AttributeSet; import android.view.*;
public class TextView extends View { public int getCurrentTextColor() { return 0; } public void setMinHeight(int h) {} public int getMinHeight() { return 0; } public void setAllCaps(boolean b) {} public boolean isAllCaps() { return false; }
  public TextView(Context c) { super(c); } public TextView(Context c, AttributeSet a) { super(c, a); }
  public TextView(Context c, AttributeSet a, int s) { super(c, a); }
  public final void setText(CharSequence t) {} public CharSequence getText() { return null; }
  public void setTextSize(float s) {} public float getTextSize() { return 0; }
  public void setTextColor(int c) {} public void setShadowLayer(float r, float dx, float dy, int c) {} public void setMaxLines(int m) {} public int getMaxLines() { return 0; } public final android.text.TextPaint getPaint() { return null; }
  public void setTextIsSelectable(boolean b) {}
  public void setLineSpacing(float a, float m) {} public void setLetterSpacing(float s) {} public float getLetterSpacing() { return 0; }
  public void setCustomSelectionActionModeCallback(android.view.ActionMode.Callback c) {} public android.view.ActionMode.Callback getCustomSelectionActionModeCallback() { return null; }
  public void setCustomInsertionActionModeCallback(android.view.ActionMode.Callback c) {} public android.view.ActionMode.Callback getCustomInsertionActionModeCallback() { return null; } public boolean isTextSelectable() { return false; } public void setHintTextColor(int c) {}
  public void setTypeface(Typeface t) {} public void setTypeface(Typeface t, int s) {} public Typeface getTypeface() { return null; }
  public void setGravity(int g) {} public int getGravity() { return 0; }
  public void setFontFeatureSettings(String s) {} public String getFontFeatureSettings() { return null; }
  public void setIncludeFontPadding(boolean b) {} public boolean getIncludeFontPadding() { return true; }
  public final void setHint(CharSequence h) {} public CharSequence getHint() { return null; }
  public void setInputType(int t) {} public int getInputType() { return 0; }
  public void setImeOptions(int o) {} public int getImeOptions() { return 0; }
  public void setOnEditorActionListener(OnEditorActionListener l) {}
  public interface OnEditorActionListener { boolean onEditorAction(TextView v, int a, android.view.KeyEvent e); }
}
