
package android.widget;
import android.content.Context; import android.content.res.ColorStateList; import android.view.View;
public class ImageView extends View { public ImageView(Context c) { super(c); }
  public void setImageResource(int r) {} public void setImageTintList(ColorStateList t) {} public ColorStateList getImageTintList() { return null; } }
