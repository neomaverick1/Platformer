package android.widget;
import android.content.Context;
public class Button extends TextView { public Button(Context c) { super(c); } public Button(Context c, android.util.AttributeSet a, int s) { super(c, a, s); } }
