package android.widget;
public abstract class AdapterView {}
