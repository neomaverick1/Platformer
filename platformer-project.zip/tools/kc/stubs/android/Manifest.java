
package android;
public final class Manifest { public static final class permission {
  public static final String POST_NOTIFICATIONS = "a", READ_MEDIA_AUDIO = "b", READ_EXTERNAL_STORAGE = "c"; } }
