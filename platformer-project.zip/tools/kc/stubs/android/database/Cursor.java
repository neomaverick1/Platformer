
package android.database;
public interface Cursor extends java.io.Closeable {
  boolean moveToFirst(); boolean moveToNext(); String getString(int i); long getLong(int i);
  int getColumnIndexOrThrow(String n);
}
