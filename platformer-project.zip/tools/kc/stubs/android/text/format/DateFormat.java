
package android.text.format;
import android.content.Context;
public class DateFormat { public static boolean is24HourFormat(Context c) { return false; } }
