
package android.app;
import android.content.*; import android.os.Bundle;
public class Application extends ContextWrapper {
  public Application() { super(null); }
  public void onCreate() {}
  public void registerActivityLifecycleCallbacks(ActivityLifecycleCallbacks c) {}
  public interface ActivityLifecycleCallbacks {
    void onActivityCreated(Activity a, Bundle b); void onActivityStarted(Activity a); void onActivityResumed(Activity a);
    void onActivityPaused(Activity a); void onActivityStopped(Activity a); void onActivitySaveInstanceState(Activity a, Bundle b);
    void onActivityDestroyed(Activity a); }
}
