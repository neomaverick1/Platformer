
package android.app;
import android.content.*; import android.os.IBinder;
public abstract class Service extends ContextWrapper {
  public static final int START_NOT_STICKY = 2, START_STICKY = 1, STOP_FOREGROUND_REMOVE = 1, STOP_FOREGROUND_DETACH = 2;
  public Service() { super(null); }
  public void onCreate() {} public void onDestroy() {}
  public int onStartCommand(Intent i, int f, int id) { return 0; }
  public abstract IBinder onBind(Intent i);
  public final void startForeground(int id, Notification n) {}
  public final void startForeground(int id, Notification n, int type) {}
  public final void stopForeground(int flags) {}
  public final void stopSelf() {}
}
