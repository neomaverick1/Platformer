
package android.app;
public class AlarmManager { public static final int RTC_WAKEUP = 0;
  public void setExactAndAllowWhileIdle(int t, long at, PendingIntent p) {} public void setAndAllowWhileIdle(int t, long at, PendingIntent p) {}
  public void setAlarmClock(AlarmClockInfo i, PendingIntent p) {} public void cancel(PendingIntent p) {}
  public boolean canScheduleExactAlarms() { return true; }
  public static final class AlarmClockInfo { public AlarmClockInfo(long t, PendingIntent s) {} } }
