
package android.app;
import android.content.*;
public final class PendingIntent { public static final int FLAG_UPDATE_CURRENT = 1, FLAG_IMMUTABLE = 2;
  public static PendingIntent getActivity(Context c, int r, Intent i, int f) { return null; }
  public static PendingIntent getBroadcast(Context c, int r, Intent i, int f) { return null; }
  public static PendingIntent getService(Context c, int r, Intent i, int f) { return null; }
  public static PendingIntent getForegroundService(Context c, int r, Intent i, int f) { return null; } }
