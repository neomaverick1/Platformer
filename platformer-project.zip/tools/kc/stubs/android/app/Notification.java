package android.app;
public class Notification { public static final int VISIBILITY_PUBLIC = 1; }
