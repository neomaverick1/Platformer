
package android.app;
import android.content.*; import android.os.Bundle; import android.view.*;
public class Activity extends ContextWrapper { public boolean isDestroyed() { return false; } public final void setVolumeControlStream(int s) {} public final int getVolumeControlStream() { return 0; }
  public Activity() { super(null); }
  protected void onCreate(Bundle b) {} public void onWindowFocusChanged(boolean f) {} @Deprecated public void onBackPressed() {} protected void onResume() {} protected void onPause() {} protected void onDestroy() {}
  protected void onStart() {} protected void onStop() {}
  protected void onNewIntent(Intent i) {}
  protected void onSaveInstanceState(Bundle b) {}
  public Intent getIntent() { return null; } public void setIntent(Intent i) {}
  public void setTheme(int r) {} public void recreate() {} public void finish() {}
  public void setContentView(int l) {} public void setContentView(View v) {}
  public <T extends View> T findViewById(int id) { return null; }
  public Window getWindow() { return null; }
  public void overridePendingTransition(int a, int b) {}
  public void setShowWhenLocked(boolean b) {} public void setTurnScreenOn(boolean b) {}
  public boolean isChangingConfigurations() { return false; } public boolean isFinishing() { return false; }
  public boolean onKeyDown(int k, android.view.KeyEvent e) { return false; } public boolean onKeyUp(int k, android.view.KeyEvent e) { return false; }
  public View getCurrentFocus() { return null; }
}
