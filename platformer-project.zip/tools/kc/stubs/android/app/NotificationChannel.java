
package android.app;
import android.net.Uri; import android.media.AudioAttributes;
public final class NotificationChannel { public NotificationChannel(String id, CharSequence n, int imp) {}
  public void setSound(Uri u, AudioAttributes a) {} public void enableVibration(boolean b) {} public void setShowBadge(boolean b) {}
  public void setLockscreenVisibility(int v) {} public int getLockscreenVisibility() { return 0; } }
