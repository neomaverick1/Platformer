
package android.app;
public class KeyguardManager { public void requestDismissKeyguard(Activity a, KeyguardDismissCallback c) {}
  public static abstract class KeyguardDismissCallback {} }
