package android.media;
public class AudioManager { public static final int STREAM_MUSIC = 3, STREAM_ALARM = 4, USE_DEFAULT_STREAM_TYPE = -2147483648;
  public int getStreamVolume(int s) { return 0; } public int getStreamMaxVolume(int s) { return 0; } public void setStreamVolume(int s, int v, int f) {} }
