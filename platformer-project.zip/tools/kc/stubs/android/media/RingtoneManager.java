
package android.media;
import android.net.Uri;
public class RingtoneManager { public static final int TYPE_ALARM = 4, TYPE_RINGTONE = 1, TYPE_NOTIFICATION = 2, TYPE_ALL = 7; public static final String ACTION_RINGTONE_PICKER = "a", EXTRA_RINGTONE_PICKED_URI = "b", EXTRA_RINGTONE_TYPE = "c", EXTRA_RINGTONE_SHOW_SILENT = "d", EXTRA_RINGTONE_TITLE = "e"; public static Ringtone getRingtone(android.content.Context c, Uri u) { return null; }
  public static Uri getDefaultUri(int t) { return null; } }
