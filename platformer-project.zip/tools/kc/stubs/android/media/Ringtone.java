package android.media;
public class Ringtone { public String getTitle(android.content.Context c) { return null; } }
