
package android.media;
import android.content.Context; import android.net.Uri;
public class MediaPlayer { public static MediaPlayer create(Context c, int resid) { return null; } public void pause() {} public void setAudioAttributes(AudioAttributes a) {} public void setDataSource(Context c, Uri u) {}
  public void setLooping(boolean l) {} public boolean isLooping() { return false; }
  public void prepare() {} public void setVolume(float l, float r) {} public void start() {} public void stop() {} public void release() {} }
