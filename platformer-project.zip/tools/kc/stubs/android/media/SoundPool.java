package android.media;
import android.content.Context;
public class SoundPool {
  public interface OnLoadCompleteListener { void onLoadComplete(SoundPool p, int id, int status); }
  public static class Builder { public Builder setMaxStreams(int n) { return this; } public Builder setAudioAttributes(AudioAttributes a) { return this; } public SoundPool build() { return null; } }
  public void setOnLoadCompleteListener(OnLoadCompleteListener l) {}
  public int load(Context c, int res, int pri) { return 0; }
  public int play(int id, float l, float r, int pri, int loop, float rate) { return 0; }
  public void release() {} public final void autoPause() {} public final void autoResume() {}
}
