
package android.graphics;
public class Canvas { public Canvas() {} public Canvas(Bitmap b) {}
  public void drawBitmap(Bitmap b, Rect s, Rect d, Paint p) {} public void drawBitmap(Bitmap b, float x, float y, Paint p) {}
  public void drawColor(int c) {} public void scale(float sx, float sy) {} public void rotate(float d, float px, float py) {} public boolean clipRect(float l, float t, float r, float b) { return true; } public boolean clipPath(Path p) { return true; }
  public void drawCircle(float cx, float cy, float r, Paint p) {}
  public void drawLine(float a, float b, float c, float d, Paint p) {}
  public void drawArc(RectF o, float s, float sw, boolean c, Paint p) {}
  public void drawText(String t, float x, float y, Paint p) {}
  public void drawRect(float l, float t, float r, float b, Paint p) {} public void drawRect(RectF r, Paint p) {} public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p) {} public void rotate(float d) {} public void drawPoint(float x, float y, Paint p) {}
  public void drawRoundRect(RectF r, float rx, float ry, Paint p) {}
  public void drawPath(Path pa, Paint p) {}
  public int save() { return 0; } public int saveLayerAlpha(float l, float t, float r, float b, int a) { return 0; } public int saveLayer(float l, float t, float r, float b, Paint p) { return 0; } public void restore() {} public void translate(float x, float y) {}
  public void scale(float sx, float sy, float px, float py) {} public void drawOval(RectF o, Paint p) {}
}
