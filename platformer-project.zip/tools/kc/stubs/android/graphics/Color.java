package android.graphics;
public class Color { public static final int RED = 1, YELLOW = 2, GREEN = 3, CYAN = 4, BLUE = 5, MAGENTA = 6;
  public static void colorToHSV(int c, float[] hsv) {} public static int HSVToColor(float[] hsv) { return 0; } public static final int WHITE = -1, BLACK = -16777216; public static int parseColor(String s) { return 0; } public static float luminance(int c) { return 0f; } }
