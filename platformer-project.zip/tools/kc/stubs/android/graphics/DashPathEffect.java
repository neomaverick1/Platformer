package android.graphics;
public class DashPathEffect extends PathEffect { public DashPathEffect(float[] i, float p) {} }
