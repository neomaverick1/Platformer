
package android.graphics;
public class Typeface { public static final int NORMAL = 0, BOLD = 1, ITALIC = 2;
  public static final Typeface DEFAULT_BOLD = null, SERIF = null, SANS_SERIF = null, MONOSPACE = null, DEFAULT = null;
  public int getStyle() { return 0; } public static Typeface create(String f, int s) { return null; } public static Typeface create(Typeface f, int s) { return null; } }
