
package android.graphics.drawable;
public class GradientDrawable extends Drawable { public enum Orientation { TL_BR, TOP_BOTTOM, LEFT_RIGHT }
  public void setColors(int[] c) {} public int[] getColors() { return null; } public void setOrientation(Orientation o) {} public Orientation getOrientation() { return null; } public static final int OVAL = 1, RADIAL_GRADIENT = 1, LINEAR_GRADIENT = 0; public void setGradientType(int t) {} public int getGradientType() { return 0; } public void setGradientRadius(float r) {} public float getGradientRadius() { return 0; }
  public void setCornerRadius(float r) {} public float getCornerRadius() { return 0; }
  public void setColor(int c) {} public void setStroke(int w, int c) {}
  public void setShape(int s) {} public int getShape() { return 0; } }
