
package android.graphics;
public class Paint {
  public static final int ANTI_ALIAS_FLAG = 1;
  public enum Style { FILL, STROKE, FILL_AND_STROKE }
  public enum Cap { BUTT, ROUND, SQUARE } public PathEffect setPathEffect(PathEffect e) { return e; } public PathEffect getPathEffect() { return null; } public Xfermode setXfermode(Xfermode x) { return x; } public Xfermode getXfermode() { return null; } public enum Join { MITER, ROUND, BEVEL } public void setStrokeJoin(Join j) {} public Join getStrokeJoin() { return null; }
  public enum Align { LEFT, CENTER, RIGHT }
  public Paint() {} public Paint(int flags) {}
  public void setStyle(Style s) {} public Style getStyle() { return null; }
  public void setStrokeCap(Cap c) {} public Cap getStrokeCap() { return null; }
  public void setStrokeWidth(float w) {} public float getStrokeWidth() { return 0; }
  public void setColor(int c) {} public int getColor() { return 0; }
  public void setAlpha(int a) {} public int getAlpha() { return 0; }
  public void setAntiAlias(boolean b) {} public boolean isAntiAlias() { return false; }
  public void setFilterBitmap(boolean b) {} public boolean isFilterBitmap() { return false; }
  public void setDither(boolean b) {} public boolean isDither() { return false; }
  public void setTextAlign(Align a) {} public Align getTextAlign() { return null; }
  public void setTextSize(float s) {} public float getTextSize() { return 0; }
  public Typeface setTypeface(Typeface t) { return t; } public Typeface getTypeface() { return null; }
  public void setLetterSpacing(float s) {} public float getLetterSpacing() { return 0; }
  public float measureText(String s) { return 0; }
  public ColorFilter setColorFilter(ColorFilter f) { return f; } public ColorFilter getColorFilter() { return null; }
  public Shader setShader(Shader s) { return s; } public Shader getShader() { return null; }
  public float ascent() { return 0; } public float descent() { return 0; }
  public void setShadowLayer(float r, float dx, float dy, int c) {} public void clearShadowLayer() {}
}
