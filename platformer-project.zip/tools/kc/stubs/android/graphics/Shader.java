package android.graphics;
public class Shader { public enum TileMode { CLAMP, REPEAT, MIRROR } public void setLocalMatrix(Matrix m) {} }
