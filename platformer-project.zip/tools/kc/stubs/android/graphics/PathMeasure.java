package android.graphics;
public class PathMeasure { public PathMeasure() {} public void setPath(Path p, boolean f) {} public float getLength() { return 0f; } public boolean getSegment(float a, float b, Path d, boolean m) { return true; } public boolean getPosTan(float d, float[] pos, float[] tan) { return true; } }
