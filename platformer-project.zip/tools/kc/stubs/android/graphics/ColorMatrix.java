package android.graphics;
public class ColorMatrix { public void setSaturation(float s) {} public void setScale(float r, float g, float b, float a) {} }
