package android.graphics;
public final class Rect { public int left, top, right, bottom;
  public Rect() {} public Rect(int l, int t, int r, int b) { left = l; top = t; right = r; bottom = b; }
  public void set(int l, int t, int r, int b) { left = l; top = t; right = r; bottom = b; }
  public boolean contains(int x, int y) { return x >= left && x < right && y >= top && y < bottom; }
  public final int width() { return right - left; } public final int height() { return bottom - top; } }
