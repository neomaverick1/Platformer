package android.graphics;
public class LightingColorFilter extends ColorFilter { public LightingColorFilter(int mul, int add) {} }
