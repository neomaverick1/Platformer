package android.graphics;
public class BitmapFactory {
  public static class Options { public boolean inScaled = true; public Bitmap.Config inPreferredConfig; }
  public static Bitmap decodeResource(android.content.res.Resources r, int id, Options o) { return null; }
  public static Bitmap decodeResource(android.content.res.Resources r, int id) { return null; }
}
