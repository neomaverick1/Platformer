package android.graphics;
public class SweepGradient extends Shader { public SweepGradient(float x, float y, int[] c, float[] p) {} }
