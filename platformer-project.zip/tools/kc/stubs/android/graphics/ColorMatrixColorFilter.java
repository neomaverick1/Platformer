package android.graphics;
public class ColorMatrixColorFilter extends ColorFilter { public ColorMatrixColorFilter(ColorMatrix m) {} }
