
package android.graphics;
public class RectF { public float left, top, right, bottom; public RectF() {} public RectF(float l, float t, float r, float b) {}
  public final void set(float l, float t, float r, float b) {} public final float width() { return 0; } public final float height() { return 0; }
  public final float centerX() { return 0; } public final float centerY() { return 0; } }
