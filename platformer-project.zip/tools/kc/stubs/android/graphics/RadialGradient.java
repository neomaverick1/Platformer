package android.graphics;
public class RadialGradient extends Shader { public RadialGradient(float x, float y, float r, int[] c, float[] s, Shader.TileMode m) {} }
