package android.graphics;
public class Bitmap {
  public enum Config { ALPHA_8, RGB_565, ARGB_4444, ARGB_8888 }
  public static Bitmap createBitmap(int w, int h, Config c) { return new Bitmap(); }
  public int getWidth() { return 0; } public int getHeight() { return 0; }
  public void setPixels(int[] p, int off, int stride, int x, int y, int w, int h) {}
  public void eraseColor(int c) {} public void recycle() {}
}
