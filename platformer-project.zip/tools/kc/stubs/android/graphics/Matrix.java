package android.graphics;
public class Matrix { public void setRotate(float d, float px, float py) {} public void setTranslate(float x, float y) {} }
