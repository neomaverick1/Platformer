package android.content.pm;
public class ServiceInfo { public static final int FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK = 2; public static final int FOREGROUND_SERVICE_TYPE_SPECIAL_USE = 1073741824; }
