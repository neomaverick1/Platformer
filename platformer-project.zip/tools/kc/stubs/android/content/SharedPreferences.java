
package android.content;
public interface SharedPreferences {
  String getString(String k, String d); int getInt(String k, int d); long getLong(String k, long d); float getFloat(String k, float d);
  boolean getBoolean(String k, boolean d); Editor edit(); boolean contains(String k); java.util.Set<String> getStringSet(String k, java.util.Set<String> d);
  interface Editor {
    Editor putString(String k, String v); Editor putInt(String k, int v); Editor putLong(String k, long v); Editor putFloat(String k, float v);
    Editor putBoolean(String k, boolean v); Editor putStringSet(String k, java.util.Set<String> v); Editor remove(String k); Editor clear(); boolean commit(); void apply();
  }
}
