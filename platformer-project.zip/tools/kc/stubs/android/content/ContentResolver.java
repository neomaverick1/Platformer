
package android.content;
import android.net.Uri;
import android.database.Cursor;
public abstract class ContentResolver {
  public void takePersistableUriPermission(Uri u, int f) {}
  public final Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
}
