
package android.content;
import android.content.res.Resources;
public abstract class Context {
  public static final int MODE_PRIVATE = 0;
  public static final String VIBRATOR_SERVICE = "vibrator";
  public static final String VIBRATOR_MANAGER_SERVICE = "vibrator_manager";
  public SharedPreferences getSharedPreferences(String n, int m) { return null; }
  public <T> T getSystemService(Class<T> c) { return null; }
  public Object getSystemService(String n) { return null; }
  public Resources getResources() { return null; }
  public String getPackageName() { return null; }
  public void startActivity(Intent i) {}
  public ComponentName startService(Intent i) { return null; }
  public ComponentName startForegroundService(Intent i) { return null; }
  public boolean stopService(Intent i) { return false; }
  public ContentResolver getContentResolver() { return null; }
  public java.io.File getFilesDir() { return null; }
  public android.content.pm.PackageManager getPackageManager() { return null; }
  public Context getApplicationContext() { return null; }
  public final String getString(int id) { return null; }
}
