
package android.content.res;
import android.util.DisplayMetrics;
public class Resources { public DisplayMetrics getDisplayMetrics() { return null; } public android.graphics.Typeface getFont(int id) { return null; } public int getIdentifier(String n, String t, String p) { return 0; } public int getDimensionPixelSize(int id) { return 0; } }
