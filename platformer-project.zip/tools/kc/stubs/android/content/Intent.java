
package android.content;
import android.net.Uri;
import android.os.Bundle;
public class Intent {
  public static final int FLAG_ACTIVITY_NEW_TASK = 1, FLAG_ACTIVITY_CLEAR_TOP = 2, FLAG_ACTIVITY_SINGLE_TOP = 4, FLAG_ACTIVITY_NO_USER_ACTION = 8, FLAG_GRANT_READ_URI_PERMISSION = 16;
  public Intent() {}
  public Intent(Context c, Class<?> cls) {}
  public Intent(String action) {}
  public Intent(String action, Uri uri) {}
  public Intent putExtra(String k, int v) { return this; } @Deprecated public <T extends android.os.Parcelable> T getParcelableExtra(String k) { return null; } public Intent putExtra(String k, CharSequence v) { return this; }
  public Intent putExtra(String k, boolean v) { return this; }
  public Intent putExtra(String k, long v) { return this; }
  public Intent putExtra(String k, String v) { return this; }
  public int getIntExtra(String k, int d) { return d; }
  public boolean getBooleanExtra(String k, boolean d) { return d; }
  public boolean hasExtra(String k) { return false; } public String getStringExtra(String k) { return null; }
  public Intent setAction(String a) { return this; }
  public String getAction() { return null; }
  public Intent addFlags(int f) { return this; }
}
