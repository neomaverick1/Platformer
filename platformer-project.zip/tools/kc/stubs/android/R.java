
package android;
public final class R { public static final class attr { public static final int progressBarStyleHorizontal = 2; } public static final class layout { public static final int simple_spinner_dropdown_item = 1; } }
