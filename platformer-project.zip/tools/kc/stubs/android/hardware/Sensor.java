package android.hardware;
public final class Sensor { public static final int TYPE_ACCELEROMETER = 1; }
