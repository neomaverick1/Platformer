package android.hardware;
public abstract class SensorManager { public static final float GRAVITY_EARTH = 9.80665f; public static final int SENSOR_DELAY_GAME = 1;
 public Sensor getDefaultSensor(int t) { return null; } public boolean registerListener(SensorEventListener l, Sensor s, int d) { return true; } public void unregisterListener(SensorEventListener l) {} }
