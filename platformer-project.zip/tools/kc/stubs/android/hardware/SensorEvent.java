package android.hardware;
public class SensorEvent { public final float[] values = new float[3]; }
