
package android.provider;
import android.content.Context;
public final class Settings {
  public static final String ACTION_APPLICATION_DETAILS_SETTINGS = "a", ACTION_REQUEST_SCHEDULE_EXACT_ALARM = "b",
    ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT = "c", ACTION_MANAGE_OVERLAY_PERMISSION = "d";
  public static boolean canDrawOverlays(Context c) { return false; } }
