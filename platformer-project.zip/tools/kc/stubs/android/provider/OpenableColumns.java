package android.provider;
public interface OpenableColumns { String DISPLAY_NAME = "_display_name"; }
