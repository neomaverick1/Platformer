
package android.provider;
import android.net.Uri;
public final class MediaStore { public static final class Audio { public static final class Media {
  public static final Uri EXTERNAL_CONTENT_URI = null; public static final String _ID = "_id", IS_MUSIC = "is_music"; } } }
