package android.animation;
public interface TimeInterpolator { float getInterpolation(float i); }
