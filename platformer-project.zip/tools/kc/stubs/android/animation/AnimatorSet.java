package android.animation;
public final class AnimatorSet extends Animator { public AnimatorSet() {} public void playTogether(Animator... a) {} public AnimatorSet setDuration(long d) { return this; } public long getDuration() { return 0; } }
