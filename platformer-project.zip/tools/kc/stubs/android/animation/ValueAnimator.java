
package android.animation;
public class ValueAnimator extends Animator { public void setStartDelay(long d) {} public long getStartDelay() { return 0; }
  public static ValueAnimator ofInt(int... v) { return null; } public static ValueAnimator ofFloat(float... v) { return null; }
  public static final int REVERSE = 2, INFINITE = -1; public void setRepeatMode(int m) {} public int getRepeatMode() { return 0; } public void setRepeatCount(int c) {} public int getRepeatCount() { return 0; } public void cancel() {}
  public void setInterpolator(TimeInterpolator i) {} public TimeInterpolator getInterpolator() { return null; }
  public static ValueAnimator ofObject(TypeEvaluator e, Object... v) { return null; }
  public ValueAnimator setDuration(long d) { return this; } public long getDuration() { return 0; }
  public Object getAnimatedValue() { return null; }
  public void addUpdateListener(AnimatorUpdateListener l) {}
  public interface AnimatorUpdateListener { void onAnimationUpdate(ValueAnimator a); } }
