package android.animation;
public class ArgbEvaluator implements TypeEvaluator { public Object evaluate(float f, Object a, Object b) { return null; } }
