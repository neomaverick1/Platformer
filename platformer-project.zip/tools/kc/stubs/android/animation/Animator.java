package android.animation;
public abstract class Animator { public void start() {} }
