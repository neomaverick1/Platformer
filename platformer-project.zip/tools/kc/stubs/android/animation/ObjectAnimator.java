
package android.animation;
public final class ObjectAnimator extends ValueAnimator {
  public static ObjectAnimator ofFloat(Object t, String p, float... v) { return null; }
  public ObjectAnimator setDuration(long d) { return this; } }
