package com.neomaverick.platformer;
public final class R {
  public static final class drawable {
    public static final int bg_clouds_far = 2130706433;
    public static final int bg_clouds_near = 2130706434;
    public static final int bg_hills_far = 2130706435;
    public static final int bg_hills_near = 2130706436;
    public static final int bg_mountains = 2130706437;
    public static final int bg_sky = 2130706438;
    public static final int bg_sun = 2130706439;
    public static final int buttons = 2130706440;
    public static final int enemies = 2130706441;
    public static final int font = 2130706442;
    public static final int hero = 2130706443;
    public static final int ic_launcher_bg = 2130706444;
    public static final int ic_launcher_fg = 2130706445;
    public static final int objects = 2130706446;
    public static final int sprites = 2130706447;
    public static final int tiles = 2130706448;
    public static final int title_font = 2130706449;
  }
  public static final class mipmap {
    public static final int ic_launcher = 2130706450;
  }
  public static final class raw {
    public static final int jingle_clear = 2130706451;
    public static final int jingle_die = 2130706452;
    public static final int music_hills = 2130706453;
    public static final int music_star = 2130706454;
    public static final int sfx_appear = 2130706455;
    public static final int sfx_break = 2130706456;
    public static final int sfx_bump = 2130706457;
    public static final int sfx_checkpoint = 2130706458;
    public static final int sfx_coin = 2130706459;
    public static final int sfx_djump = 2130706460;
    public static final int sfx_fire = 2130706461;
    public static final int sfx_gem = 2130706462;
    public static final int sfx_heart = 2130706463;
    public static final int sfx_hurt = 2130706464;
    public static final int sfx_jump = 2130706465;
    public static final int sfx_kick = 2130706466;
    public static final int sfx_land = 2130706467;
    public static final int sfx_pause = 2130706468;
    public static final int sfx_pop = 2130706469;
    public static final int sfx_portal = 2130706470;
    public static final int sfx_powerup = 2130706471;
    public static final int sfx_spring = 2130706472;
    public static final int sfx_stomp = 2130706473;
  }
  public static final class style {
    public static final int Theme_Platformer = 2130706474;
  }
  public static final class string {
    public static final int app_name = 2130706475;
  }
}
