
package com.google.android.material.textfield;
public class TextInputLayout extends android.widget.LinearLayout { public TextInputLayout(android.content.Context c) { super(c); }
  public void setError(CharSequence e) {} public CharSequence getError() { return null; } }
