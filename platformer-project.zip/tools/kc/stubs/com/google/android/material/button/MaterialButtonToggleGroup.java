
package com.google.android.material.button;
import android.content.Context; import java.util.List;
public class MaterialButtonToggleGroup extends android.widget.LinearLayout { public MaterialButtonToggleGroup(Context c) { super(c); }
  public void check(int id) {} public int getCheckedButtonId() { return 0; } public List<Integer> getCheckedButtonIds() { return null; }
  public void addOnButtonCheckedListener(OnButtonCheckedListener l) {}
  public interface OnButtonCheckedListener { void onButtonChecked(MaterialButtonToggleGroup g, int id, boolean c); } }
