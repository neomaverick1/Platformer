package com.google.android.material.checkbox;
public class MaterialCheckBox extends android.widget.CompoundButton { public MaterialCheckBox(android.content.Context c) { super(c); } }
