
package com.google.android.material.bottomnavigation;
public class BottomNavigationView extends android.widget.FrameLayout { public BottomNavigationView(android.content.Context c) { super(c); }
  public int getSelectedItemId() { return 0; } public void setSelectedItemId(int id) {}
  public void setOnItemSelectedListener(OnItemSelectedListener l) {}
  public interface OnItemSelectedListener { boolean onNavigationItemSelected(android.view.MenuItem item); } }
