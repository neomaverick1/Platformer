package com.google.android.material.dialog;
import android.content.Context; import android.content.DialogInterface;
public class MaterialAlertDialogBuilder { public MaterialAlertDialogBuilder(Context c) {}
  public MaterialAlertDialogBuilder setTitle(CharSequence t) { return this; } public MaterialAlertDialogBuilder setMessage(CharSequence m) { return this; }
  public MaterialAlertDialogBuilder setPositiveButton(CharSequence t, DialogInterface.OnClickListener l) { return this; }
  public MaterialAlertDialogBuilder setNegativeButton(CharSequence t, DialogInterface.OnClickListener l) { return this; }
  public androidx.appcompat.app.AlertDialog show() { return null; } public MaterialAlertDialogBuilder setSingleChoiceItems(CharSequence[] items, int checked, DialogInterface.OnClickListener l) { return this; } public MaterialAlertDialogBuilder setOnDismissListener(DialogInterface.OnDismissListener l) { return this; } }
