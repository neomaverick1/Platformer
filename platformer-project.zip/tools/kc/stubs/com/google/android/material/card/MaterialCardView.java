
package com.google.android.material.card;
public class MaterialCardView extends android.widget.FrameLayout { public MaterialCardView(android.content.Context c) { super(c); }
  public void setCardBackgroundColor(int c) {} }
