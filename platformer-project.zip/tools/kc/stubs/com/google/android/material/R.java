package com.google.android.material;
public final class R { public static final class attr { public static final int materialButtonOutlinedStyle = 1; } }
