package com.google.android.material.textfield;
public class TextInputEditText extends android.widget.EditText { public TextInputEditText(android.content.Context c) { super(c); } }
