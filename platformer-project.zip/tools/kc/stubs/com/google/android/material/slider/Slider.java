
package com.google.android.material.slider;
public class Slider extends android.view.View { public Slider(android.content.Context c) { super(c); }
  public float getValue() { return 0; } public void setValue(float v) {}
  public float getValueFrom() { return 0; } public void setValueFrom(float v) {} public float getValueTo() { return 0; } public void setValueTo(float v) {}
  public float getStepSize() { return 0; } public void setStepSize(float v) {}
  public android.content.res.ColorStateList getTrackActiveTintList() { return null; } public void setTrackActiveTintList(android.content.res.ColorStateList c) {}
  public android.content.res.ColorStateList getThumbTintList() { return null; } public void setThumbTintList(android.content.res.ColorStateList c) {}
  public void addOnChangeListener(OnChangeListener l) {} public interface OnSliderTouchListener { void onStartTrackingTouch(Slider s); void onStopTrackingTouch(Slider s); } public void addOnSliderTouchListener(OnSliderTouchListener l) {}
  public interface OnChangeListener { void onValueChange(Slider s, float v, boolean u); } }
