package com.google.android.material.materialswitch;
public class MaterialSwitch extends android.widget.CompoundButton { public MaterialSwitch(android.content.Context c) { super(c); } }
