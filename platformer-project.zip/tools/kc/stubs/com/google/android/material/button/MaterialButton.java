
package com.google.android.material.button;
import android.content.Context;
public class MaterialButton extends android.widget.Button { public MaterialButton(Context c) { super(c); }
  public MaterialButton(Context c, android.util.AttributeSet a, int s) { super(c, a, s); } }
