
package androidx.recyclerview.widget;
import android.content.Context; import android.view.*;
public class RecyclerView extends ViewGroup { public RecyclerView(Context c) { super(c); }
  public void setLayoutManager(LayoutManager m) {} public LayoutManager getLayoutManager() { return null; }
  public void setAdapter(Adapter a) {} public Adapter getAdapter() { return null; }
  public abstract static class LayoutManager {}
  public abstract static class ViewHolder { public final View itemView; public ViewHolder(View v) { itemView = v; } }
  public abstract static class Adapter<VH extends ViewHolder> {
    public abstract VH onCreateViewHolder(ViewGroup p, int t); public abstract void onBindViewHolder(VH h, int pos);
    public abstract int getItemCount(); public final void notifyDataSetChanged() {} } }
