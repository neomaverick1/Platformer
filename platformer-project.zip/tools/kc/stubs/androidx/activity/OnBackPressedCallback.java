
package androidx.activity;
public abstract class OnBackPressedCallback { public OnBackPressedCallback(boolean e) {} public abstract void handleOnBackPressed(); }
