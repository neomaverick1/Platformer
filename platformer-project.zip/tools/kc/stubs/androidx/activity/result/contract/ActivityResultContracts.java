
package androidx.activity.result.contract;
import android.net.Uri;
public final class ActivityResultContracts {
  public static final class RequestPermission extends ActivityResultContract<String, Boolean> { public RequestPermission() {} }
  public static final class StartActivityForResult extends ActivityResultContract<android.content.Intent, androidx.activity.result.ActivityResult> { public StartActivityForResult() {} }
  public static class OpenDocument extends ActivityResultContract<String[], Uri> { public OpenDocument() {} } }
