
package androidx.activity;
import androidx.activity.result.*; import androidx.activity.result.contract.ActivityResultContract;
public class ComponentActivity extends android.app.Activity implements androidx.lifecycle.LifecycleOwner {
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() { return null; }
  public final <I, O> ActivityResultLauncher<I> registerForActivityResult(ActivityResultContract<I, O> c, ActivityResultCallback<O> cb) { return null; }
  @Override protected void onNewIntent(android.content.Intent i) {} }
