
package androidx.activity;
public final class OnBackPressedDispatcher { public void addCallback(androidx.lifecycle.LifecycleOwner o, OnBackPressedCallback c) {} }
