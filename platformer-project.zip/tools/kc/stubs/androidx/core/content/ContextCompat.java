
package androidx.core.content;
import android.content.*;
public class ContextCompat { public static int checkSelfPermission(Context c, String p) { return 0; }
  public static void startForegroundService(Context c, Intent i) {} }
