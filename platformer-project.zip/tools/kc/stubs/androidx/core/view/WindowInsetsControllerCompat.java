
package androidx.core.view;
public final class WindowInsetsControllerCompat { public WindowInsetsControllerCompat(android.view.Window w, android.view.View v) {}
  public boolean isAppearanceLightStatusBars() { return false; } public void setAppearanceLightStatusBars(boolean b) {}
  public boolean isAppearanceLightNavigationBars() { return false; } public void setAppearanceLightNavigationBars(boolean b) {} }
