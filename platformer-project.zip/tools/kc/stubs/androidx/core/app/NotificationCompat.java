
package androidx.core.app;
import android.app.*; import android.content.Context;
public class NotificationCompat {
  public static final String CATEGORY_ALARM = "alarm", CATEGORY_PROGRESS = "progress";
  public static final int PRIORITY_MAX = 2, VISIBILITY_PUBLIC = 1;
  public static class Builder {
    public Builder(Context c, String channel) {}
    public Builder setSmallIcon(int i) { return this; } public Builder setContentTitle(CharSequence t) { return this; }
    public Builder setContentText(CharSequence t) { return this; } public Builder setSubText(CharSequence t) { return this; }
    public Builder setCategory(String c) { return this; } public Builder setPriority(int p) { return this; }
    public Builder setVisibility(int v) { return this; } public Builder setOngoing(boolean b) { return this; }
    public Builder setAutoCancel(boolean b) { return this; } public Builder setContentIntent(PendingIntent p) { return this; }
    public Builder setFullScreenIntent(PendingIntent p, boolean h) { return this; } public Builder setSilent(boolean s) { return this; }
    public Builder setOnlyAlertOnce(boolean b) { return this; } public Builder setUsesChronometer(boolean b) { return this; }
    public Builder setChronometerCountDown(boolean b) { return this; } public Builder setShowWhen(boolean b) { return this; }
    public Builder setWhen(long w) { return this; }
    public Builder addAction(int icon, CharSequence title, PendingIntent p) { return this; }
    public Notification build() { return null; } } }
