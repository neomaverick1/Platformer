package androidx.appcompat.app;
public class AlertDialog implements android.content.DialogInterface { public android.widget.Button getButton(int which) { return null; } public void dismiss() {} }
