"""The hero: a small adventurer with a big head, a red headband (its ribbon tails are
animated in-game), a blue jacket and red boots. Built from a hand-drawn head plus limbs
posed per frame, then given a selective outline."""
import math
from px import Pix, hexc, mix, shade

C = 32  # cell size

PAL = {
    'S': hexc('#FFE6CC'), 's': hexc('#F7C79E'), 'z': hexc('#DE9A6C'), 'Z': hexc('#B5704E'),
    'H': hexc('#9C6A44'), 'h': hexc('#6B4129'), 'd': hexc('#47291A'), 'D': hexc('#2A170F'),
    'R': hexc('#FF8A78'), 'r': hexc('#EC3B3E'), 'q': hexc('#A81E2B'),
    'e': hexc('#1B1630'), 'w': hexc('#FFFFFF'), 'm': hexc('#A33A3A'), 'c': hexc('#FF9E8E'),
    'o': hexc('#3B1F18'),
}
JACKET = (hexc('#86B9FF'), hexc('#3F82EC'), hexc('#2A5CC0'), hexc('#1A3880'))  # hi, base, shade, line
SHIRT = hexc('#F6F2E4')
BELT = (hexc('#FFE08A'), hexc('#CC9A30'), hexc('#7A5418'))
PANTS = (hexc('#6A68A0'), hexc('#4A4778'), hexc('#2E2B52'), hexc('#1C1A36'))
BOOT = (hexc('#FF8F5E'), hexc('#D4502F'), hexc('#8E2E1E'), hexc('#4E1810'))
SKIN = (PAL['S'], PAL['s'], PAL['z'], PAL['o'])

HEAD = [
    ".......D....DD....",
    "......DhD..DHhD...",
    "....DDDhhDDDHhhDD.",
    "...DhhhhhHhhhHHhhD",
    "..DhhhhhhHHHHhhhhD",
    ".DhhhhhhhhHHhhhhhD",
    ".DhhhhhhhhhhhhhhhD",
    "DdhhhhhhhhhhhhhhhD",
    "DdqrrrrrrrrrrrrrrD",
    "DdqRRRRRRRRRRRRRrD",
    ".DhdzhsshssshhshsD",
    ".Dhdzssssssssssss.",
    ".DhdzssewSssseweS.",
    "..DdzsseessssseesD",
    "..Ddzsseessssseez.",
    "...DzzscsssssmsscD",
    "....DZzzssssssszD.",
    "......DZZZZZZZD...",
]
# head grid is 18 x 18; its (0,0) goes at cell (7, 0)


def make_head(kind='normal'):
    rows = [r.ljust(18, '.') for r in HEAD]
    if kind == 'blink':
        rows[12] = ".DhdzssssSssssssS."
        rows[13] = "..DdzsssssssssssssD"[:18]
        rows[14] = "..DdzseesssssseesD"[:18]
    elif kind == 'hurt':
        rows[12] = ".DhdzsesSssssseSs."
        rows[13] = "..DdzssesssssesssD"
        rows[14] = "..DdzsesssssssesS."
        rows[15] = "...DzzscssssmmsscD"
    elif kind == 'happy':
        rows[12] = ".DhdzssssSssssssS."
        rows[13] = "..DdzseessssseesD."
        rows[14] = "..Ddzesseessessez."
        rows[15] = "...DzzscssmmmsscD."
    p = Pix(18, 18)
    p.from_rows(rows, PAL)
    return p


def seg(p, x0, y0, x1, y1, r, col, line):
    p.thick(x0, y0, x1, y1, r + 0.75, line)
    p.thick(x0, y0, x1, y1, r, col)


def limb_pts(x0, y0, a1, l1, a2, l2):
    r1, r2 = math.radians(a1), math.radians(a2)
    x1, y1 = x0 + math.sin(r1) * l1, y0 + math.cos(r1) * l1
    x2, y2 = x1 + math.sin(r2) * l2, y1 + math.cos(r2) * l2
    return x1, y1, x2, y2


def draw_leg(p, hx, hy, th, sh, front):
    x1, y1, x2, y2 = limb_pts(hx, hy, th, 3.0, sh, 2.9)
    pc = PANTS[1] if front else PANTS[2]
    seg(p, hx, hy, x1, y1, 1.35, pc, PANTS[3])
    seg(p, x1, y1, x2, y2, 1.25, pc, PANTS[3])
    # boot: a rounded block pointing the way the shin points (forward = right)
    bc = BOOT if front else (BOOT[1], BOOT[2], BOOT[3], BOOT[3])
    fwd = math.radians(sh)
    dx, dy = math.cos(fwd), -math.sin(fwd)
    cx, cy = x2 + dx * 0.8, y2 + 1.0
    for i in range(-2, 4):
        for j in range(-1, 2):
            x = cx + dx * i * 0.9 + (-dy) * j * 0.0
            y = cy + dy * i * 0.9 + j
            col = bc[1]
            if j == -1:
                col = bc[0] if i < 2 else bc[1]
            if j == 1:
                col = bc[2]
            p.put(int(round(x)), int(round(y)), col)
    return x2, y2


def draw_arm(p, sx, sy, a1, a2, front):
    x1, y1, x2, y2 = limb_pts(sx, sy, a1, 3.0, a2, 2.8)
    col = JACKET[1] if front else JACKET[2]
    seg(p, sx, sy, x1, y1, 1.15, col, JACKET[3])
    seg(p, x1, y1, x2, y2, 1.05, col, JACKET[3])
    # mitten hand
    p.disc(x2, y2, 1.9, PAL['o'])
    p.disc(x2, y2, 1.25, SKIN[1] if front else SKIN[2])
    if front:
        p.put(int(x2 - 0.5), int(y2 - 0.6), SKIN[0])


def torso(p, x, y, lean):
    """Rounded jacket torso 10 x 7 at (x, y)."""
    hi, base, sh, line = JACKET
    rows = [
        "..llllll..",
        ".lbbbbsbbl",
        "lbbbbbswbl",
        "lsbbbbswhl",
        "lsbbbbswhl",
        "lyyyyyYyyl",
        ".lpppppppl",
    ]
    pal = {'l': line, 'b': base, 's': sh, 'h': hi, 'w': SHIRT, 'y': BELT[1], 'Y': BELT[0], 'p': PANTS[1]}
    for j, row in enumerate(rows):
        off = lean if j < 3 else 0
        for i, ch in enumerate(row):
            if ch != '.':
                p.put(x + i + off, y + j, pal[ch])


def frame(pose):
    p = Pix(C, C)
    bob = pose.get('bob', 0)
    hipy = 23 + bob
    shy = 18.5 + bob
    legs, arms = pose['legs'], pose['arms']
    def raised(a):
        return abs(a[0]) > 100
    # back limbs
    draw_arm(p, 13.5, shy, arms[1][0], arms[1][1], False)
    draw_leg(p, 14.5, hipy, legs[1][0], legs[1][1], False)
    if raised(arms[0]):
        draw_arm(p, 17.5, shy, arms[0][0], arms[0][1], True)
    # torso
    torso(p, 11, 17 + bob, pose.get('lean', 0))
    # front leg
    draw_leg(p, 17, hipy, legs[0][0], legs[0][1], True)
    # head
    h = make_head(pose.get('head', 'normal'))
    p.blit(h, 7 + pose.get('hx', 0), 0 + bob + pose.get('hy', 0))
    # front arm
    if not raised(arms[0]):
        draw_arm(p, 17.5, shy, arms[0][0], arms[0][1], True)
    p.outline(darken=0.75)
    return p


def run_pose(t):
    ph = t / 8 * 2 * math.pi
    s, c = math.sin(ph), math.cos(ph)
    ft, bt = 48 * s, -48 * s
    fs = ft - (10 + 70 * max(0.0, -c))
    bs = bt - (10 + 70 * max(0.0, c))
    return {
        'bob': 1 - int(round(abs(s))), 'lean': 1, 'hx': 1,
        'legs': [(ft, fs), (bt, bs)],
        'arms': [(-55 * s, -55 * s - 70 * 0 + 60), (55 * s, 55 * s + 60)],
    }


POSES = [
    ('idle0', {'bob': 0, 'legs': [(8, 0), (-8, 0)], 'arms': [(-12, 8), (14, 22)]}),
    ('idle1', {'bob': 0, 'legs': [(8, 0), (-8, 0)], 'arms': [(-12, 8), (14, 22)]}),
    ('idle2', {'bob': 1, 'legs': [(10, -4), (-10, 4)], 'arms': [(-14, 10), (16, 24)]}),
    ('idle3', {'bob': 1, 'legs': [(10, -4), (-10, 4)], 'arms': [(-14, 10), (16, 24)]}),
    ('blink', {'bob': 0, 'legs': [(8, 0), (-8, 0)], 'arms': [(-12, 8), (14, 22)], 'head': 'blink'}),
] + [('run%d' % t, run_pose(t)) for t in range(8)] + [
    ('skid', {'bob': 1, 'lean': -1, 'hx': -1, 'legs': [(45, 30), (-10, -30)], 'arms': [(-70, -40), (60, 90)]}),
    ('jump', {'bob': -1, 'hy': -1, 'legs': [(70, -20), (-20, 15)], 'arms': [(75, 45), (-70, -40)]}),
    ('peak', {'bob': -1, 'legs': [(55, -40), (15, -45)], 'arms': [(95, 70), (-95, -70)]}),
    ('fall0', {'bob': 0, 'legs': [(25, 10), (-30, -10)], 'arms': [(98, 88), (-98, -88)]}),
    ('fall1', {'bob': 0, 'legs': [(32, 14), (-34, -16)], 'arms': [(92, 100), (-92, -100)]}),
    ('land', {'bob': 3, 'legs': [(60, -40), (-40, 40)], 'arms': [(-40, 10), (40, 70)]}),
    ('tuck', {'bob': 4, 'hy': 1, 'legs': [(95, -70), (75, -80)], 'arms': [(70, 130), (50, 120)]}),
    ('hurt', {'bob': 0, 'lean': -1, 'hx': -1, 'legs': [(-25, -5), (20, 30)], 'arms': [(90, 60), (-85, -120)], 'head': 'hurt'}),
    ('throw0', {'bob': 0, 'legs': [(12, 0), (-14, 0)], 'arms': [(-80, -50), (20, 40)]}),
    ('throw1', {'bob': 0, 'lean': 1, 'hx': 1, 'legs': [(14, 0), (-16, 0)], 'arms': [(88, 88), (30, 50)]}),
    ('win0', {'bob': -1, 'legs': [(10, 0), (-10, 0)], 'arms': [(95, 140), (-60, -20)], 'head': 'happy'}),
    ('win1', {'bob': -2, 'legs': [(30, -30), (-15, 0)], 'arms': [(98, 150), (-70, -30)], 'head': 'happy'}),
]


def build():
    names = [n for n, _ in POSES]
    frames = [frame(p) for _, p in POSES]
    return names, frames
