"""Tiny pixel-art toolkit: crisp (non anti-aliased) drawing on RGBA numpy canvases."""
import math
import random
import numpy as np
from PIL import Image


def hexc(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def mix(c1, c2, t):
    return tuple(int(round(c1[i] + (c2[i] - c1[i]) * t)) for i in range(4))


def shade(c, k):
    """k < 0 darker (towards a cool shadow), k > 0 lighter (towards a warm light)."""
    if k < 0:
        target = (24, 20, 48, c[3])
        return mix(c, target, -k)
    target = (255, 250, 230, c[3])
    return mix(c, target, k)


class Pix:
    def __init__(self, w, h, fill=(0, 0, 0, 0)):
        self.w, self.h = w, h
        self.a = np.zeros((h, w, 4), dtype=np.uint8)
        if fill[3]:
            self.a[:, :] = fill

    # ---------- basic ----------
    def put(self, x, y, c):
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            if c[3] == 255 or self.a[y, x, 3] == 0:
                self.a[y, x] = c
            else:
                a = c[3] / 255.0
                self.a[y, x, :3] = (np.array(c[:3]) * a + self.a[y, x, :3] * (1 - a)).astype(np.uint8)
                self.a[y, x, 3] = max(self.a[y, x, 3], c[3])

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return tuple(int(v) for v in self.a[y, x])
        return (0, 0, 0, 0)

    def rect(self, x0, y0, w, h, c):
        for y in range(int(y0), int(y0 + h)):
            for x in range(int(x0), int(x0 + w)):
                self.put(x, y, c)

    def line(self, x0, y0, x1, y1, c):
        x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            self.put(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy; x0 += sx
            if e2 <= dx:
                err += dx; y0 += sy

    def disc(self, cx, cy, r, c):
        """Filled circle; works with half-pixel centres for even sizes."""
        for y in range(int(math.floor(cy - r - 1)), int(math.ceil(cy + r + 1)) + 1):
            for x in range(int(math.floor(cx - r - 1)), int(math.ceil(cx + r + 1)) + 1):
                if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= r * r:
                    self.put(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(int(math.floor(cy - ry - 1)), int(math.ceil(cy + ry + 1)) + 1):
            for x in range(int(math.floor(cx - rx - 1)), int(math.ceil(cx + rx + 1)) + 1):
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1.0:
                    self.put(x, y, c)

    def poly(self, pts, c):
        ys = [p[1] for p in pts]
        for y in range(int(math.floor(min(ys))), int(math.ceil(max(ys))) + 1):
            yc = y + 0.5
            xs = []
            n = len(pts)
            for i in range(n):
                x1, y1 = pts[i]
                x2, y2 = pts[(i + 1) % n]
                if (y1 <= yc < y2) or (y2 <= yc < y1):
                    xs.append(x1 + (yc - y1) * (x2 - x1) / (y2 - y1))
            xs.sort()
            for k in range(0, len(xs) - 1, 2):
                for x in range(int(math.ceil(xs[k] - 0.5)), int(math.floor(xs[k + 1] - 0.5)) + 1):
                    self.put(x, y, c)

    def thick(self, x0, y0, x1, y1, r, c):
        n = max(1, int(math.hypot(x1 - x0, y1 - y0) * 2))
        for i in range(n + 1):
            t = i / n
            self.disc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, r, c)

    def blit(self, src, x, y, flip=False):
        for sy in range(src.h):
            for sx in range(src.w):
                c = tuple(int(v) for v in src.a[sy, sx])
                if c[3]:
                    dx = (src.w - 1 - sx) if flip else sx
                    self.put(x + dx, y + sy, c)

    def from_rows(self, rows, pal, x=0, y=0):
        """Paint hand-drawn rows: each char is a palette key ('.' = transparent)."""
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch != '.' and ch != ' ':
                    self.put(x + i, y + j, pal[ch])

    # ---------- effects ----------
    def outline(self, color=None, darken=0.62, diagonals=False):
        """Sel-out style outline: each empty pixel touching the sprite gets a dark
        version of the colour it touches (or a fixed colour)."""
        a = self.a
        alpha = a[:, :, 3] > 0
        out = a.copy()
        nb = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        if diagonals:
            nb += [(-1, -1), (1, -1), (-1, 1), (1, 1)]
        for y in range(self.h):
            for x in range(self.w):
                if alpha[y, x]:
                    continue
                touch = None
                for dx, dy in nb:
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < self.w and 0 <= yy < self.h and alpha[yy, xx] and a[yy, xx, 3] > 128:
                        touch = a[yy, xx]
                        break
                if touch is not None:
                    if color is not None:
                        out[y, x] = color
                    else:
                        c = shade(tuple(int(v) for v in touch), -darken)
                        out[y, x] = (c[0], c[1], c[2], 255)
        self.a = out

    def image(self):
        return Image.fromarray(self.a, 'RGBA')

    def copy(self):
        p = Pix(self.w, self.h)
        p.a = self.a.copy()
        return p

    def flipped(self):
        p = Pix(self.w, self.h)
        p.a = self.a[:, ::-1].copy()
        return p


def sheet(cells, cw, ch, cols):
    """Pack a list of Pix (each cw x ch) into one image, row-major."""
    rows = (len(cells) + cols - 1) // cols
    img = Image.new('RGBA', (cw * cols, ch * rows), (0, 0, 0, 0))
    for i, c in enumerate(cells):
        img.paste(c.image(), ((i % cols) * cw, (i // cols) * ch))
    return img


def preview(img, scale, path, bg=(90, 110, 140, 255)):
    big = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    base = Image.new('RGBA', big.size, bg)
    base.alpha_composite(big)
    base.convert('RGB').save(path)
