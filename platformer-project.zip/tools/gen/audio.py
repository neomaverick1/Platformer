"""Original music and sound effects, synthesized with numpy and written as OGG Vorbis."""
import os
import subprocess
import numpy as np

SR = 44100
RAW = '/home/claude/platformer/src/app/src/main/res/raw'
TMP = '/tmp/claude-0/-home-claude/e4d3ecb0-c2d1-5dae-8b8a-6bc6d54a3741/scratchpad/aud'
os.makedirs(RAW, exist_ok=True)
os.makedirs(TMP, exist_ok=True)
rng = np.random.default_rng(7)

NOTE = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}


def freq(n):
    name, octv = n[:-1], int(n[-1])
    m = NOTE[name] + (octv + 1) * 12
    return 440.0 * 2 ** ((m - 69) / 12.0)


def write(name, x, stereo=False, q=4):
    x = np.asarray(x, dtype=np.float64)
    peak = np.max(np.abs(x)) or 1.0
    x = x / peak * 0.92
    wav = os.path.join(TMP, name + '.wav')
    pcm = (x * 32767).astype(np.int16)
    import wave
    with wave.open(wav, 'wb') as w:
        w.setnchannels(2 if stereo else 1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    out = os.path.join(RAW, name + '.ogg')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'libvorbis', '-q:a', str(q), out], check=True)


def env(n, a=0.005, d=0.1, s=0.6, r=0.05, hold=None):
    t = np.arange(n) / SR
    total = n / SR
    hold = total - r if hold is None else hold
    e = np.ones(n)
    e = np.where(t < a, t / a, e)
    dec = (t >= a) & (t < a + d)
    e = np.where(dec, 1 - (1 - s) * (t - a) / d, e)
    e = np.where((t >= a + d) & (t < hold), s, e)
    rel = t >= hold
    e = np.where(rel, s * np.clip(1 - (t - hold) / max(r, 1e-4), 0, 1), e)
    return e


def osc(kind, f, n, duty=0.5, vib=0.0, vibf=5.5, phase0=0.0):
    t = np.arange(n) / SR
    fm = f * (1 + vib * np.sin(2 * np.pi * vibf * t) * np.clip(t / 0.15, 0, 1))
    ph = phase0 + np.cumsum(fm) / SR
    ph = ph % 1.0
    if kind == 'sine':
        return np.sin(2 * np.pi * ph)
    if kind == 'tri':
        return 4 * np.abs(ph - 0.5) - 1
    if kind == 'saw':
        # soft (band-limited-ish) saw: a few harmonics
        out = np.zeros(n)
        for k in range(1, 9):
            out += np.sin(2 * np.pi * k * ph) / k * (0.9 ** k)
        return out * 0.6
    if kind == 'pulse':
        out = np.zeros(n)
        for k in range(1, 12):
            out += (2 / (k * np.pi)) * np.sin(k * np.pi * duty) * np.cos(2 * np.pi * k * ph)
        return out
    raise ValueError(kind)


def lowpass(x, cutoff):
    from scipy.signal import lfilter
    a = np.exp(-2 * np.pi * cutoff / SR)
    return lfilter([1 - a], [1, -a], x)


def noise(n):
    return rng.uniform(-1, 1, n)


# ======================================================================= instruments
def lead(f, dur):
    n = int(dur * SR)
    x = 0.55 * osc('pulse', f, n, duty=0.25, vib=0.006) + 0.45 * osc('saw', f * 1.003, n, vib=0.006)
    x += 0.25 * osc('sine', f * 2, n)
    return x * env(n, a=0.008, d=0.12, s=0.7, r=0.06)


def marimba(f, dur):
    n = int(min(dur, 0.6) * SR)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) * np.exp(-t * 9) + 0.35 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 30)
    return x


def bass(f, dur):
    n = int(dur * SR)
    x = 0.8 * osc('tri', f, n) + 0.35 * osc('pulse', f, n, duty=0.5)
    return x * env(n, a=0.004, d=0.08, s=0.55, r=0.03)


def pad(fs, dur):
    n = int(dur * SR)
    x = np.zeros(n)
    for f in fs:
        x += osc('saw', f, n, vib=0.003, vibf=4.5) + osc('saw', f * 1.006, n)
    x = lowpass(x, 1400)
    return x * env(n, a=0.12, d=0.2, s=0.8, r=0.25)


def kick():
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    f = 50 + 120 * np.exp(-t * 35)
    ph = np.cumsum(f) / SR
    return np.sin(2 * np.pi * ph) * np.exp(-t * 14) * 1.1


def snare():
    n = int(0.18 * SR)
    t = np.arange(n) / SR
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 30)
    nz = noise(n) * np.exp(-t * 22)
    return 0.5 * tone + 0.6 * lowpass(nz, 6000)


def hat(open_=False):
    n = int((0.12 if open_ else 0.04) * SR)
    t = np.arange(n) / SR
    nz = noise(n)
    hp = nz - lowpass(nz, 7000)
    return hp * np.exp(-t * (18 if open_ else 70)) * 0.5


# ======================================================================= music
BPM = 132
E8 = 60.0 / BPM / 2  # one eighth note in seconds

A_MEL = [
    "E5:2 G5:1 E5:1 D5:2 C5:2", "D5:2 B4:1 D5:1 G5:3 R:1", "C5:2 E5:1 A5:1 G5:2 E5:2", "F5:2 E5:1 D5:1 C5:2 A4:2",
    "E5:1 F5:1 G5:2 C6:2 G5:2", "B5:1 A5:1 G5:2 D5:2 B4:2", "A5:2 G5:1 F5:1 E5:2 D5:1 C5:1", "D5:4 G4:2 R:2",
]
A2_MEL = [
    "E5:2 G5:1 E5:1 D5:2 C5:2", "D5:2 B4:1 D5:1 G5:3 R:1", "C5:2 E5:1 A5:1 G5:2 E5:2", "F5:2 A5:1 G5:1 F5:2 E5:2",
    "E5:1 F5:1 G5:2 C6:2 E6:2", "D6:1 C6:1 B5:2 G5:2 D5:2", "F5:2 A5:1 G5:1 F5:2 D5:2", "C5:6 R:2",
]
B_MEL = [
    "A4:1 C5:1 E5:2 A5:2 G5:1 E5:1", "F5:3 E5:1 C5:2 A4:2", "G4:1 C5:1 E5:2 G5:2 E5:1 C5:1", "D5:3 B4:1 G4:4",
    "A4:1 C5:1 E5:1 A5:1 B5:2 C6:2", "A5:2 F5:2 C6:2 A5:2", "D6:2 C6:1 A5:1 F5:2 D5:2", "G5:2 F5:1 D5:1 B4:2 G4:2",
]
A_CH = ['C', 'G', 'Am', 'F', 'C', 'G', 'F', 'G']
A2_CH = ['C', 'G', 'Am', 'F', 'C', 'G', 'F', 'C']
B_CH = ['Am', 'F', 'C', 'G', 'Am', 'F', 'Dm', 'G']
CHORD = {
    'C': ['C', 'E', 'G'], 'G': ['G', 'B', 'D'], 'Am': ['A', 'C', 'E'], 'F': ['F', 'A', 'C'],
    'Dm': ['D', 'F', 'A'], 'Em': ['E', 'G', 'B'],
}


def place(buf, x, at, gain=1.0, pan=0.0):
    i = int(at * SR)
    if i >= buf.shape[0]:
        return
    j = min(buf.shape[0], i + len(x))
    l = (1 - max(0, pan)) * gain
    r = (1 + min(0, pan)) * gain
    buf[i:j, 0] += x[:j - i] * l
    buf[i:j, 1] += x[:j - i] * r


def song(sections, bars_per_loop, tempo_scale=1.0, drums=True, arps=None, name=''):
    e8 = E8 / tempo_scale
    total = bars_per_loop * 8 * e8
    buf = np.zeros((int(total * SR) + SR, 2))
    bar = 0
    for (mel, chords, arp) in sections:
        for k in range(8):
            t0 = bar * 8 * e8
            ch = CHORD[chords[k]]
            root = ch[0]
            # pad
            place(buf, pad([freq(n + '4') for n in ch], 8 * e8), t0, 0.10)
            # bass: root, fifth bounce
            pattern = [(root, 2), (None, 0), (ch[2], 2), (None, 0), (root, 2), (None, 0), (ch[2], 2), (root, 3)]
            for s, (nn, octv) in enumerate(pattern):
                if nn:
                    place(buf, bass(freq(nn + str(octv)), e8 * 0.9), t0 + s * e8, 0.42)
            # melody
            tt = t0
            for tok in mel[k].split():
                nn, d = tok.split(':')
                d = int(d)
                if nn != 'R':
                    place(buf, lead(freq(nn), d * e8 * 0.95), tt, 0.30, pan=-0.1)
                tt += d * e8
            # arpeggio (marimba sixteenths)
            if arp:
                tones = [freq(n + '5') for n in ch] + [freq(ch[0] + '6')]
                for s in range(16):
                    place(buf, marimba(tones[s % 4], e8 / 2), t0 + s * e8 / 2, 0.16, pan=0.35)
            # drums
            if drums:
                for b in range(4):
                    tb = t0 + b * 2 * e8
                    if b in (0, 2):
                        place(buf, kick(), tb, 0.55)
                    else:
                        place(buf, snare(), tb, 0.32)
                    place(buf, hat(), tb, 0.12, pan=0.25)
                    place(buf, hat(b == 3), tb + e8, 0.10, pan=0.25)
                if k == 7:
                    place(buf, kick(), t0 + 5 * e8, 0.45)
                    place(buf, snare(), t0 + 6.5 * e8, 0.18)
                    place(buf, snare(), t0 + 7 * e8, 0.26)
                    place(buf, snare(), t0 + 7.5 * e8, 0.3)
            bar += 1
    n = int(total * SR)
    # wrap the tail (release of the last notes) into the start so the loop is seamless
    tail = buf[n:]
    buf = buf[:n]
    buf[:len(tail)] += tail
    return buf


def master(buf):
    # gentle saturation and a touch of room
    d = int(0.083 * SR)
    wet = np.zeros_like(buf)
    wet[d:] = buf[:-d] * 0.18
    wet[:, [0, 1]] = wet[:, [1, 0]]
    y = np.tanh((buf + wet) * 1.2)
    return y


def music():
    sec = [(A_MEL, A_CH, False), (A2_MEL, A2_CH, True), (B_MEL, B_CH, True)]
    write('music_hills', master(song(sec, 24)), stereo=True, q=4)
    # star power: same tune, faster and brighter, A section with arps only
    star = song([(A_MEL, A_CH, True)], 8, tempo_scale=1.45)
    write('music_star', master(star), stereo=True, q=4)


# ======================================================================= jingles
def jingle(notes, step, name, tail=1.2, arp=True):
    n = int((len(notes) * step + tail) * SR)
    buf = np.zeros((n, 2))
    for i, nn in enumerate(notes):
        if nn == 'R':
            continue
        parts = nn.split('+')
        for p_ in parts:
            d = step * (4 if i == len(notes) - 1 else 1.1)
            place(buf, lead(freq(p_), d), i * step, 0.4)
            if arp:
                place(buf, marimba(freq(p_) * 2, d), i * step, 0.18)
    place(buf, kick(), (len(notes) - 1) * step, 0.4)
    write(name, master(buf), stereo=True)


def jingles():
    jingle(['G4', 'C5', 'E5', 'G5', 'C6', 'R', 'A5', 'C6', 'E6+C6+G5'], 0.13, 'jingle_clear', tail=1.6)
    jingle(['C5', 'B4', 'A#4', 'A4', 'G#4', 'G4+D4+B3'], 0.14, 'jingle_die', tail=0.9, arp=False)


# ======================================================================= sound effects
def sweep(f0, f1, dur, kind='pulse', duty=0.25, curve=1.0, vol_decay=6.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    k = (t / dur) ** curve
    f = f0 * (f1 / f0) ** k
    ph = np.cumsum(f) / SR % 1.0
    if kind == 'pulse':
        x = np.where(ph < duty, 1.0, -1.0) * 0.6
        x = lowpass(x, 9000)
    elif kind == 'sine':
        x = np.sin(2 * np.pi * ph)
    else:
        x = 4 * np.abs(ph - 0.5) - 1
    return x * np.exp(-t * vol_decay)


def tone_seq(fs, step, kind='sine', decay=10.0, harm=0.3):
    out = np.zeros(int((len(fs) * step + 0.3) * SR))
    for i, f in enumerate(fs):
        n = int(0.3 * SR)
        t = np.arange(n) / SR
        x = np.sin(2 * np.pi * f * t) + harm * np.sin(2 * np.pi * f * 2 * t)
        if kind == 'square':
            x = np.sign(np.sin(2 * np.pi * f * t)) * 0.5
            x = lowpass(x, 8000)
        x *= np.exp(-t * decay)
        i0 = int(i * step * SR)
        out[i0:i0 + n] += x
    return out


def mixs(*xs):
    n = max(len(x) for x in xs)
    out = np.zeros(n)
    for x in xs:
        out[:len(x)] += x
    return out


def sfx():
    write('sfx_jump', sweep(260, 620, 0.16, 'pulse', 0.25, 0.6, 8))
    write('sfx_djump', mixs(sweep(420, 980, 0.18, 'pulse', 0.125, 0.5, 7), 0.4 * tone_seq([1568, 2093], 0.05, decay=25)))
    n = int(0.09 * SR)
    t = np.arange(n) / SR
    write('sfx_land', lowpass(noise(n), 900) * np.exp(-t * 40) + 0.4 * np.sin(2 * np.pi * 90 * t) * np.exp(-t * 35))
    write('sfx_coin', tone_seq([988, 1319], 0.07, 'square', decay=9))
    write('sfx_stomp', mixs(sweep(520, 140, 0.16, 'tri', curve=0.7, vol_decay=10), 0.4 * lowpass(noise(int(0.16 * SR)), 2500) * np.exp(-np.arange(int(0.16 * SR)) / SR * 30)))
    write('sfx_hurt', sweep(700, 180, 0.32, 'pulse', 0.5, 1.0, 5) * (1 + 0.5 * np.sin(np.arange(int(0.32 * SR)) / SR * 2 * np.pi * 30)))
    n = int(0.12 * SR)
    t = np.arange(n) / SR
    write('sfx_bump', np.sin(2 * np.pi * (140 * np.exp(-t * 8)) * t) * np.exp(-t * 25) + 0.3 * lowpass(noise(n), 1500) * np.exp(-t * 40))
    write('sfx_appear', sweep(300, 1200, 0.45, 'pulse', 0.25, 1.0, 3) * (0.6 + 0.4 * np.sign(np.sin(np.arange(int(0.45 * SR)) / SR * 2 * np.pi * 24))))
    write('sfx_powerup', tone_seq([523, 659, 784, 1047, 1319, 1568], 0.055, 'square', decay=7))
    write('sfx_heart', tone_seq([784, 988, 1175, 1568], 0.07, 'sine', decay=6, harm=0.5))
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    write('sfx_fire', mixs(lowpass(noise(n), 3500) * np.exp(-t * 14) * 0.7, sweep(900, 300, 0.22, 'tri', vol_decay=12)))
    write('sfx_pop', sweep(900, 1800, 0.06, 'sine', vol_decay=30))
    n = int(0.3 * SR)
    t = np.arange(n) / SR
    write('sfx_break', lowpass(noise(n), 2200) * np.exp(-t * 11) + 0.5 * np.sin(2 * np.pi * 110 * t) * np.exp(-t * 20))
    n = int(0.42 * SR)
    t = np.arange(n) / SR
    write('sfx_spring', np.sin(2 * np.pi * np.cumsum(260 + 140 * np.sin(t * 2 * np.pi * 14) * np.exp(-t * 4) + 200 * t) / SR) * np.exp(-t * 6))
    write('sfx_checkpoint', tone_seq([784, 1047, 1319, 1568, 2093], 0.06, 'sine', decay=5, harm=0.4))
    write('sfx_gem', tone_seq([1319, 1568, 1976, 2637, 1976, 2637, 3136], 0.045, 'sine', decay=7, harm=0.6))
    write('sfx_kick', mixs(sweep(300, 900, 0.1, 'pulse', 0.5, 1, 15), sweep(900, 200, 0.18, 'tri', vol_decay=14)))
    write('sfx_pause', tone_seq([660, 880], 0.06, 'square', decay=18))
    write('sfx_portal', mixs(sweep(200, 1600, 0.9, 'sine', curve=1.5, vol_decay=2), 0.3 * lowpass(noise(int(0.9 * SR)), 4000) * np.exp(-np.arange(int(0.9 * SR)) / SR * 3)))


if __name__ == '__main__':
    sfx()
    jingles()
    music()
    print(sorted(os.listdir(RAW)))
