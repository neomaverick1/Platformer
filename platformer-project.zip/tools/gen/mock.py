import random
from PIL import Image
from px import Pix, hexc, preview
import tiles as TL
import bg as BG

VW, VH = 585, 270
scene = Image.new('RGBA', (VW, VH))
sky = BG.sky(VH).image().resize((VW, VH), Image.NEAREST)
scene.alpha_composite(sky)
sun = BG.sun().image()
scene.alpha_composite(sun, (430, 18))
def layer(img, y, scroll=0):
    w = img.width
    x = -(scroll % w)
    while x < VW:
        scene.alpha_composite(img, (int(x), y)) if x >= 0 else scene.alpha_composite(img.crop((-int(x), 0, w, img.height)), (0, y))
        x += w
far_clouds = BG.clouds(640, 90, 11, big=False).image()
layer(far_clouds, 8, 40)
mnt = BG.mountains().image()
layer(mnt, 100, 10)
near_clouds = BG.clouds(640, 110, 3, big=True).image()
layer(near_clouds, 20, 120)
hf = BG.hills(640, 120, 21, 40, 22, (hexc('#8FD08A'), hexc('#6DB878'), hexc('#4F9E6A'), hexc('#3F8660')), trees=True).image()
layer(hf, 150, 30)
hn = BG.hills(640, 100, 33, 34, 18, (hexc('#7ED957'), hexc('#5DBE45'), hexc('#45A03C'), hexc('#3A8A38')), bushes=True, flowers=True).image()
layer(hn, 190, 60)

# sample tile map (rows of 16px)
M = [
"....................................",
"....................................",
"....................................",
"....................................",
"..........P.C...........BBBBB.......",
"....................................",
"......................#####.........",
"..........######...........S........",
"#####......................######...",
"#####.....^^.....#######.Z.######...",
"#############################S######",
"####################################",
]
oy = VH - len(M) * 16 + 4
def solid(x, y):
    if y < 0 or y >= len(M) or x < 0 or x >= len(M[0]):
        return y >= len(M)
    return M[y][x] == '#'
for y, row in enumerate(M):
    for x, ch in enumerate(row):
        X, Y = x * 16, oy + y * 16
        if ch == '#':
            mask = (1 if solid(x, y - 1) else 0) | (2 if solid(x, y + 1) else 0) | (4 if solid(x - 1, y) else 0) | (8 if solid(x + 1, y) else 0)
            var = (x * 7 + y * 3) % 3
            t = TL.ground_tile(mask, var, x * 131 + y * 17)
            if mask == 15 and solid(x, y - 2):
                t = TL.deep_tile(x * 31 + y)
            scene.alpha_composite(t.image(), (X, Y))
        elif ch == 'B':
            kind = 1 if row[x - 1] != 'B' else (2 if x + 1 >= len(row) or row[x + 1] != 'B' else 0)
            scene.alpha_composite(TL.bridge_tile(kind).image(), (X, Y))
        elif ch == 'P':
            scene.alpha_composite(TL.prize_block(0).image(), (X, Y))
        elif ch == 'C':
            scene.alpha_composite(TL.crate().image(), (X, Y))
        elif ch == '^':
            scene.alpha_composite(TL.spikes().image(), (X, Y))
        elif ch == 'Z':
            scene.alpha_composite(TL.spring(0).image(), (X, Y))
        elif ch == 'S':
            mask = 0
            scene.alpha_composite(TL.stone_tile(5 if row[x-1]=='S' else 0, x).image(), (X, Y))
preview(scene, 2, 'out/mock.png')
print('ok')
