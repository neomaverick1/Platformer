"""Enemies, power-ups, collectibles, effects, decorations and UI in the same pixel style."""
import math
import random
from px import Pix, hexc, mix, shade

OUT = hexc('#22142A')


def finish(p, darken=0.72):
    p.outline(darken=darken)
    return p


# ============================================================ enemies (facing right)
def beetle(frame):
    """Shell beetle, 24x16. frames 0-3 walk, 4 = squashed."""
    p = Pix(24, 16)
    shell = (hexc('#FF9BE0'), hexc('#E04AB4'), hexc('#A8288A'), hexc('#661A5A'))
    if frame == 4:
        p.ellipse(12, 13, 9, 2.6, shell[2])
        p.ellipse(11, 12.5, 7, 1.6, shell[1])
        for x in (8, 11, 14):
            p.put(x, 12, shell[0])
        p.put(19, 13, hexc('#FFFFFF')); p.put(20, 13, OUT)
        return finish(p)
    bob = (0, 1, 0, 1)[frame]
    # legs (3 visible), alternate
    leg = hexc('#3A2340')
    for i, lx in enumerate((7, 12, 16)):
        ph = (frame + i) % 4
        off = (-1, 0, 1, 0)[ph]
        lift = 1 if ph == 1 else 0
        p.line(lx, 11 + bob, lx + off, 15 - lift, leg)
        p.put(lx + off + 1, 15 - lift, leg)
    # body / shell dome
    cy = 9 + bob
    p.ellipse(11.5, cy, 8.5, 5.5, shell[2])
    p.ellipse(11, cy - 0.5, 7.5, 4.6, shell[1])
    p.ellipse(9.5, cy - 2.0, 4, 2.0, shell[0])
    # shell split line and spots
    p.line(11, cy - 5, 13, cy + 3, shell[3])
    for (sx, sy) in ((7, cy), (15, cy - 2), (16, cy + 1)):
        p.put(int(sx), int(sy), shell[3]); p.put(int(sx) + 1, int(sy), shell[3])
    # head
    hx, hy = 19, 10 + bob
    p.disc(hx, hy, 3.2, hexc('#3B2A52'))
    p.disc(hx - 0.5, hy - 0.8, 1.8, hexc('#5A4478'))
    p.put(hx + 1, hy - 1, hexc('#FFFFFF')); p.put(hx + 2, hy - 1, hexc('#FFFFFF'))
    p.put(hx + 2, hy, OUT)
    # antenna
    p.line(hx + 1, hy - 3, hx + 3, hy - 6 + (frame % 2), hexc('#3A2340'))
    p.put(hx + 3, hy - 7 + (frame % 2), hexc('#FFD24A'))
    return finish(p)


def hornet(frame):
    """Hornet, 24x20, frames 0-1 (wings)."""
    p = Pix(24, 20)
    y0 = 11 + (0, 1)[frame]
    wing = (230, 245, 255, 200)
    wing_e = (170, 210, 255, 230)
    # back wing then front wing
    if frame == 0:
        p.ellipse(10, y0 - 7, 5, 3, wing); p.ellipse(13, y0 - 8, 4.5, 2.6, wing_e)
    else:
        p.ellipse(9, y0 - 3, 5, 2.4, wing); p.ellipse(12, y0 - 4, 4.5, 2.2, wing_e)
    # abdomen with stripes
    yel, yd, blk = hexc('#FFD43B'), hexc('#E0A01E'), hexc('#2A1E2E')
    p.ellipse(8, y0 + 1, 6, 4.2, yd)
    p.ellipse(7.5, y0 + 0.3, 5.2, 3.3, yel)
    for sx in (4, 7, 10):
        for yy in range(int(y0 - 3), int(y0 + 5)):
            if p.get(sx, yy)[3]:
                p.put(sx, yy, blk)
    # stinger
    p.put(1, y0 + 3, blk); p.put(2, y0 + 2, blk); p.put(0, y0 + 4, hexc('#FFFFFF'))
    # thorax + head
    p.disc(15, y0, 3.2, hexc('#3A2A3E'))
    p.disc(19, y0 - 1, 3.4, yel)
    p.disc(18.5, y0 - 1.5, 2.2, hexc('#FFE98A'))
    # big eye
    p.put(20, y0 - 2, blk); p.put(21, y0 - 2, blk); p.put(20, y0 - 1, blk); p.put(21, y0 - 1, hexc('#FFFFFF'))
    # angry brow
    p.put(19, y0 - 4, blk); p.put(20, y0 - 3, blk)
    # legs
    p.line(15, y0 + 3, 14, y0 + 5, blk); p.line(17, y0 + 3, 17, y0 + 5, blk)
    return finish(p)


def hedgehog(frame):
    """Spiky hedgehog, 24x16, frames 0-3. Not stompable."""
    p = Pix(24, 16)
    bob = (0, 1, 0, 1)[frame]
    sp_hi, sp, sp_d = hexc('#F0E0FF'), hexc('#8C5AC8'), hexc('#4E2C7A')
    # spikes: triangles along the back
    cx, cy = 10, 9 + bob
    for i in range(7):
        a = math.radians(200 + i * 22)
        bx, by = cx + math.cos(a) * 6, cy + math.sin(a) * 5
        tx, ty = cx + math.cos(a) * 10.5, cy + math.sin(a) * 8.5
        p.poly([(bx - 2.2 * math.sin(a), by + 2.2 * math.cos(a)), (bx + 2.2 * math.sin(a), by - 2.2 * math.cos(a)), (tx, ty)], sp)
        p.put(int(tx), int(ty), sp_hi)
    p.ellipse(10, cy + 0.5, 7.5, 5.5, sp_d)
    p.ellipse(9.5, cy, 6.5, 4.6, sp)
    # face
    face = hexc('#E8B98A')
    p.ellipse(16.5, cy + 1.5, 4.5, 3.6, face)
    p.ellipse(16, cy + 0.6, 3, 2, hexc('#F7D5AE'))
    p.put(21, cy + 1, hexc('#FF6B8A')); p.put(21, cy + 2, hexc('#C2405E'))
    p.put(17, cy, OUT); p.put(17, cy + 1, OUT); p.put(18, cy, hexc('#FFFFFF'))
    # feet
    feet = hexc('#6E4A3A')
    off = (0, 1, 0, -1)[frame]
    p.rect(7 + off, 14, 3, 2, feet)
    p.rect(14 - off, 14, 3, 2, feet)
    return finish(p)


def frog(frame):
    """Hopping frog, 24x20. 0-1 idle (throat), 2 = jump, 3 = land."""
    p = Pix(24, 20)
    body, body_d, body_hi = hexc('#FF8A2E'), hexc('#C2501A'), hexc('#FFC27A')
    spot = hexc('#5A2A6E')
    belly = hexc('#FFE8B0')
    if frame == 2:
        p.ellipse(12, 9, 7, 5, body_d)
        p.ellipse(12, 8.5, 6, 4, body)
        p.ellipse(11, 7, 3.5, 2, body_hi)
        p.thick(6, 12, 2, 18, 1.2, body_d)
        p.thick(17, 12, 21, 18, 1.2, body_d)
        p.ellipse(15, 4, 2.4, 2.4, body); p.disc(15.5, 3.8, 1.3, hexc('#FFFFFF')); p.put(16, 4, OUT)
        p.ellipse(9, 4, 2.2, 2.2, body); p.disc(9.5, 3.8, 1.1, hexc('#FFFFFF')); p.put(10, 4, OUT)
        p.put(13, 9, spot); p.put(9, 10, spot)
        return finish(p)
    squat = 1 if frame == 3 else 0
    throat = frame == 1
    cy = 13 + squat
    # back leg
    p.ellipse(7, cy + 3, 5, 3, body_d)
    p.rect(3, 18, 6, 2, body_d)
    # body
    p.ellipse(12, cy, 8.5, 5.5 - squat, body_d)
    p.ellipse(12, cy - 0.5, 7.5, 4.6 - squat, body)
    p.ellipse(10, cy - 2.5, 4, 1.8, body_hi)
    # belly / throat
    p.ellipse(16, cy + 2, 3.5, 2.6 + (0.6 if throat else 0), belly)
    # eyes on top
    for ex in (10, 15):
        p.disc(ex, cy - 5 + squat, 2.6, body)
        p.disc(ex + 0.3, cy - 5.3 + squat, 1.6, hexc('#FFFFFF'))
        p.put(ex + 1, cy - 5 + squat, OUT)
    # spots
    for (sx, sy) in ((8, cy - 1), (12, cy + 1), (6, cy + 1)):
        p.put(sx, sy, spot)
    # front foot
    p.rect(15, 18, 5, 2, body_d)
    p.put(19, 18, body)
    # mouth
    p.line(17, cy + 0, 20, cy - 1, body_d)
    return finish(p)


# ============================================================ items (16x16)
def heart(frame=0):
    p = Pix(16, 16)
    rows = [
        "..rrr...rrr..",
        ".rRRrr.rrrrr.",
        "rRWRrrrrrrrrq",
        "rRRrrrrrrrrrq",
        "rrrrrrrrrrrqq",
        ".rrrrrrrrrqq.",
        "..rrrrrrrqq..",
        "...rrrrrqq...",
        "....rrrqq....",
        ".....rqq.....",
        "......q......",
    ]
    p.from_rows(rows, {'r': hexc('#FF3B5C'), 'R': hexc('#FF8CA0'), 'W': hexc('#FFFFFF'), 'q': hexc('#B01E3E')}, 1, 3)
    return finish(p)


def feather(frame=0):
    p = Pix(16, 16)
    # quill diagonal from bottom-left to top-right with vanes
    for i in range(12):
        x, y = 3 + i * 0.8, 13 - i * 0.95
        w = min(i, 11 - i) * 0.55 + 0.6
        p.ellipse(x + 0.8, y - 0.4, w, 1.0, hexc('#DFF4FF'))
    for i in range(12):
        x, y = 3 + i * 0.8, 13 - i * 0.95
        p.put(int(x), int(y), hexc('#8FB8E8'))
    p.line(2, 15, 4, 12, hexc('#C9A86A'))
    for k in (4, 7, 9):
        x, y = 3 + k * 0.8, 13 - k * 0.95
        p.put(int(x) + 2, int(y) - 1, hexc('#9FD0FF'))
    p.put(11, 2, hexc('#FFFFFF'))
    return finish(p)


def sunflower(frame=0):
    p = Pix(16, 16)
    stem = hexc('#3E9A3A')
    p.line(8, 9, 8, 15, stem)
    p.ellipse(5.5, 12.5, 2.2, 1.2, hexc('#5DBE45'))
    p.ellipse(10.5, 13, 2.2, 1.2, hexc('#5DBE45'))
    pet, pet_d = hexc('#FFD23F'), hexc('#F08A1C')
    for i in range(10):
        a = i * math.pi * 2 / 10 + frame * 0.3
        p.disc(8 + math.cos(a) * 4.2, 6 + math.sin(a) * 4.2, 1.7, pet if i % 2 == 0 else pet_d)
    p.disc(8, 6, 2.8, hexc('#8A4A1E'))
    p.disc(7.5, 5.5, 1.4, hexc('#C26E2E'))
    p.put(9, 7, hexc('#5E2E12'))
    return finish(p)


def shield(frame=0):
    p = Pix(16, 16)
    p.disc(8, 8, 6.5, (120, 220, 255, 140))
    p.disc(8, 8, 5.5, (160, 235, 255, 120))
    for a in range(0, 360, 6):
        x = 8 + math.cos(math.radians(a)) * 6.3
        y = 8 + math.sin(math.radians(a)) * 6.3
        p.put(int(x), int(y), hexc('#7FE7FF'))
    p.ellipse(5.5, 5, 2, 1.2, hexc('#FFFFFF'))
    p.put(10, 11, hexc('#FFFFFF'))
    # little shield emblem
    p.poly([(5.5, 7), (10.5, 7), (10.5, 9.5), (8, 12), (5.5, 9.5)], hexc('#2F7FE8'))
    p.line(8, 7, 8, 11, hexc('#9FD0FF'))
    return finish(p, 0.5)


def star(frame=0):
    p = Pix(16, 16)
    pts = []
    for i in range(10):
        a = math.radians(-90 + i * 36)
        r = 7 if i % 2 == 0 else 3.1
        pts.append((8 + math.cos(a) * r, 8.4 + math.sin(a) * r))
    cols = [hexc('#FFD23F'), hexc('#FF8A3D'), hexc('#FF5DA2'), hexc('#7FE7FF')]
    p.poly(pts, cols[frame % 4])
    inner = [(8 + (x - 8) * 0.55, 8.4 + (y - 8.4) * 0.55) for (x, y) in pts]
    p.poly(inner, mix(cols[frame % 4], hexc('#FFFFFF'), 0.55))
    p.put(6, 7, OUT); p.put(10, 7, OUT)
    p.put(6, 6, hexc('#FFFFFF')); p.put(10, 6, hexc('#FFFFFF'))
    return finish(p)


def coin(frame):
    """Spinning coin, 6 frames."""
    p = Pix(16, 16)
    w = [5.5, 4.4, 2.2, 0.9, 2.2, 4.4][frame]
    g, gl, gd, gdd = hexc('#FFD54A'), hexc('#FFF2A8'), hexc('#D99A1C'), hexc('#8A5A0E')
    if w < 1.5:
        p.rect(7, 2, 2, 12, gd)
        p.rect(7, 2, 1, 12, gl)
        return finish(p)
    p.ellipse(8, 8, w, 6.2, gd)
    p.ellipse(8 - 0.3, 8 - 0.3, max(0.8, w - 1.2), 5.0, g)
    if w > 3:
        p.rect(int(8 - w * 0.25), 5, 1, 6, gd)
        p.rect(int(8 - w * 0.25) + 1, 5, 1, 6, gl)
    p.put(int(8 - w + 1.5), 5, gl)
    return finish(p, 0.6)


def gem(frame):
    """Big hidden gem (3 per level), 4 frames shimmer."""
    p = Pix(16, 16)
    hi, lt, md, dk = hexc('#F2E8FF'), hexc('#C79BFF'), hexc('#9550F0'), hexc('#5A22A8')
    top = [(3, 6), (6, 2), (10, 2), (13, 6)]
    p.poly([(3, 6), (6, 2), (10, 2), (13, 6), (8, 14)], md)
    p.poly([(3, 6), (6, 2), (8, 6)], lt)
    p.poly([(8, 6), (10, 2), (13, 6)], dk)
    p.poly([(3, 6), (8, 6), (8, 14)], lt)
    p.line(6, 2, 10, 2, hi)
    sx = [4, 6, 9, 30][frame]
    if sx < 16:
        p.put(sx, 4, hexc('#FFFFFF')); p.put(sx + 1, 3, hexc('#FFFFFF')); p.put(sx - 1, 5, hi)
    return finish(p)


def sun_orb(frame):
    """Projectile from the sunflower power, 4 frames (spin)."""
    p = Pix(16, 16)
    p.disc(8, 8, 4.2, hexc('#FF8A1C'))
    p.disc(8, 8, 3.2, hexc('#FFD23F'))
    p.disc(7.5, 7.5, 1.8, hexc('#FFF8C8'))
    for i in range(4):
        a = math.radians(frame * 22 + i * 90)
        p.put(int(8 + math.cos(a) * 5.6), int(8 + math.sin(a) * 5.6), hexc('#FFE070'))
    return p


# ============================================================ effects (16x16)
def dust(frame):
    p = Pix(16, 16)
    r = [2.0, 3.0, 3.6, 3.4, 2.4][frame]
    a = [230, 220, 180, 120, 70][frame]
    c = (238, 228, 210, a)
    p.disc(8, 10 - frame * 0.6, r, c)
    p.disc(5, 11 - frame * 0.4, r * 0.6, c)
    p.disc(11, 11 - frame * 0.4, r * 0.55, c)
    return p


def poof(frame):
    p = Pix(16, 16)
    k = frame / 5.0
    for i in range(6):
        a = i * math.pi / 3 + 0.4
        d = 2 + k * 5
        r = 2.6 * (1 - k * 0.7) + 0.5
        p.disc(8 + math.cos(a) * d, 8 + math.sin(a) * d, r, (255, 255, 255, int(255 * (1 - k * 0.6))))
    if frame < 2:
        p.disc(8, 8, 3 - frame, (255, 240, 200, 255))
    return p


def sparkle(frame):
    p = Pix(16, 16)
    L = [2, 4, 5, 3][frame]
    c = hexc('#FFFFFF')
    c2 = hexc('#FFF2A8')
    for d in range(1, L + 1):
        col = c if d < L else c2
        p.put(8 + d, 8, col); p.put(8 - d, 8, col); p.put(8, 8 + d, col); p.put(8, 8 - d, col)
    p.put(8, 8, c)
    if frame in (1, 2):
        for d in (1, 2):
            p.put(8 + d, 8 + d, c2); p.put(8 - d, 8 - d, c2); p.put(8 + d, 8 - d, c2); p.put(8 - d, 8 + d, c2)
    return p


def stomp_star(frame):
    p = Pix(16, 16)
    for i in range(5):
        a = math.radians(-90 + i * 72 + frame * 20)
        x, y = 8 + math.cos(a) * (3 + frame * 2), 8 + math.sin(a) * (3 + frame * 2)
        p.put(int(x), int(y), hexc('#FFF2A8'))
        p.put(int(x) + 1, int(y), hexc('#FFD23F'))
    return p


# ============================================================ level objects
def checkpoint(frame, active):
    """Flag on a pole, 16x32. active: banner colourful and waving; else grey and limp."""
    p = Pix(16, 32)
    pole, pole_d = hexc('#E8E2D4'), hexc('#9A9284')
    p.rect(3, 4, 2, 27, pole)
    p.rect(4, 4, 1, 27, pole_d)
    p.disc(4, 3, 1.6, hexc('#FFD23F') if active else hexc('#B8B2A6'))
    p.rect(1, 30, 6, 2, hexc('#6E6A62'))
    if active:
        cols = (hexc('#FF5D6E'), hexc('#C52C46'), hexc('#FFD23F'))
        for x in range(5, 15):
            wave = math.sin((x - 5) * 0.7 + frame * 1.5) * 1.3 * ((x - 5) / 9)
            top = 5 + int(round(wave))
            for y in range(top, top + 8 - (x - 5) // 4):
                p.put(x, y, cols[0] if y < top + 5 else cols[1])
            if x in (8, 9):
                p.put(x, top + 3, cols[2])
    else:
        g = (hexc('#9C978E'), hexc('#77736C'))
        for x in range(5, 10):
            for y in range(5, 18 - (x - 5)):
                p.put(x, y, g[0] if x < 8 else g[1])
    return finish(p, 0.6)


def portal(frame):
    """Goal: a stone arch holding a swirling crystal portal, 32x48, 6 frames."""
    p = Pix(32, 48)
    stone, stone_l, stone_d = hexc('#B9C0CE'), hexc('#E2E6EE'), hexc('#5F6580')
    # arch
    for y in range(8, 48):
        for x in range(2, 30):
            dx = (x + 0.5 - 16) / 13.5
            dy = (y + 0.5 - 20) / 14
            inside = (dx * dx + (dy * dy if y < 20 else 0)) < 0.68
            outer = (dx * dx + (dy * dy if y < 20 else 0)) < 1.0
            if outer and not inside:
                p.put(x, y, stone if x > 6 else stone_l)
    # pillar shading
    for y in range(20, 48):
        p.put(3, y, stone_l); p.put(28, y, stone_d)
    # keystone gem
    p.disc(16, 7, 3.4, hexc('#5A22A8'))
    p.disc(16, 6.5, 2.4, hexc('#C79BFF'))
    p.put(15, 5, hexc('#FFFFFF'))
    # swirling portal
    for y in range(9, 46):
        for x in range(6, 26):
            dx = (x + 0.5 - 16) / 10.5
            dy = (y + 0.5 - 20) / 11.5
            if (dx * dx + (dy * dy if y < 20 else 0)) < 0.98 and y < 46:
                ang = math.atan2(y - 26, x - 16)
                rr = math.hypot(x - 16, (y - 26) * 0.6)
                v = math.sin(ang * 3 + rr * 0.5 - frame * 1.05)
                c = mix(hexc('#3EC8FF'), hexc('#B48CFF'), (v + 1) / 2)
                if v > 0.75:
                    c = hexc('#E8FBFF')
                p.put(x, y, c)
    p.rect(2, 46, 28, 2, stone_d)
    return finish(p, 0.6)


# ============================================================ decorations
FLOWER_COLS = [(hexc('#FFF6FA'), hexc('#FFC2D6')), (hexc('#FFD84D'), hexc('#F2A21E')),
               (hexc('#FF7AA8'), hexc('#D93F78')), (hexc('#B98CFF'), hexc('#7A4AE0')),
               (hexc('#7FE7FF'), hexc('#2FA8E0'))]


def flower(kind, frame):
    p = Pix(16, 16)
    sway = (0, 1)[frame]
    stem = hexc('#3E9A3A')
    p.line(8, 15, 8 + sway, 9, stem)
    p.put(7, 13, hexc('#5DBE45')); p.put(9, 12, hexc('#5DBE45'))
    c, cd = FLOWER_COLS[kind % len(FLOWER_COLS)]
    cx, cy = 8 + sway, 8
    for (dx, dy) in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        p.put(cx + dx, cy + dy, c)
    p.put(cx - 1, cy - 1, cd); p.put(cx + 1, cy + 1, cd)
    p.put(cx, cy, hexc('#FFE070'))
    return finish(p, 0.55)


def tuft(frame):
    p = Pix(16, 16)
    s = (0, 1)[frame]
    g1, g2, g3 = hexc('#A6EA4C'), hexc('#6FCB33'), hexc('#3E9A2A')
    blades = [(4, 7, -1), (6, 4, 0), (8, 6, 1), (10, 3, 1), (12, 7, 2)]
    for (x, top, lean) in blades:
        p.line(x, 15, x + lean + s, 15 - (15 - top) // 2 - 3, g2)
        p.put(x + lean + s, 15 - (15 - top) // 2 - 3, g1)
        p.put(x, 15, g3)
    return p


def bush():
    p = Pix(32, 16)
    d, m, l, h = hexc('#2E7F22'), hexc('#4BAA27'), hexc('#76CF34'), hexc('#A6EA4C')
    for (x, y, r) in ((8, 11, 6), (16, 8, 8), (24, 11, 6), (13, 12, 5), (20, 12, 5)):
        p.disc(x, y, r, d)
    for (x, y, r) in ((8, 10, 4.6), (16, 7, 6.4), (24, 10, 4.6)):
        p.disc(x - 0.6, y - 0.6, r, m)
    for (x, y, r) in ((7, 8, 2.2), (14, 4, 3.2), (23, 8, 2.2)):
        p.disc(x, y, r, l)
    for (x, y) in ((13, 2), (6, 7), (22, 7)):
        p.put(x, y, h)
    for (x, y) in ((11, 9), (19, 6), (26, 11)):
        p.put(x, y, hexc('#FF7AA8'))
    p.rect(2, 15, 28, 1, d)
    return finish(p, 0.55)


def rock():
    p = Pix(16, 16)
    p.ellipse(8, 11, 7, 4.6, hexc('#8C93A8'))
    p.ellipse(7, 10, 5.4, 3.4, hexc('#B9C0CE'))
    p.ellipse(5.5, 8.5, 2.4, 1.2, hexc('#E2E6EE'))
    p.rect(1, 15, 14, 1, hexc('#5F6580'))
    p.put(10, 12, hexc('#5F6580')); p.put(11, 12, hexc('#5F6580'))
    p.put(4, 13, MOSSC[0]); p.put(5, 13, MOSSC[1])
    return finish(p, 0.55)


MOSSC = (hexc('#5DB83A'), hexc('#3A8A2A'))


def sign(kind):
    """kind 0 = arrow right, 1 = exclamation, 2 = arrow up."""
    p = Pix(16, 16)
    w, wl, wd = hexc('#C88B55'), hexc('#E8B07A'), hexc('#7B4628')
    p.rect(7, 9, 2, 7, wd)
    p.rect(2, 2, 12, 8, w)
    p.rect(2, 2, 12, 1, wl)
    p.rect(2, 9, 12, 1, wd)
    ink = hexc('#4A2A16')
    if kind == 0:
        p.line(4, 6, 10, 6, ink); p.line(8, 4, 10, 6, ink); p.line(8, 8, 10, 6, ink)
    elif kind == 1:
        p.rect(7, 3, 2, 4, ink); p.rect(7, 8, 2, 1, ink)
    else:
        p.line(8, 3, 8, 8, ink); p.line(6, 5, 8, 3, ink); p.line(10, 5, 8, 3, ink)
    return finish(p, 0.55)


def fence():
    p = Pix(16, 16)
    w, wl, wd = hexc('#E8C89A'), hexc('#FFF0D6'), hexc('#A8825A')
    for x in (2, 12):
        p.rect(x, 4, 3, 12, w); p.rect(x, 4, 1, 12, wl); p.rect(x + 2, 4, 1, 12, wd)
        p.put(x + 1, 3, w)
    p.rect(0, 7, 16, 2, w); p.rect(0, 7, 16, 1, wl)
    p.rect(0, 12, 16, 2, w); p.rect(0, 13, 16, 1, wd)
    return finish(p, 0.55)


def mushroom(kind):
    p = Pix(16, 16)
    cap = [hexc('#FF5D6E'), hexc('#B98CFF')][kind]
    p.rect(7, 11, 3, 5, hexc('#F6EEDC'))
    p.rect(9, 11, 1, 5, hexc('#CFC3A8'))
    p.ellipse(8.5, 10, 5, 3.2, mix(cap, hexc('#000000'), 0.3))
    p.ellipse(8, 9.4, 4.4, 2.6, cap)
    p.put(6, 8, hexc('#FFFFFF')); p.put(10, 9, hexc('#FFFFFF')); p.put(8, 7, hexc('#FFFFFF'))
    return finish(p, 0.55)


def tree():
    """A big leafy tree, 48x64 (decoration, behind the action)."""
    p = Pix(48, 64)
    trunk, trunk_l, trunk_d = hexc('#7A4A2E'), hexc('#A8703A'), hexc('#4E2C16')
    p.rect(20, 34, 8, 30, trunk)
    p.rect(20, 34, 2, 30, trunk_l)
    p.rect(26, 34, 2, 30, trunk_d)
    p.line(17, 63, 20, 58, trunk); p.line(31, 63, 28, 58, trunk)
    p.line(24, 44, 16, 36, trunk); p.line(24, 46, 33, 37, trunk)
    d, m, l, h = hexc('#2E7F22'), hexc('#4BAA27'), hexc('#76CF34'), hexc('#A6EA4C')
    blobs = [(24, 18, 15), (13, 26, 10), (35, 26, 10), (18, 12, 9), (31, 12, 9), (24, 30, 10)]
    for (x, y, r) in blobs:
        p.disc(x, y, r, d)
    for (x, y, r) in blobs:
        p.disc(x - 1.5, y - 1.5, r * 0.8, m)
    for (x, y, r) in blobs:
        p.disc(x - 3, y - 3.5, r * 0.42, l)
    rnd = random.Random(4)
    for _ in range(40):
        x, y = rnd.randrange(6, 42), rnd.randrange(2, 36)
        if p.get(x, y)[3] and p.get(x, y)[:3] == l[:3]:
            p.put(x, y, h)
    for (x, y) in ((16, 20), (30, 24), (22, 8), (36, 18)):
        p.put(x, y, hexc('#FF5D6E')); p.put(x + 1, y, hexc('#C52C46'))  # little apples
    return finish(p, 0.55)


def butterfly(frame):
    p = Pix(16, 16)
    w = (hexc('#FFD23F'), hexc('#FF8A3D')) if frame < 2 else (hexc('#7FE7FF'), hexc('#2F7FE8'))
    up = frame % 2 == 0
    if up:
        p.ellipse(6, 6, 2.4, 3, w[0]); p.ellipse(10, 6, 2.4, 3, w[0])
        p.put(6, 6, w[1]); p.put(10, 6, w[1])
    else:
        p.ellipse(6, 9, 2.6, 1.4, w[0]); p.ellipse(10, 9, 2.6, 1.4, w[0])
    p.rect(8, 6, 1, 5, hexc('#2A1E2E'))
    return p


# ============================================================ UI
def ui_heart(state):
    """state 2 = full, 1 = half, 0 = empty. 16x16 cell, heart 11x10."""
    p = Pix(16, 16)
    rows = [
        ".rrr.rrr.",
        "rRWrrrrrq",
        "rRrrrrrrq",
        "rrrrrrrqq",
        ".rrrrrqq.",
        "..rrrqq..",
        "...rqq...",
        "....q....",
    ]
    full = {'r': hexc('#FF3B5C'), 'R': hexc('#FF8CA0'), 'W': hexc('#FFFFFF'), 'q': hexc('#B01E3E')}
    empty = {'r': hexc('#4A3A5A'), 'R': hexc('#5E4E70'), 'W': hexc('#6E5E80'), 'q': hexc('#2E2440')}
    p.from_rows(rows, empty if state == 0 else full, 3, 4)
    if state == 1:
        for y in range(4, 12):
            for x in range(8, 13):
                c = p.get(x, y)
                if c[3]:
                    p.put(x, y, empty['r'] if c[:3] != empty['q'][:3] else empty['q'])
    p.outline(color=hexc('#1A1024'))
    return p


def button(kind, pressed):
    """On-screen touch buttons, 32x32: 0 left, 1 right, 2 jump, 3 fire, 4 pause."""
    p = Pix(32, 32)
    a = 150 if not pressed else 225
    ring = (255, 255, 255, a)
    fill = (30, 24, 60, 110 if not pressed else 170)
    if kind == 4:
        p.disc(16, 16, 11, fill)
        for a2 in range(0, 360, 3):
            p.put(int(16 + math.cos(math.radians(a2)) * 11), int(16 + math.sin(math.radians(a2)) * 11), ring)
        p.rect(12, 11, 3, 10, ring); p.rect(18, 11, 3, 10, ring)
        return p
    p.disc(16, 16, 14.5, fill)
    for a2 in range(0, 360, 2):
        p.put(int(16 + math.cos(math.radians(a2)) * 14.5), int(16 + math.sin(math.radians(a2)) * 14.5), ring)
    icon = (255, 255, 255, 235 if pressed else 200)
    if kind in (0, 1):
        s = -1 if kind == 0 else 1
        p.poly([(16 - 5 * s, 9), (16 + 6 * s, 16), (16 - 5 * s, 23)], icon)
    elif kind == 2:
        p.poly([(16, 8), (24, 17), (19, 17), (19, 24), (13, 24), (13, 17), (8, 17)], icon)
    else:
        p.disc(16, 16, 5.5, (255, 200, 70, 230 if pressed else 190))
        p.disc(15, 15, 3, (255, 245, 200, 240))
        for i in range(8):
            ang = math.radians(i * 45)
            p.put(int(16 + math.cos(ang) * 8), int(16 + math.sin(ang) * 8), (255, 220, 120, 220))
    return p
