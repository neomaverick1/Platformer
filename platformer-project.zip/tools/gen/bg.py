"""Parallax background layers for the grassy hills (all tile seamlessly left-right)."""
import math
import random
import numpy as np
from px import Pix, hexc, mix, shade

SKY_STOPS = [(0.0, hexc('#2F6FD8')), (0.45, hexc('#5FA6F0')), (0.78, hexc('#A9D9FF')), (1.0, hexc('#E4F6FF'))]


def sky(h=270):
    """A 4-px wide strip, banded with ordered dithering between bands (retro look)."""
    p = Pix(4, h)
    bands = 22
    bayer = [[0, 2], [3, 1]]
    for y in range(h):
        t = y / (h - 1)
        # colour of the band and the next one
        fb = t * bands
        b0 = int(fb)
        frac = fb - b0

        def col(bi):
            tt = min(1.0, bi / bands)
            for i in range(len(SKY_STOPS) - 1):
                t0, c0 = SKY_STOPS[i]
                t1, c1 = SKY_STOPS[i + 1]
                if t0 <= tt <= t1:
                    return mix(c0, c1, (tt - t0) / (t1 - t0))
            return SKY_STOPS[-1][1]
        for x in range(4):
            thr = (bayer[y % 2][x % 2] + 0.5) / 4.0
            c = col(b0 + 1) if frac > 0.75 and thr < (frac - 0.75) * 4 else col(b0)
            p.put(x, y, c)
    return p


def sun():
    """Sun disc with pixel halo rings (drawn additively at runtime)."""
    s = 64
    p = Pix(s, s)
    c = s / 2
    for r, col in ((31, (255, 246, 200, 40)), (26, (255, 240, 180, 70)), (21, (255, 236, 160, 110))):
        p.disc(c, c, r, col)
    p.disc(c, c, 15, hexc('#FFF6C8'))
    p.disc(c, c, 13, hexc('#FFFBE6'))
    p.disc(c - 3, c - 3, 7, hexc('#FFFFFF'))
    return p


def cloud_shape(p, cx, cy, w, rnd):
    """A cumulus: overlapping puffs with a flat-ish bottom, shaded top to bottom."""
    puffs = []
    n = max(3, int(w / 14))
    for i in range(n):
        x = cx - w / 2 + (i + 0.5) * w / n + rnd.uniform(-3, 3)
        r = rnd.uniform(9, 15) * (1.25 if 0 < i < n - 1 else 0.85)
        puffs.append((x, cy - r * 0.35 + rnd.uniform(-3, 2), r))
    if w > 50:
        puffs.append((cx + rnd.uniform(-8, 8), cy - 14, rnd.uniform(13, 18)))
    mask = Pix(p.w, p.h)
    for (x, y, r) in puffs:
        for dx in (-p.w, 0, p.w):
            mask.disc(x + dx, y, r, (255, 255, 255, 255))
    bottom = cy + 6
    hi, body, sh, dsh = hexc('#FFFFFF'), hexc('#F2F7FF'), hexc('#D3E3F7'), hexc('#ADC6EA')
    top = min(y - r for (x, y, r) in puffs)
    for y in range(p.h):
        for x in range(p.w):
            if mask.a[y, x, 3] and y <= bottom:
                t = (y - top) / max(1.0, (bottom - top))
                c = hi if t < 0.18 else body if t < 0.55 else sh if t < 0.82 else dsh
                p.put(x, y, c)
    # crisp highlight rim on the top-left of each puff
    for (x, y, r) in puffs:
        for a in range(200, 300, 4):
            rx = x + math.cos(math.radians(a)) * (r - 1.5)
            ry = y + math.sin(math.radians(a)) * (r - 1.5)
            xi, yi = int(rx) % p.w, int(ry)
            if 0 <= yi < p.h and p.a[yi, xi, 3]:
                p.put(xi, yi, hexc('#FFFFFF'))


def clouds(w=640, h=110, seed=3, big=True):
    rnd = random.Random(seed)
    p = Pix(w, h)
    x = 30
    while x < w - 20:
        cw = rnd.uniform(60, 120) if big else rnd.uniform(34, 60)
        cy = rnd.uniform(h * 0.45, h * 0.8) if big else rnd.uniform(h * 0.4, h * 0.85)
        cloud_shape(p, x + cw / 2, cy, cw, rnd)
        x += cw + rnd.uniform(60, 140)
    return p


def mountains(w=640, h=150, seed=5):
    rnd = random.Random(seed)
    p = Pix(w, h)
    # ridge: sum of tileable waves + a few sharp peaks
    peaks = []
    x = 0
    while x < w:
        peaks.append((x, rnd.uniform(35, 105)))
        x += rnd.uniform(70, 130)
    def ridge(xx):
        best = 0
        for (px0, ph) in peaks:
            for off in (-w, 0, w):
                d = abs(xx - (px0 + off))
                v = ph - d * 0.95
                best = max(best, v)
        return best + 8 * math.sin(xx * 2 * math.pi / w * 3) + 6
    face_lt, face_dk = hexc('#9DB3E0'), hexc('#7B90C6')
    snow, snow_d = hexc('#F4F8FF'), hexc('#C5D4F0')
    haze = hexc('#B9DAFA')
    for xx in range(w):
        top = h - ridge(xx)
        slope = ridge((xx + 1) % w) - ridge(xx)
        for y in range(int(top), h):
            depth = (y - top)
            lit = slope > 0
            c = face_lt if lit else face_dk
            if depth < 9 and top < h - 70:
                c = snow if lit else snow_d
            # haze towards the base
            t = max(0.0, (y - (h - 50)) / 50.0)
            c = mix(c, haze, min(0.85, t * 0.9))
            p.put(xx, y, c)
    return p


def hills(w, h, seed, base_y, amp, cols, trees=False, flowers=False, bushes=False):
    rnd = random.Random(seed)
    p = Pix(w, h)
    k1, k2, k3 = rnd.choice([2, 3]), rnd.choice([4, 5]), rnd.choice([7, 9])
    ph1, ph2, ph3 = rnd.uniform(0, 6.28), rnd.uniform(0, 6.28), rnd.uniform(0, 6.28)

    def surf(xx):
        t = xx * 2 * math.pi / w
        return base_y - amp * (0.55 * math.sin(k1 * t + ph1) + 0.3 * math.sin(k2 * t + ph2) + 0.15 * math.sin(k3 * t + ph3))
    light, mid, dark, deep = cols
    tops = [surf(x) for x in range(w)]
    for xx in range(w):
        top = tops[xx]
        slope = tops[(xx + 2) % w] - tops[xx - 2]
        for y in range(int(top), h):
            d = y - top
            if d < 2:
                c = light
            elif d < 7:
                c = mid if slope > 0.4 else light
            else:
                c = mid if d < 24 else dark
            if d > 40:
                c = deep
            p.put(xx, y, c)
    # banded field stripes for texture
    for xx in range(w):
        for y in range(int(tops[xx]) + 10, h, 9):
            if (xx // 3 + y // 9) % 2 == 0:
                p.put(xx, y, mix(p.get(xx, y), dark, 0.35))
    if trees:
        x = rnd.uniform(0, 30)
        while x < w:
            tx = int(x) % w
            ty = tops[tx]
            r = rnd.uniform(4, 7)
            trunk = hexc('#4A3A30')
            p.rect(tx, ty - 3, 1, 4, trunk)
            for dx in (-w, 0, w):
                p.disc(tx + 0.5 + dx, ty - 3 - r * 0.8, r, cols[2])
                p.disc(tx - 1 + dx, ty - 4 - r * 0.95, r * 0.6, cols[1])
                p.put(tx - 2 + dx, int(ty - 5 - r), cols[0])
            x += rnd.uniform(14, 60)
    if bushes:
        x = rnd.uniform(0, 30)
        while x < w:
            tx = int(x) % w
            ty = tops[tx] + 2
            for dx in (-w, 0, w):
                p.disc(tx + dx, ty - 2, 5, cols[2])
                p.disc(tx + 5 + dx, ty - 3, 6, cols[2])
                p.disc(tx + 4 + dx, ty - 5, 4, cols[1])
                p.put(tx + 2 + dx, int(ty - 7), cols[0])
            x += rnd.uniform(40, 110)
    if flowers:
        fc = [hexc('#FFF4FA'), hexc('#FFD84D'), hexc('#FF7AA8'), hexc('#B98CFF')]
        for _ in range(w // 5):
            fx = rnd.randrange(w)
            fy = int(tops[fx] + rnd.uniform(3, 30))
            if fy < h:
                p.put(fx, fy, rnd.choice(fc))
    return p
