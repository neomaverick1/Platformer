"""App icon: the hero in front of a sky and a grassy hill (adaptive icon layers, pixel art)."""
import os
from PIL import Image
import hero as HERO
import bg as BG
from px import Pix, hexc

RES = '/home/claude/platformer/src/app/src/main/res'
S = 432        # 108 dp at 4x
K = 9          # pixel size

# background: dithered sky + a hill (drawn small, then scaled up with crisp pixels)
n = S // K  # 48
b = Pix(n, n)
sky = BG.sky(n).image()
for y in range(n):
    c = sky.getpixel((0, y))
    for x in range(n):
        b.put(x, y, c)
for x in range(n):
    import math
    top = int(34 + 3 * math.sin(x / 7.0))
    for y in range(top, n):
        g = hexc('#5DBE45') if y - top > 1 else hexc('#A6EA4C')
        if y - top > 5:
            g = hexc('#45A03C')
        b.put(x, y, g)
bg = b.image().resize((S, S), Image.NEAREST)

# foreground: idle hero, 8x, feet on the hill
names, frames = HERO.build()
h = frames[0].image()
fg = Image.new('RGBA', (S, S), (0, 0, 0, 0))
big = h.resize((h.width * 8, h.height * 8), Image.NEAREST)
fg.alpha_composite(big, ((S - big.width) // 2, 34 * K - big.height + 8 * 2))

os.makedirs(RES + '/drawable-nodpi', exist_ok=True)
bg.save(RES + '/drawable-nodpi/ic_launcher_bg.png', optimize=True)
fg.save(RES + '/drawable-nodpi/ic_launcher_fg.png', optimize=True)
os.makedirs(RES + '/mipmap-anydpi-v26', exist_ok=True)
open(RES + '/mipmap-anydpi-v26/ic_launcher.xml', 'w').write('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_bg" />
    <foreground android:drawable="@drawable/ic_launcher_fg" />
</adaptive-icon>
''')
prev = bg.copy(); prev.alpha_composite(fg)
# mask preview as a circle like most launchers
m = Image.new('L', (S, S), 0)
from PIL import ImageDraw
ImageDraw.Draw(m).ellipse((36, 36, S - 36, S - 36), fill=255)
out = Image.new('RGBA', (S, S), (30, 30, 40, 255)); out.paste(prev, (0, 0), m)
out.save('out/icon_preview.png')
print('icon ok')
