"""Grassy-hills tiles (16x16), drawn procedurally in a 32-bit era pixel style."""
import math
import random
from px import Pix, hexc, mix, shade

T = 16

# palette
G_TIP = hexc('#D8FF7A')
G_HI = hexc('#A6EA4C')
G_LT = hexc('#76CF34')
G_MD = hexc('#4BAA27')
G_DK = hexc('#2E7F22')
G_DD = hexc('#1C561C')
D_LT = hexc('#C88B55')
D_MD = hexc('#A2663B')
D_DK = hexc('#7B4628')
D_DD = hexc('#58301C')
D_XX = hexc('#3A1E14')
ST_LT = hexc('#D9CDBE')
ST_MD = hexc('#A89A8A')
ST_DK = hexc('#776A60')


def grass_depth(x, variant):
    """Depth of the grass band at column x (0..15). Ends match so tiles join seamlessly."""
    base = [4, 4, 5, 5, 4, 5, 6, 5, 4, 4, 5, 6, 6, 5, 4, 4]
    alt = [[0] * 16,
           [0, 0, 0, 1, 1, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0],
           [0, 0, 1, 0, 0, -1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0]][variant % 3]
    return base[x] + alt[x]


def dirt_texture(p, rnd, x0=0, y0=0, w=T, h=T):
    p.rect(x0, y0, w, h, D_MD)
    # soft clumps
    for _ in range(7):
        cx, cy = rnd.randrange(w), rnd.randrange(h)
        col = D_DK if rnd.random() < 0.6 else D_LT
        p.put(x0 + cx, y0 + cy, col)
        if rnd.random() < 0.7:
            p.put(x0 + (cx + 1) % w, y0 + cy, col)
    # tiny pebble
    if rnd.random() < 0.55:
        px_, py_ = rnd.randrange(2, w - 4), rnd.randrange(6, h - 3)
        p.put(x0 + px_, y0 + py_, ST_LT); p.put(x0 + px_ + 1, y0 + py_, ST_MD)
        p.put(x0 + px_, y0 + py_ + 1, ST_MD); p.put(x0 + px_ + 1, y0 + py_ + 1, ST_DK)
        p.put(x0 + px_ + 2, y0 + py_ + 1, D_DD)
    # dark speckles
    for _ in range(5):
        p.put(x0 + rnd.randrange(w), y0 + rnd.randrange(h), D_DD)
    # a root
    if rnd.random() < 0.35:
        rx, ry = rnd.randrange(3, w - 3), rnd.randrange(7, h - 2)
        for k in range(4):
            p.put(x0 + rx + k, y0 + ry + (1 if k in (1, 2) else 0), D_DD)


def ground_tile(mask, variant, seed):
    """mask bits: 1=solid above, 2=solid below, 4=solid left, 8=solid right."""
    up, down, left, right = bool(mask & 1), bool(mask & 2), bool(mask & 4), bool(mask & 8)
    rnd = random.Random(seed)
    p = Pix(T, T)
    dirt_texture(p, rnd)
    # deeper soil gets a touch darker towards the bottom of exposed bottoms
    if not down:
        for x in range(T):
            p.put(x, 15, D_XX)
            p.put(x, 14, D_DD)
            if rnd.random() < 0.3:
                p.put(x, 13, D_DK)
    if not left:
        for y in range(T):
            p.put(0, y, D_XX)
            p.put(1, y, D_DK if y % 3 else D_DD)
    if not right:
        for y in range(T):
            p.put(15, y, D_XX)
            p.put(14, y, D_DK if (y + 1) % 3 else D_DD)
    if not up:
        for x in range(T):
            d = grass_depth(x, variant)
            # body of the grass
            for y in range(0, d + 1):
                if y == 0:
                    c = G_HI
                elif y == 1:
                    c = G_LT
                elif y < d - 1:
                    c = G_MD
                elif y == d - 1:
                    c = G_DK
                else:
                    c = G_DD
                p.put(x, y, c)
            # a lit blade here and there
            if (x * 7 + variant * 3) % 5 == 0:
                p.put(x, 1, G_TIP)
            # drips of grass into the soil
            if (x * 5 + variant) % 7 == 0:
                p.put(x, d + 1, G_DD)
                p.put(x, d + 2, D_DD)
            else:
                p.put(x, d + 1, D_DD)
        # top highlight line
        for x in range(T):
            if (x + variant) % 4 != 1:
                p.put(x, 0, G_TIP if (x + variant) % 6 == 0 else G_HI)
        # grass wraps round exposed sides
        if not left:
            for y in range(0, 7):
                p.put(0, y, G_DK if y > 1 else G_MD)
                p.put(1, y, G_MD if y > 1 else G_LT)
            p.put(0, 7, G_DD); p.put(1, 8, G_DD)
            p.put(0, 0, (0, 0, 0, 0))
        if not right:
            for y in range(0, 7):
                p.put(15, y, G_DK if y > 1 else G_MD)
                p.put(14, y, G_MD if y > 1 else G_LT)
            p.put(15, 7, G_DD); p.put(14, 8, G_DD)
            p.put(15, 0, (0, 0, 0, 0))
    else:
        # inside the hill: a darker, cooler soil reads as depth
        pass
    # rounded bottom corners
    if not down and not left:
        p.put(0, 15, (0, 0, 0, 0)); p.put(1, 15, D_XX); p.put(0, 14, D_XX)
    if not down and not right:
        p.put(15, 15, (0, 0, 0, 0)); p.put(14, 15, D_XX); p.put(15, 14, D_XX)
    return p


def deep_tile(seed):
    """Soil far inside a hill: darker so the surface reads clearly."""
    rnd = random.Random(seed)
    p = Pix(T, T)
    dirt_texture(p, rnd)
    p.a[:, :, :3] = (p.a[:, :, :3].astype(int) * 0.82).astype('uint8')
    return p


# ---------------------------------------------------------------- stone blocks
S_HI = hexc('#E2E6EE')
S_LT = hexc('#B9C0CE')
S_MD = hexc('#8C93A8')
S_DK = hexc('#5F6580')
S_DD = hexc('#3B3F58')
MOSS = hexc('#5DB83A')
MOSS_D = hexc('#3A8A2A')


def stone_tile(mask, seed):
    up, down, left, right = bool(mask & 1), bool(mask & 2), bool(mask & 4), bool(mask & 8)
    rnd = random.Random(seed)
    p = Pix(T, T)
    # two rows of bricks with offset joints
    p.rect(0, 0, T, T, S_MD)
    for (y0, off) in ((0, 0), (8, 8)):
        for bx in range(-off, T, 16):
            x0 = bx
            # brick body
            for y in range(y0, y0 + 8):
                for x in range(max(0, x0), min(T, x0 + 16)):
                    p.put(x, y, S_MD)
            for x in range(max(0, x0), min(T, x0 + 16)):
                p.put(x, y0, S_LT)
                p.put(x, y0 + 7, S_DK)
            if 0 <= x0 < T:
                for y in range(y0, y0 + 8):
                    p.put(x0, y, S_DD)
                    if x0 + 1 < T:
                        p.put(x0 + 1, y, S_LT)
    # chips and speckles
    for _ in range(6):
        p.put(rnd.randrange(T), rnd.randrange(T), S_DK if rnd.random() < 0.5 else S_LT)
    if not up:
        for x in range(T):
            p.put(x, 0, S_HI)
            if (x * 3 + seed) % 5 < 3:
                p.put(x, 0, MOSS)
                p.put(x, 1, MOSS_D if x % 2 else MOSS)
                if (x + seed) % 4 == 0:
                    p.put(x, 2, MOSS_D)
    if not down:
        for x in range(T):
            p.put(x, 15, S_DD)
    if not left:
        for y in range(T):
            p.put(0, y, S_DD)
    if not right:
        for y in range(T):
            p.put(15, y, S_DD)
    return p


# ---------------------------------------------------------------- wood bridge
W_HI = hexc('#F1C27D')
W_LT = hexc('#D49A57')
W_MD = hexc('#A8703A')
W_DK = hexc('#7A4A24')
W_DD = hexc('#4E2C16')
ROPE = hexc('#E8D7A8')
ROPE_D = hexc('#B49A68')


def bridge_tile(kind):
    """kind 0 = middle, 1 = left end (post), 2 = right end (post)."""
    p = Pix(T, T)
    # planks along the top 6 px
    for x in range(T):
        seam = x in (0, 8)
        p.put(x, 0, W_HI if not seam else W_DK)
        for y in range(1, 4):
            p.put(x, y, (W_LT if y == 1 else W_MD) if not seam else W_DK)
        p.put(x, 4, W_DK)
        p.put(x, 5, W_DD)
    for x in (3, 11):
        p.put(x, 2, W_DK)  # nail
    # rope loops underneath
    for x in range(T):
        y = 7 + int(round(2.2 * math.sin(math.pi * x / 16.0)))
        p.put(x, y, ROPE)
        p.put(x, y + 1, ROPE_D)
    if kind in (1, 2):
        px0 = 1 if kind == 1 else 12
        for y in range(-0, 16):
            for x in range(px0, px0 + 3):
                c = W_MD if x == px0 + 1 else (W_LT if x == px0 else W_DK)
                p.put(x, y, c)
        p.rect(px0 - 1, 0, 5, 1, W_HI)
        p.rect(px0 - 1, 1, 5, 1, W_DK)
    return p


# ---------------------------------------------------------------- blocks
GOLD_HI = hexc('#FFF2A8')
GOLD_LT = hexc('#FFD34E')
GOLD_MD = hexc('#E8A21E')
GOLD_DK = hexc('#A8640F')
GOLD_DD = hexc('#5E3208')
GEM_HI = hexc('#E9FFF0')
GEM_LT = hexc('#7CF5B6')
GEM_MD = hexc('#20C98A')
GEM_DK = hexc('#11805E')


def prize_block(frame):
    """Golden rune block with a gem that glints (4 frames)."""
    p = Pix(T, T)
    p.rect(0, 0, T, T, GOLD_MD)
    for i in range(T):
        p.put(i, 0, GOLD_HI); p.put(0, i, GOLD_HI)
        p.put(i, 1, GOLD_LT); p.put(1, i, GOLD_LT)
        p.put(i, 15, GOLD_DD); p.put(15, i, GOLD_DD)
        p.put(i, 14, GOLD_DK); p.put(14, i, GOLD_DK)
    # rivets
    for (x, y) in ((3, 3), (12, 3), (3, 12), (12, 12)):
        p.put(x, y, GOLD_HI); p.put(x + 1, y + 1, GOLD_DK)
    # gem (diamond)
    gem = [
        "....hl....",
        "...hlmm...",
        "..hlmmmd..",
        ".hlmmmmdd.",
        "hlmmmmmmdd",
        ".lmmmmmdd.",
        "..mmmmdd..",
        "...mmdd...",
        "....dd....",
    ]
    pal = {'h': GEM_HI, 'l': GEM_LT, 'm': GEM_MD, 'd': GEM_DK}
    p.from_rows(gem, pal, 3, 3)
    # glint sweeps across the gem
    gx = [4, 6, 8, 20][frame]
    for k in range(3):
        x, y = 3 + gx - k, 4 + k
        if 0 <= gx < 12:
            p.put(x, y, GEM_HI)
    return p


def used_block():
    p = Pix(T, T)
    p.rect(0, 0, T, T, hexc('#8A6A4E'))
    for i in range(T):
        p.put(i, 0, hexc('#B48E6A')); p.put(0, i, hexc('#B48E6A'))
        p.put(i, 15, hexc('#4A3424')); p.put(15, i, hexc('#4A3424'))
    for (x, y) in ((3, 3), (12, 3), (3, 12), (12, 12)):
        p.put(x, y, hexc('#5E4532'))
    return p


def crate():
    p = Pix(T, T)
    p.rect(0, 0, T, T, W_MD)
    for i in range(T):
        p.put(i, 0, W_HI); p.put(i, 1, W_LT); p.put(i, 15, W_DD); p.put(i, 14, W_DK)
        p.put(0, i, W_LT); p.put(15, i, W_DD)
    for y in (5, 10):
        for x in range(1, 15):
            p.put(x, y, W_DK)
    # diagonal brace
    for k in range(2, 14):
        p.put(k, k, W_LT); p.put(k + 1, k, W_DK)
    for (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13)):
        p.put(x, y, hexc('#CFCFD8'))
    return p


def spikes():
    p = Pix(T, T)
    base = hexc('#6D6F86')
    for x in range(T):
        p.put(x, 15, hexc('#3B3D52'))
        p.put(x, 14, base)
        p.put(x, 13, hexc('#9A9CB4'))
    for cx in (2.5, 7.5, 12.5):
        for y in range(4, 13):
            half = (y - 4) * 0.28 + 0.5
            for x in range(int(cx - half), int(cx + half) + 1):
                if x < cx - 0.2:
                    c = hexc('#F3F5FF')
                elif x < cx + 0.8:
                    c = hexc('#B8BCD6')
                else:
                    c = hexc('#757A99')
                p.put(x, y, c)
        p.put(int(cx), 3, hexc('#FFFFFF'))
    return p


def spring(frame):
    """Spring board: 0 = ready, 1 = squashed."""
    p = Pix(T, T)
    top = 6 if frame == 0 else 10
    # base
    p.rect(1, 13, 14, 3, hexc('#4A4E66'))
    p.rect(1, 13, 14, 1, hexc('#7A7FA0'))
    # coil
    for y in range(top + 2, 13):
        x0 = 4 if (y % 2 == 0) else 5
        p.rect(x0, y, 7, 1, hexc('#C9CDE0') if y % 2 == 0 else hexc('#8E93AE'))
    # pad
    p.rect(0, top, 16, 3, hexc('#E8473C'))
    p.rect(0, top, 16, 1, hexc('#FF8A7A'))
    p.rect(0, top + 2, 16, 1, hexc('#9E2420'))
    return p
