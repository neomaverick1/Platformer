"""Draws the whole level with the real art, to review the layout."""
from PIL import Image
from px import Pix, hexc, preview
import tiles as TL, sprites as S, hero as HERO
import level as LV

M = LV.MAP; W, H = LV.W, LV.H
img = Image.new('RGBA', (W * 16, H * 16), (150, 205, 250, 255))
def isg(x, y):
    if x < 0 or x >= W: return True
    if y >= H: return True
    if y < 0: return False
    return M[y][x] in '#%'
cache = {}
def tile(name, *a):
    k = (name,) + a
    if k not in cache:
        cache[k] = getattr(TL, name)(*a).image()
    return cache[k]
for y in range(H):
    for x in range(W):
        ch = M[y][x]; X, Y = x * 16, y * 16
        if ch in '#%':
            mask = (1 if isg(x, y-1) else 0) | (2 if isg(x, y+1) else 0) | (4 if isg(x-1, y) else 0) | (8 if isg(x+1, y) else 0)
            img.alpha_composite(tile('ground_tile', mask, (x*7+y*3) % 3, mask*97 + ((x*7+y*3)%3)*13 + 5), (X, Y))
            if ch == '%':
                img.alpha_composite(Image.new('RGBA', (16, 16), (255, 0, 255, 70)), (X, Y))
        elif ch == 'S':
            img.alpha_composite(tile('stone_tile', 0, 3), (X, Y))
        elif ch == '=':
            img.alpha_composite(tile('bridge_tile', 0), (X, Y))
        elif ch in '?$!FUD*':
            img.alpha_composite(tile('prize_block', 0), (X, Y))
        elif ch == 'X':
            img.alpha_composite(tile('crate'), (X, Y))
        elif ch == '^':
            img.alpha_composite(tile('spikes'), (X, Y))
        elif ch == 'Z':
            img.alpha_composite(tile('spring', 0), (X, Y))
for y in range(H):
    for x in range(W):
        ch = M[y][x]; X, Y = x * 16, y * 16
        def spr(p, dx=0, dy=0):
            img.alpha_composite(p.image(), (X + dx, Y + dy))
        if ch == 'o': spr(S.coin(0))
        elif ch == 'G': spr(S.gem(0))
        elif ch == '@': spr(HERO.build()[1][0], -8, -16)
        elif ch == 'C': spr(S.checkpoint(0, False), 0, -16)
        elif ch == 'E': spr(S.portal(0), -8, -32)
        elif ch == 'b': spr(S.beetle(0), -4, 0)
        elif ch == 'w': spr(S.hornet(0), -4, -4)
        elif ch == 'g': spr(S.hedgehog(0), -4, 0)
        elif ch == 'r': spr(S.frog(0), -4, -4)
        elif ch == 't': spr(S.tree(), -16, -48)
        elif ch == 'u': spr(S.bush(), -8, 0)
        elif ch == 'y': spr(S.flower(x % 5, 0))
        elif ch == 'n': spr(S.sign(0))
        elif ch == 'N': spr(S.sign(1))
        elif ch == 'l': spr(S.fence())
        elif ch == 'k': spr(S.rock())
        elif ch == 'm': spr(S.mushroom(0))
        elif ch in 'MV':
            for k in range(3):
                img.alpha_composite(Image.new('RGBA', (16, 8), (200, 140, 80, 255)), (X + k * 16, Y))
        if ch in '?$!FUD*':
            lab = {'?':'c','$':'$','!':'H','F':'F','U':'U','D':'D','*':'*'}[ch]
# grid lines every 10 tiles + labels
from PIL import ImageDraw
d = ImageDraw.Draw(img)
for x in range(0, W, 10):
    d.line([(x*16, 0), (x*16, H*16)], fill=(255, 255, 255, 90))
    d.text((x*16+2, 2), str(x), fill=(0, 0, 0, 255))
for y in range(0, H, 4):
    d.text((2, y*16+2), str(y), fill=(0, 0, 0, 255))
# split into 3 strips for viewing
strip = W * 16 // 3 + 16
for i in range(3):
    x0 = i * (W * 16 // 3)
    part = img.crop((x0, 0, min(W*16, x0 + strip), H * 16))
    part = part.resize((part.width * 2, part.height * 2), Image.NEAREST)
    part.convert('RGB').save('out/level_%d.png' % i)
print('ok', img.size)
