package com.neomaverick.platformer

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * Draws the game at a small fixed pixel size (about 585 x 270) into a bitmap, then scales that
 * up by a whole number with no smoothing, so every pixel stays crisp. Logic runs at a steady
 * 60 steps a second whatever the screen's refresh rate.
 */
@SuppressLint("ViewConstructor")
class GameView(ctx: Context) : View(ctx) {
    val gfx = Gfx(resources)
    val audio = Audio(ctx)
    val input = Input()
    val game = Game(gfx, audio, ctx.getSharedPreferences("game", Context.MODE_PRIVATE), input)

    private var frame: Bitmap? = null
    private var fc: Canvas? = null
    private var scale = 4
    private var offX = 0
    private var offY = 0
    private val dst = Rect()
    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false; isDither = false }
    private var lastNs = 0L
    private var acc = 0f
    private var running = true

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        keepScreenOn = true
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        scale = max(1, (h + 135) / 270)
        val vh = h / scale
        val vw = w / scale
        val bmp = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888)
        frame = bmp
        fc = Canvas(bmp)
        offX = (w - vw * scale) / 2
        offY = (h - vh * scale) / 2
        dst.set(offX, offY, offX + vw * scale, offY + vh * scale)
        game.resize(vw, vh)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNs == 0L) STEP else (now - lastNs) / 1_000_000_000f
        lastNs = now
        if (dt > 0.1f) dt = 0.1f
        if (dt < 0f) dt = 0f
        if (running) {
            acc += dt
            var n = 0
            while (acc >= STEP && n < 5) {
                try { game.update(STEP) } catch (e: Exception) { }
                acc -= STEP
                n++
            }
            if (n == 5) acc = 0f
        }
        val bmp = frame
        val canvas = fc
        if (bmp != null && canvas != null) {
            try { game.render(canvas) } catch (e: Exception) { }
            c.drawColor(0xFF000000.toInt())
            c.drawBitmap(bmp, null, dst, paint)
        }
        if (running) postInvalidateOnAnimation()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN ->
                input.down(e.getPointerId(i), gx(e.getX(i)), gy(e.getY(i)))
            MotionEvent.ACTION_MOVE ->
                for (k in 0 until e.pointerCount) input.move(e.getPointerId(k), gx(e.getX(k)), gy(e.getY(k)))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> input.up(e.getPointerId(i))
            MotionEvent.ACTION_CANCEL -> input.cancelAll()
        }
        return true
    }

    private fun gx(x: Float) = (x - offX) / scale
    private fun gy(y: Float) = (y - offY) / scale

    fun key(code: Int, down: Boolean) = input.key(code, down)

    /** Back button; true when the game handled it. */
    fun back(): Boolean = game.onBack()

    fun pause() {
        running = false
        input.cancelAll()
        game.onAppPause()
        audio.pause()
    }

    fun resume() {
        running = true
        lastNs = 0L
        acc = 0f
        if (game.state != Game.PAUSE) audio.resume()
        invalidate()
    }

    fun release() = audio.release()
}
