package com.neomaverick.platformer

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

const val TS = 16
const val STEP = 1f / 60f

fun approach(v: Float, target: Float, d: Float) = if (v < target) min(v + d, target) else max(v - d, target)

object Rnd {
    private val r = java.util.Random()
    fun seed(s: Long) = r.setSeed(s)
    fun f(a: Float, b: Float) = a + r.nextFloat() * (b - a)
    fun i(n: Int) = if (n <= 0) 0 else r.nextInt(n)
    fun chance(p: Float) = r.nextFloat() < p
}

/** Anything with a box. (x, y) is the middle of its feet. */
open class Body(var w: Float, var h: Float) {
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 0f
    var onGround = false
    /** -1 / +1 when the last horizontal move ran into a wall on that side. */
    var hitWall = 0
    var hitCeil = false
    val left get() = x - w / 2f
    val right get() = x + w / 2f
    val top get() = y - h
    val cx get() = x
    val cy get() = y - h / 2f

    fun overlaps(o: Body) = left < o.right && right > o.left && top < o.y && y > o.top
    fun overlaps(l: Float, t: Float, r: Float, b: Float) = left < r && right > l && top < b && y > t
}

// ------------------------------------------------------------------------------ enemies
class Enemy(val type: Int, x0: Float, y0: Float) : Body(16f, 12f) {
    companion object {
        const val ALIVE = 0
        const val SQUASHED = 1
        const val FALLING = 2
        const val GONE = 3
    }

    var state = ALIVE
    var dir = -1
    var t = Rnd.f(0f, 2f)
    var stateT = 0f
    var active = false
    val homeX = x0
    val homeY = y0
    var hopT = Rnd.f(0.6f, 1.4f)
    var landT = 0f
    var flipY = false

    init {
        x = x0; y = y0
        when (type) {
            G.E_HORNET -> { w = 14f; h = 12f }
            G.E_FROG -> { w = 16f; h = 13f }
            else -> { w = 16f; h = 12f }
        }
    }

    val stompable get() = type != G.E_HEDGEHOG
    val alive get() = state == ALIVE
}

// ------------------------------------------------------------------------------ pickups
class Item(val kind: Int, x0: Float, y0: Float) : Body(10f, 12f) {
    companion object {
        const val COIN = 0
        const val GEM = 1
        const val HEART = 2
        const val FEATHER = 3
        const val SUN = 4
        const val SHIELD = 5
        const val STAR = 6
    }

    var t = Rnd.f(0f, 1f)
    /** Seconds left while it rises out of a block. */
    var emerge = 0f
    var blockTop = 0f
    var baseY = y0
    var taken = false
    /** Hidden inside fake ground (secret area). */
    var hidden = false
    /** Index of the map cell it came from (gems are remembered across lives). */
    var cell = -1

    init {
        x = x0; y = y0
        if (kind == GEM) { w = 12f; h = 14f }
        if (kind == STAR) vx = 55f
    }
}

/** A sun orb thrown with the sunflower power. */
class Orb(x0: Float, y0: Float, val dir: Int) : Body(8f, 8f) {
    var life = 2.4f
    var t = 0f
    var dead = false

    init { x = x0; y = y0; vx = dir * 215f; vy = 40f }
}

/** A floating wooden raft that slides left-right or bobs up-down (3 tiles wide). */
class Platform(val x0: Float, val y0: Float, val vertical: Boolean, val phase: Float) {
    val w = 48f
    var x = x0
    var y = y0
    var dx = 0f
    var dy = 0f
    var prevY = y0
    private var t = 0f
    private val amp = if (vertical) 36f else 32f
    private val period = 3.6f

    fun update(dt: Float) {
        t += dt
        val s = sin((t / period * 2.0 * PI + phase).toFloat())
        val nx = if (vertical) x0 else x0 + amp * s
        val ny = if (vertical) y0 + amp * s else y0
        dx = nx - x; dy = ny - y
        prevY = y
        x = nx; y = ny
    }
}

class Spring(val tx: Int, val ty: Int) {
    val x = tx * TS + 8f
    val top = ty * TS + 6f
    var squash = 0f
}

class Flag(val tx: Int, val ty: Int) {
    var active = false
    var t = 0f
    val x = tx * TS + 8f
    val y = (ty + 1) * TS.toFloat()
}

class Portal(val tx: Int, val ty: Int) {
    val x = tx * TS + 8f
    val y = (ty + 1) * TS.toFloat()
    var t = 0f
}

/** Scenery: drawn into the static layer (trees, signs...) or animated each frame (flowers, tufts). */
class Decor(val kind: Int, val x: Int, val y: Int, val v: Int) {
    companion object {
        const val TREE = 0
        const val BUSH = 1
        const val SIGN = 2
        const val FENCE = 3
        const val ROCK = 4
        const val MUSHROOM = 5
        const val FLOWER = 6
        const val TUFT = 7
    }
    val phase = ((x * 7 + y * 13) % 100) / 100f
}

class Butterfly(val hx: Float, val hy: Float) {
    var t = Rnd.f(0f, 10f)
    var x = hx
    var y = hy
    val sx = Rnd.f(0.6f, 1.1f)
    val sy = Rnd.f(1.1f, 1.7f)
}

// ------------------------------------------------------------------------------ effects
/** A short sprite animation from the 16x16 sheet, with optional motion. */
class Fx(
    var x: Float, var y: Float, val base: Int, val frames: Int, val fps: Float,
    var vx: Float = 0f, var vy: Float = 0f, val grav: Float = 0f, val loop: Boolean = false, var life: Float = -1f,
) {
    var t = 0f
    /** Seconds before it appears. */
    var delay = 0f
    init { if (life < 0f) life = frames / fps }
    val frame get() = if (loop) ((t * fps).toInt() % frames) else min(frames - 1, (t * fps).toInt())
}

/** Little wood or dirt chips (crate break). */
class Chip(var x: Float, var y: Float, var vx: Float, var vy: Float, val color: Int, val size: Int) {
    var t = 0f
    var rot = Rnd.f(0f, 360f)
}

/** Floating text (score, 1UP). */
class Pop(val text: String, var x: Float, var y: Float, val gold: Boolean) {
    var t = 0f
}

/** The two tails of the hero's headband, simulated as little chains. */
class Ribbon {
    val n = 5
    val xs = Array(2) { FloatArray(n) }
    val ys = Array(2) { FloatArray(n) }
    val pxs = Array(2) { FloatArray(n) }
    val pys = Array(2) { FloatArray(n) }
    private var init = false

    fun update(kx: Float, ky: Float, facing: Int, speed: Float, t: Float) {
        if (!init) {
            for (k in 0..1) for (i in 0 until n) {
                xs[k][i] = kx - facing * i * 2f; ys[k][i] = ky + i
                pxs[k][i] = xs[k][i]; pys[k][i] = ys[k][i]
            }
            init = true
        }
        for (k in 0..1) {
            val xa = xs[k]; val ya = ys[k]; val px = pxs[k]; val py = pys[k]
            xa[0] = kx; ya[0] = ky
            px[0] = kx; py[0] = ky
            for (i in 1 until n) {
                // verlet with a little gravity and a breeze that grows with speed
                val vx = (xa[i] - px[i]) * 0.86f
                val vy = (ya[i] - py[i]) * 0.86f
                px[i] = xa[i]; py[i] = ya[i]
                val flutter = sin(t * (16f + k * 5f) + i * 1.3f) * (0.12f + abs(speed) * 0.0022f)
                xa[i] += vx - facing * 0.22f
                ya[i] += vy + 0.16f + flutter - (if (k == 0) 0.04f else 0f)
            }
            val seg = if (k == 0) 2.6f else 2.2f
            for (rep in 0..1) for (i in 1 until n) {
                val dx = xa[i] - xa[i - 1]
                val dy = ya[i] - ya[i - 1]
                val d = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
                val f = seg / d
                xa[i] = xa[i - 1] + dx * f
                ya[i] = ya[i - 1] + dy * f
            }
        }
    }

    fun reset() { init = false }
}

fun wave(t: Float, speed: Float) = sin(t * speed)
fun wavec(t: Float, speed: Float) = cos(t * speed)
