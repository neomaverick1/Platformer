package com.neomaverick.platformer

import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Screens, lives, score, the heads-up display, menus and transitions. */
class Game(val gfx: Gfx, val audio: Audio, private val prefs: SharedPreferences, val input: Input) {
    companion object {
        const val TITLE = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val DYING = 3
        const val GAMEOVER = 4
        const val CLEAR = 5
        const val START_LIVES = 3
    }

    var vw = 585
    var vh = 270
    var state = TITLE
    var stateT = 0f
    var t = 0f

    // the run
    var lives = START_LIVES
    var coins = 0
    var score = 0
    var runTime = 0f
    val gemsFound = HashSet<Int>()
    var checkpointCell = -1
    private var startCellX = 3
    private var startCellY = 18

    lateinit var world: World

    // transition: a circle that closes on the hero and opens again
    private var iris = 1f
    private var irisTarget = 1f
    private var irisDone: (() -> Unit)? = null
    private var shakeT = 0f
    private var shakeAmp = 0f
    private var newBest = false
    private var lastCleared = false

    private val fill = Paint().apply { isAntiAlias = false }
    private val dimPaint = Paint().apply { isFilterBitmap = false; alpha = 70 }
    private val btnPaint = Paint().apply { isFilterBitmap = false; alpha = 190 }
    private val irisPath = Path()
    private val src = Rect()
    private val dst = Rect()

    // pause menu
    private val menu = arrayOf("RESUME", "RESTART", "SOUND", "QUIT")
    private val menuRects = Array(4) { Rect() }

    init {
        for ((ty, row) in LevelData.MAP.withIndex()) {
            val tx = row.indexOf('@')
            if (tx >= 0) { startCellX = tx; startCellY = ty }
        }
        newWorld()
        audio.music(R.raw.music_hills, vol = 0.4f)
    }

    fun resize(w: Int, h: Int) {
        vw = w; vh = h
        input.vw = w; input.vh = h
        world.snapCamera()
    }

    private fun newWorld() {
        val (sx, sy) = if (checkpointCell >= 0) {
            val cols = LevelData.MAP[0].length
            Pair((checkpointCell % cols) * TS + 8f, (checkpointCell / cols + 1) * TS.toFloat())
        } else Pair(startCellX * TS + 8f, (startCellY + 1) * TS.toFloat())
        world = World(this, sx, sy)
        input.fireEnabled = false
    }

    private fun resetRun() {
        lives = START_LIVES
        coins = 0
        score = 0
        runTime = 0f
        gemsFound.clear()
        checkpointCell = -1
        newWorld()
    }

    private fun go(s: Int) { state = s; stateT = 0f }

    private fun irisTo(target: Float, then: (() -> Unit)? = null) {
        irisTarget = target
        irisDone = then
    }

    // ------------------------------------------------------------------ scoring hooks
    fun addScore(n: Int, x: Float = Float.NaN, y: Float = Float.NaN) {
        score += n
        if (!x.isNaN()) world.pop(n.toString(), x, y, gold = false)
    }

    fun addCoin() {
        coins++
        score += 10
        if (coins % 100 == 0) { addLife(); world.pop("1UP", world.hero.x, world.hero.top - 10f) }
    }

    fun addLife() {
        lives = min(99, lives + 1)
        audio.play(R.raw.sfx_heart, 1f, 1.25f)
    }

    fun shake(a: Float) { shakeT = 0.18f; shakeAmp = a }

    fun onHeroDied() {
        audio.stopMusic()
        audio.play(R.raw.jingle_die)
        go(DYING)
    }

    fun onClear() {
        audio.stopMusic()
        audio.play(R.raw.jingle_clear)
        val bestTime = prefs.getFloat("best_time", 0f)
        val bestCoins = prefs.getInt("best_coins", 0)
        val bestGems = prefs.getInt("best_gems", 0)
        newBest = bestTime <= 0f || runTime < bestTime || coins > bestCoins || gemsFound.size > bestGems
        prefs.edit()
            .putFloat("best_time", if (bestTime <= 0f) runTime else min(bestTime, runTime))
            .putInt("best_coins", max(bestCoins, coins))
            .putInt("best_gems", max(bestGems, gemsFound.size))
            .putInt("clears", prefs.getInt("clears", 0) + 1)
            .apply()
        lastCleared = true
        go(CLEAR)
    }

    /** Back button: true when the game used it. */
    fun onBack(): Boolean = when (state) {
        PLAY -> { pause(); true }
        PAUSE -> { unpause(); true }
        CLEAR, GAMEOVER -> { toTitle(); true }
        else -> false
    }

    fun onAppPause() { if (state == PLAY) pause() }

    private fun pause() {
        go(PAUSE)
        audio.play(R.raw.sfx_pause)
        audio.pause()
    }

    private fun unpause() {
        audio.resume()
        go(PLAY)
    }

    private fun toTitle() {
        resetRun()
        iris = 0f
        irisTo(1f)
        audio.music(R.raw.music_hills, vol = 0.4f)
        go(TITLE)
    }

    private fun startPlay() {
        audio.music(R.raw.music_hills)
        go(PLAY)
    }

    // ------------------------------------------------------------------ update
    fun update(dt: Float) {
        t += dt
        stateT += dt
        shakeT = max(0f, shakeT - dt)
        if (iris != irisTarget) {
            iris = if (iris < irisTarget) min(irisTarget, iris + dt * 2.2f) else max(irisTarget, iris - dt * 2.2f)
            if (iris == irisTarget) { val d = irisDone; irisDone = null; d?.invoke() }
        }
        input.fireEnabled = state == PLAY && world.hero.hasSun
        // while the circle closes for a scene change, everything holds still
        if (irisDone != null && irisTarget < iris && state != DYING) { input.clearEdges(); return }
        when (state) {
            TITLE -> {
                world.time += dt
                world.hero.t += dt
                world.hero.idleT += dt
                if (input.anyTap && stateT > 0.4f && irisDone == null) {
                    audio.play(R.raw.sfx_portal, 0.6f)
                    irisTo(0f) { resetRun(); startPlay(); irisTo(1f) }
                }
                tickWorldIdle(dt)
            }
            PLAY -> {
                if (input.pausePressed) { pause(); input.clearEdges(); return }
                world.update(dt)
                if (!world.clearing && !world.hero.dead) runTime += dt
            }
            PAUSE -> {
                if (input.pausePressed) unpause()
                else if (input.anyTap && input.tapY >= 0f) {
                    for ((k, r) in menuRects.withIndex()) {
                        if (r.contains(input.tapX.toInt(), input.tapY.toInt())) {
                            when (k) {
                                0 -> unpause()
                                1 -> { audio.resume(); go(PLAY); irisTo(0f) { resetRun(); startPlay(); irisTo(1f) } }
                                2 -> { audio.setMuted(!audio.muted); audio.pause(); audio.play(R.raw.sfx_coin) }
                                3 -> { audio.resume(); irisTo(0f) { toTitle() } }
                            }
                        }
                    }
                }
            }
            DYING -> {
                world.update(dt)
                if (stateT > 2.6f && irisDone == null && iris > 0f) {
                    irisTo(0f) {
                        lives--
                        if (lives > 0) {
                            newWorld()
                            startPlay()
                            irisTo(1f)
                        } else {
                            go(GAMEOVER)
                            irisTo(1f)
                        }
                    }
                }
            }
            GAMEOVER -> {
                if (input.anyTap && stateT > 1.4f && irisDone == null) irisTo(0f) { toTitle() }
            }
            CLEAR -> {
                world.update(dt)
                if (input.anyTap && stateT > 4f && irisDone == null) irisTo(0f) { toTitle() }
            }
        }
        input.clearEdges()
    }

    /** Keep the scenery alive behind the title. */
    private fun tickWorldIdle(dt: Float) {
        val w = world
        for (p in w.platforms) p.update(dt)
        for (b in w.butterflies) {
            b.t += dt
            b.x = b.hx + sin(b.t * b.sx) * 26f + sin(b.t * 2.3f) * 6f
            b.y = b.hy + sin(b.t * b.sy) * 9f
        }
        val h = w.hero
        val f = h.frame()
        val kx = if (h.facing > 0) G.KNOT[f * 2] else 31 - G.KNOT[f * 2]
        h.ribbon.update(h.x.roundToInt() - 16 + kx + 0.5f, h.y.roundToInt() - 32 + G.KNOT[f * 2 + 1] + 0.5f, h.facing, 0f, w.time)
    }

    // ------------------------------------------------------------------ drawing
    fun render(c: Canvas) {
        val w = world
        val sx = if (shakeT > 0f) Rnd.f(-shakeAmp, shakeAmp).roundToInt() else 0
        val sy = if (shakeT > 0f) Rnd.f(-shakeAmp, shakeAmp).roundToInt() else 0
        val cx = w.camX; val cy = w.camY
        w.camX = (cx + sx).coerceIn(0, max(0, w.pxW - vw))
        w.camY = (cy + sy).coerceIn(0, max(0, w.pxH - vh))
        w.render(c)
        w.camX = cx; w.camY = cy

        when (state) {
            TITLE -> drawTitle(c)
            PLAY, DYING -> { drawHud(c); if (state == PLAY) drawButtons(c) }
            PAUSE -> { drawHud(c); drawPause(c) }
            GAMEOVER -> drawGameOver(c)
            CLEAR -> { drawHud(c); drawClear(c) }
        }
        drawIris(c)
    }

    private fun shade(c: Canvas, a: Int) {
        fill.color = (a shl 24) or 0x0A0618
        c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), fill)
    }

    private fun timeText(s: Float): String {
        val total = s.toInt()
        return "%d:%02d".format(total / 60, total % 60)
    }

    private fun drawHud(c: Canvas) {
        val h = world.hero
        for (k in 0 until 3) gfx.spr(c, G.S_UIHEART + if (k < h.hearts) 0 else 2, 4 + k * 13, 3)
        var px = 46
        if (h.shield) { gfx.spr(c, G.S_SHIELD, px, 3); px += 15 }
        if (h.hasFeather) { gfx.spr(c, G.S_FEATHER, px, 3); px += 15 }
        if (h.hasSun) { gfx.spr(c, G.S_SUNFLOWER, px, 3); px += 15 }
        if (h.starT > 0f && ((h.starT > 2f) || ((t * 8f).toInt() % 2 == 0))) gfx.spr(c, G.S_STAR + ((t * 10f).toInt() % 4), px, 3)
        // coins, gems, lives
        gfx.spr(c, G.S_COIN, 4, 19)
        gfx.text(c, "x" + coins, 19, 23)
        for (k in 0 until 3) {
            val got = k < gemsFound.size
            gfx.spr(c, G.S_GEM, 52 + k * 13, 19, if (got) gfx.paint else dimPaint)
        }
        src.set(7, 0, 25, 18)
        dst.set(96, 18, 114, 36)
        c.drawBitmap(gfx.hero, src, dst, gfx.paint)
        gfx.text(c, "x" + lives, 116, 23)
        // score and time
        gfx.text(c, "%06d".format(score), vw / 2, 6, align = 1)
        gfx.text(c, timeText(runTime), vw - 44, 6, gold = true, align = 2)
        gfx.button(c, 4, false, vw - 36, 4, btnPaint)
    }

    private fun drawButtons(c: Canvas) {
        val i = input
        gfx.button(c, 0, i.left, i.leftX - 16, i.padY - 16, btnPaint)
        gfx.button(c, 1, i.right, i.rightX - 16, i.padY - 16, btnPaint)
        gfx.button(c, 2, i.jumpHeld, i.jumpX - 16, i.jumpY - 16, btnPaint)
        if (i.fireEnabled) gfx.button(c, 3, i.fireHeld, i.fireX - 16, i.fireY - 16, btnPaint)
    }

    private fun drawTitle(c: Canvas) {
        fill.color = 0x66000000
        c.drawRect(0f, 30f, vw.toFloat(), 104f, fill)
        gfx.text(c, "STAGE 1", vw / 2, 40, gold = true, align = 1)
        val bob = (sin(t * 2f) * 2f).roundToInt()
        gfx.title(c, LevelData.NAME, vw / 2, 58 + bob, gold = true)
        gfx.text(c, "COINS, 3 HIDDEN GEMS AND A PORTAL", vw / 2, 86, align = 1)
        if ((t * 2.2f).toInt() % 2 == 0 && iris >= 1f) gfx.title(c, "TAP TO START", vw / 2, (vh * 0.62f).toInt())
        val best = prefs.getFloat("best_time", 0f)
        if (best > 0f) {
            val line = "BEST  " + timeText(best) + "   COINS " + prefs.getInt("best_coins", 0) + "   GEMS " + prefs.getInt("best_gems", 0) + "/3"
            fill.color = 0x66000000
            c.drawRect(0f, vh - 22f, vw.toFloat(), vh - 6f, fill)
            gfx.text(c, line, vw / 2, vh - 18, gold = true, align = 1)
        }
    }

    private fun drawPause(c: Canvas) {
        shade(c, 0xA0)
        gfx.title(c, "PAUSED", vw / 2, vh / 2 - 78)
        val bw = 150
        val bh = 24
        for (k in 0 until 4) {
            val x = vw / 2 - bw / 2
            val y = vh / 2 - 48 + k * 30
            menuRects[k].set(x, y, x + bw, y + bh)
            fill.color = 0xE01B2244.toInt()
            c.drawRect(x.toFloat(), y.toFloat(), (x + bw).toFloat(), (y + bh).toFloat(), fill)
            fill.color = 0xFFB9D7FF.toInt()
            c.drawRect(x.toFloat(), y.toFloat(), (x + bw).toFloat(), y + 1f, fill)
            c.drawRect(x.toFloat(), (y + bh - 1).toFloat(), (x + bw).toFloat(), (y + bh).toFloat(), fill)
            c.drawRect(x.toFloat(), y.toFloat(), x + 1f, (y + bh).toFloat(), fill)
            c.drawRect((x + bw - 1).toFloat(), y.toFloat(), (x + bw).toFloat(), (y + bh).toFloat(), fill)
            val label = if (k == 2) "SOUND: " + (if (audio.muted) "OFF" else "ON") else menu[k]
            gfx.text(c, label, vw / 2, y + 8, gold = k == 0, align = 1)
        }
    }

    private fun drawGameOver(c: Canvas) {
        shade(c, 0xC0)
        gfx.title(c, "GAME OVER", vw / 2, vh / 2 - 30, gold = false)
        gfx.text(c, "SCORE " + "%06d".format(score) + "   COINS " + coins, vw / 2, vh / 2 + 4, align = 1)
        if (stateT > 1.4f && (t * 2.2f).toInt() % 2 == 0) gfx.text(c, "TAP TO TRY AGAIN", vw / 2, vh / 2 + 34, gold = true, align = 1)
    }

    private fun drawClear(c: Canvas) {
        val k = stateT - 2.4f
        if (k < 0f) return
        shade(c, (min(1f, k * 2f) * 150f).toInt())
        gfx.title(c, "COURSE CLEAR!", vw / 2, 36 + (if (k < 0.4f) ((0.4f - k) * -120f).roundToInt() else 0), gold = true)
        val lines = arrayOf(
            "TIME" to timeText(runTime),
            "COINS" to coins.toString(),
            "GEMS" to gemsFound.size.toString() + "/3",
            "SCORE" to "%06d".format(score),
        )
        for ((i, l) in lines.withIndex()) {
            if (k < 0.5f + i * 0.35f) break
            val y = 76 + i * 18
            gfx.text(c, l.first, vw / 2 - 70, y)
            gfx.text(c, l.second, vw / 2 + 70, y, gold = true, align = 2)
        }
        if (newBest && k > 2f && (t * 3f).toInt() % 2 == 0) gfx.title(c, "NEW BEST!", vw / 2, 154, gold = true)
        if (stateT > 4f && (t * 2.2f).toInt() % 2 == 0) gfx.text(c, "TAP TO PLAY AGAIN", vw / 2, vh - 30, align = 1)
    }

    private fun drawIris(c: Canvas) {
        if (iris >= 1f) return
        val w = world
        val h = w.hero
        val cx = (h.x - w.camX).coerceIn(0f, vw.toFloat())
        val cy = (h.y - 14f - w.camY).coerceIn(0f, vh.toFloat())
        val far = sqrt(max(cx, vw - cx).let { it * it } + max(cy, vh - cy).let { it * it })
        val r = far * iris * iris
        fill.color = 0xFF000000.toInt()
        if (r < 1f) { c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), fill); return }
        irisPath.reset()
        irisPath.fillType = Path.FillType.EVEN_ODD
        irisPath.addRect(0f, 0f, vw.toFloat(), vh.toFloat(), Path.Direction.CW)
        irisPath.addCircle(cx, cy, r, Path.Direction.CW)
        c.drawPath(irisPath, fill)
    }
}
