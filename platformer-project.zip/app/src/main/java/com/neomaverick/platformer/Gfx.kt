package com.neomaverick.platformer

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect

/** All the pixel art, plus helpers that blit frames 1:1 with no smoothing. */
class Gfx(res: Resources) {
    private fun load(res: Resources, id: Int): Bitmap {
        val o = BitmapFactory.Options()
        o.inScaled = false
        o.inPreferredConfig = Bitmap.Config.ARGB_8888
        return BitmapFactory.decodeResource(res, id, o)
    }

    val hero = load(res, R.drawable.hero)
    val enemies = load(res, R.drawable.enemies)
    val sprites = load(res, R.drawable.sprites)
    val tiles = load(res, R.drawable.tiles)
    val objects = load(res, R.drawable.objects)
    val buttons = load(res, R.drawable.buttons)
    val font = load(res, R.drawable.font)
    val titleFont = load(res, R.drawable.title_font)
    val sky = load(res, R.drawable.bg_sky)
    val sun = load(res, R.drawable.bg_sun)
    val cloudsFar = load(res, R.drawable.bg_clouds_far)
    val mountains = load(res, R.drawable.bg_mountains)
    val cloudsNear = load(res, R.drawable.bg_clouds_near)
    val hillsFar = load(res, R.drawable.bg_hills_far)
    val hillsNear = load(res, R.drawable.bg_hills_near)

    /** Crisp 1:1 drawing. */
    val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false; isDither = false }
    private val src = Rect()
    private val dst = Rect()

    fun cell(c: Canvas, bmp: Bitmap, cw: Int, ch: Int, cols: Int, index: Int, x: Int, y: Int, p: Paint = paint) {
        val sx = (index % cols) * cw
        val sy = (index / cols) * ch
        src.set(sx, sy, sx + cw, sy + ch)
        dst.set(x, y, x + cw, y + ch)
        c.drawBitmap(bmp, src, dst, p)
    }

    /** Hero frame (32x32); left-facing frames are the second row. */
    fun hero(c: Canvas, frame: Int, left: Boolean, x: Int, y: Int, p: Paint = paint) =
        cell(c, hero, 32, 32, G.HERO_FRAMES, frame + if (left) G.HERO_FRAMES else 0, x, y, p)

    /** Enemy frame (24x20): row = type * 2 (+1 when facing left). */
    fun enemy(c: Canvas, type: Int, frame: Int, left: Boolean, x: Int, y: Int, p: Paint = paint) =
        cell(c, enemies, 24, 20, 5, (type * 2 + if (left) 1 else 0) * 5 + frame, x, y, p)

    fun spr(c: Canvas, index: Int, x: Int, y: Int, p: Paint = paint) = cell(c, sprites, 16, 16, 16, index, x, y, p)

    fun tile(c: Canvas, index: Int, x: Int, y: Int, p: Paint = paint) = cell(c, tiles, 16, 16, 16, index, x, y, p)

    fun obj(c: Canvas, id: Int, x: Int, y: Int, p: Paint = paint) {
        val o = id * 4
        src.set(G.OBJ[o], G.OBJ[o + 1], G.OBJ[o] + G.OBJ[o + 2], G.OBJ[o + 1] + G.OBJ[o + 3])
        dst.set(x, y, x + G.OBJ[o + 2], y + G.OBJ[o + 3])
        c.drawBitmap(objects, src, dst, p)
    }

    fun objW(id: Int) = G.OBJ[id * 4 + 2]
    fun objH(id: Int) = G.OBJ[id * 4 + 3]

    fun button(c: Canvas, kind: Int, pressed: Boolean, x: Int, y: Int, p: Paint = paint) =
        cell(c, buttons, 32, 32, 5, kind + if (pressed) 5 else 0, x, y, p)

    /** Stretch a bitmap region (nearest neighbour). */
    fun stretch(c: Canvas, bmp: Bitmap, sx: Int, sy: Int, sw: Int, sh: Int, x: Int, y: Int, w: Int, h: Int, p: Paint = paint) {
        src.set(sx, sy, sx + sw, sy + sh)
        dst.set(x, y, x + w, y + h)
        c.drawBitmap(bmp, src, dst, p)
    }

    // ------------------------------------------------------------------ text
    /** Small font: 6 px per character. [gold] picks the yellow set. */
    fun text(c: Canvas, s: String, x: Int, y: Int, gold: Boolean = false, align: Int = 0, p: Paint = paint) {
        val str = s.uppercase()
        var cx = x - when (align) { 1 -> textW(str) / 2; 2 -> textW(str); else -> 0 }
        for (ch in str) {
            val i = G.FONT_CHARS.indexOf(ch)
            if (i >= 0 && ch != ' ') {
                val row = i / 32 + if (gold) G.FONT_ROWS else 0
                val col = i % 32
                src.set(col * 7, row * 9, col * 7 + 7, row * 9 + 9)
                dst.set(cx - 1, y - 1, cx + 6, y + 8)
                c.drawBitmap(font, src, dst, p)
            }
            cx += 6
        }
    }

    fun textW(s: String) = s.length * 6 - 1

    /** Big title font: 12 px per character. */
    fun title(c: Canvas, s: String, x: Int, y: Int, gold: Boolean = false, align: Int = 1, p: Paint = paint) {
        val str = s.uppercase()
        var cx = x - when (align) { 1 -> titleW(str) / 2; 2 -> titleW(str); else -> 0 }
        for (ch in str) {
            val i = G.FONT_CHARS.indexOf(ch)
            if (i >= 0 && ch != ' ') {
                val row = i / 32 + if (gold) G.TFONT_ROWS else 0
                val col = i % 32
                src.set(col * 14, row * 18, col * 14 + 14, row * 18 + 18)
                dst.set(cx - 2, y - 2, cx + 12, y + 16)
                c.drawBitmap(titleFont, src, dst, p)
            }
            cx += 12
        }
    }

    fun titleW(s: String) = s.length * 12 - 2
}
