package com.neomaverick.platformer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LightingColorFilter
import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** One level: its tiles, everything living in it, the camera, and how it all draws. */
class World(val game: Game, startX: Float, startY: Float) {
    companion object {
        const val EMPTY = 0
        const val GROUND = 1
        const val STONE = 2
        const val BRIDGE = 3
        const val BLOCK = 4
        const val USED = 5
        const val CRATE = 6
        const val SPIKES = 7
        const val FAKE = 8

        const val I_NONE = 0
        const val I_COIN = 1
        const val I_MULTI = 2
        const val I_HEART = 3
        const val I_FEATHER = 4
        const val I_SUN = 5
        const val I_SHIELD = 6
        const val I_STAR = 7

        private var shared: Bitmap? = null
    }

    val gfx get() = game.gfx
    val audio get() = game.audio
    val cols = LevelData.MAP[0].length
    val rows = LevelData.MAP.size
    val pxW = cols * TS
    val pxH = rows * TS

    val tile = IntArray(cols * rows)
    val content = IntArray(cols * rows)
    val bumpT = FloatArray(cols * rows)
    private val multiLeft = HashMap<Int, Int>()
    private val multiStart = HashMap<Int, Float>()
    private val blockCells = ArrayList<Int>()
    private val fakeCells = ArrayList<Int>()
    private val fakeIndex = HashMap<Int, Int>()

    val hero = Hero()
    val enemies = ArrayList<Enemy>()
    val items = ArrayList<Item>()
    val orbs = ArrayList<Orb>()
    val platforms = ArrayList<Platform>()
    val springs = ArrayList<Spring>()
    val flags = ArrayList<Flag>()
    var portal: Portal? = null
    val decor = ArrayList<Decor>()
    val butterflies = ArrayList<Butterfly>()
    val fx = ArrayList<Fx>()
    val chips = ArrayList<Chip>()
    val pops = ArrayList<Pop>()

    var time = 0f
    var camXf = 0f
    var camYf = 0f
    var camX = 0
    var camY = 0
    private var lookX = 0f
    var fakeAlpha = 1f
    var stompCombo = 0
    var clearing = false
    var clearT = 0f
    private var starFxT = 0f

    /** Tiles and scenery that never change, drawn once and shared by every life. */
    val layer: Bitmap = shared ?: Bitmap.createBitmap(pxW, pxH, Bitmap.Config.ARGB_8888)

    private val paint = gfx.paint
    private val alphaPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val fillPaint = Paint().apply { isAntiAlias = false }
    private val src = Rect()
    private val dst = Rect()
    /** Darkened dirt: the inside wall of the secret cave, seen when its fake front fades. */
    private val cavePaint = Paint().apply { isFilterBitmap = false; colorFilter = LightingColorFilter(0x585450, 0x0A0604) }
    private val starPaints = intArrayOf(0x7A3000, 0x00704A, 0x40207A, 0x6A6000, 0x7A1050).map { add ->
        Paint().apply { isFilterBitmap = false; colorFilter = LightingColorFilter(0xFFFFFF, add) }
    }

    init {
        load()
        hero.x = startX
        hero.y = startY
        hero.onGround = true
        snapCamera()
        if (shared == null) { bakeLayer(); shared = layer }
    }

    // =========================================================================== level loading
    private fun load() {
        for (ty in 0 until rows) {
            val row = LevelData.MAP[ty]
            for (tx in 0 until cols) {
                val i = ty * cols + tx
                val ch = row[tx]
                val px = tx * TS + 8f
                val py = (ty + 1) * TS.toFloat()
                when (ch) {
                    '#' -> tile[i] = GROUND
                    'S' -> tile[i] = STONE
                    '=' -> tile[i] = BRIDGE
                    '%' -> tile[i] = FAKE
                    '^' -> tile[i] = SPIKES
                    'X' -> { tile[i] = CRATE; blockCells.add(i) }
                    '?', '$', '!', 'F', 'U', 'D', '*' -> {
                        tile[i] = BLOCK
                        blockCells.add(i)
                        content[i] = when (ch) {
                            '?' -> I_COIN
                            '$' -> I_MULTI
                            '!' -> I_HEART
                            'F' -> I_FEATHER
                            'U' -> I_SUN
                            'D' -> I_SHIELD
                            else -> I_STAR
                        }
                        if (ch == '$') multiLeft[i] = 8
                    }
                    'o' -> items.add(Item(Item.COIN, px, py))
                    'G' -> if (i !in game.gemsFound) items.add(Item(Item.GEM, px, py).also { it.cell = i })
                    'c' -> { tile[i] = FAKE; items.add(Item(Item.COIN, px, py).also { it.hidden = true }) }
                    'j' -> { tile[i] = FAKE; if (i !in game.gemsFound) items.add(Item(Item.GEM, px, py).also { it.hidden = true; it.cell = i }) }
                    'C' -> flags.add(Flag(tx, ty).also { it.active = game.checkpointCell == i })
                    'E' -> portal = Portal(tx, ty)
                    'Z' -> springs.add(Spring(tx, ty))
                    'M', 'V' -> platforms.add(Platform(tx * TS.toFloat(), ty * TS.toFloat(), ch == 'V', platforms.size * 1.7f))
                    'b' -> enemies.add(Enemy(G.E_BEETLE, px, py))
                    'w' -> enemies.add(Enemy(G.E_HORNET, px, py - 6f))
                    'g' -> enemies.add(Enemy(G.E_HEDGEHOG, px, py))
                    'r' -> enemies.add(Enemy(G.E_FROG, px, py))
                    't' -> decor.add(Decor(Decor.TREE, tx, ty, 0))
                    'u' -> decor.add(Decor(Decor.BUSH, tx, ty, 0))
                    'n' -> decor.add(Decor(Decor.SIGN, tx, ty, 0))
                    'N' -> decor.add(Decor(Decor.SIGN, tx, ty, 1))
                    'l' -> decor.add(Decor(Decor.FENCE, tx, ty, 0))
                    'k' -> decor.add(Decor(Decor.ROCK, tx, ty, 0))
                    'm' -> decor.add(Decor(Decor.MUSHROOM, tx, ty, tx % 2))
                    'y' -> {
                        decor.add(Decor(Decor.FLOWER, tx, ty, tx % 5))
                        if (tx % 3 == 0) butterflies.add(Butterfly(px, py - 22f))
                    }
                }
            }
        }
        // grass tufts on some open grass tops
        for (ty in 1 until rows) for (tx in 0 until cols) {
            val i = ty * cols + tx
            if (tile[i] == GROUND && LevelData.MAP[ty - 1][tx] == '.' && tile[i - cols] == EMPTY && (tx * 37 + ty * 11) % 5 == 0) {
                decor.add(Decor(Decor.TUFT, tx, ty - 1, tx % 2))
            }
        }
        for (i in tile.indices) if (tile[i] == FAKE) {
            fakeCells.add(i)
            fakeIndex[i] = groundIndex(i % cols, i / cols)
        }
    }

    private fun groundLike(tx: Int, ty: Int): Boolean {
        if (tx < 0 || tx >= cols) return true
        if (ty >= rows) return true
        if (ty < 0) return false
        val t = tile[ty * cols + tx]
        return t == GROUND || t == FAKE
    }

    private fun groundIndex(tx: Int, ty: Int): Int {
        val mask = (if (groundLike(tx, ty - 1)) 1 else 0) or (if (groundLike(tx, ty + 1)) 2 else 0) or
            (if (groundLike(tx - 1, ty)) 4 else 0) or (if (groundLike(tx + 1, ty)) 8 else 0)
        return G.T_GROUND + mask * 3 + (tx * 7 + ty * 3) % 3
    }

    private fun stoneIndex(tx: Int, ty: Int): Int {
        fun s(x: Int, y: Int) = x in 0 until cols && y in 0 until rows && tile[y * cols + x] == STONE
        val mask = (if (s(tx, ty - 1)) 1 else 0) or (if (s(tx, ty + 1)) 2 else 0) or (if (s(tx - 1, ty)) 4 else 0) or (if (s(tx + 1, ty)) 8 else 0)
        return G.T_STONE + mask
    }

    private fun bakeLayer() {
        val c = Canvas(layer)
        for (d in decor) {
            val x = d.x * TS
            val y = d.y * TS
            when (d.kind) {
                Decor.TREE -> gfx.obj(c, G.O_TREE, x - 16, y - 48)
                Decor.BUSH -> gfx.obj(c, G.O_BUSH, x - 8, y)
                Decor.SIGN -> gfx.spr(c, G.S_SIGN + d.v, x, y)
                Decor.FENCE -> gfx.spr(c, G.S_FENCE, x, y)
                Decor.ROCK -> gfx.spr(c, G.S_ROCK, x, y)
                Decor.MUSHROOM -> gfx.spr(c, G.S_MUSHROOM + d.v, x, y)
            }
        }
        for (ty in 0 until rows) for (tx in 0 until cols) {
            val i = ty * cols + tx
            val x = tx * TS
            val y = ty * TS
            when (tile[i]) {
                GROUND -> gfx.tile(c, groundIndex(tx, ty), x, y)
                STONE -> gfx.tile(c, stoneIndex(tx, ty), x, y)
                BRIDGE -> {
                    val l = tx > 0 && tile[i - 1] == BRIDGE
                    val r = tx < cols - 1 && tile[i + 1] == BRIDGE
                    gfx.tile(c, G.T_BRIDGE + if (!l) 1 else if (!r) 2 else 0, x, y)
                }
                SPIKES -> gfx.tile(c, G.T_SPIKES, x, y)
            }
        }
    }

    // =========================================================================== collisions
    fun solidAt(tx: Int, ty: Int): Boolean {
        if (tx < 0 || tx >= cols) return true
        if (ty < 0 || ty >= rows) return false
        return when (tile[ty * cols + tx]) {
            GROUND, STONE, BLOCK, USED, CRATE, SPIKES -> true
            else -> false
        }
    }

    fun oneWayAt(tx: Int, ty: Int): Boolean = tx in 0 until cols && ty in 0 until rows && tile[ty * cols + tx] == BRIDGE

    fun tileAt(tx: Int, ty: Int): Int = if (tx in 0 until cols && ty in 0 until rows) tile[ty * cols + tx] else EMPTY

    fun moveX(b: Body, dx: Float) {
        b.hitWall = 0
        if (dx == 0f) return
        b.x += dx
        val ty0 = floor((b.top + 0.01f) / TS).toInt()
        val ty1 = floor((b.y - 0.01f) / TS).toInt()
        if (dx > 0f) {
            val tx = floor((b.right - 0.001f) / TS).toInt()
            for (ty in ty0..ty1) if (solidAt(tx, ty)) { b.x = tx * TS - b.w / 2f; b.hitWall = 1; return }
        } else {
            val tx = floor((b.left + 0.001f) / TS).toInt()
            for (ty in ty0..ty1) if (solidAt(tx, ty)) { b.x = (tx + 1) * TS + b.w / 2f; b.hitWall = -1; return }
        }
    }

    fun moveY(b: Body, dy: Float, oneWay: Boolean) {
        b.hitCeil = false
        val prevBottom = b.y
        b.y += dy
        val tx0 = floor((b.left + 0.01f) / TS).toInt()
        val tx1 = floor((b.right - 0.01f) / TS).toInt()
        if (dy > 0f) {
            b.onGround = false
            val ty = floor((b.y - 0.001f) / TS).toInt()
            for (tx in tx0..tx1) {
                if (solidAt(tx, ty) || (oneWay && oneWayAt(tx, ty) && prevBottom <= ty * TS + 0.01f)) {
                    b.y = ty * TS.toFloat()
                    b.vy = 0f
                    b.onGround = true
                    return
                }
            }
        } else if (dy < 0f) {
            b.onGround = false
            val ty = floor(b.top / TS).toInt()
            for (tx in tx0..tx1) {
                if (solidAt(tx, ty)) { b.y = (ty + 1) * TS + b.h; b.vy = 0f; b.hitCeil = true; return }
            }
        }
    }

    fun spikesUnder(b: Body): Boolean {
        val ty = floor((b.y + 1f) / TS).toInt()
        val tx0 = floor((b.left + 2f) / TS).toInt()
        val tx1 = floor((b.right - 2f) / TS).toInt()
        for (tx in tx0..tx1) if (tileAt(tx, ty) == SPIKES) return true
        return false
    }

    /** Which way to bounce off spikes: toward the nearest safe ground, so a hit never throws you further in. */
    fun spikeEscapeDir(b: Body): Int {
        val ty = floor((b.y + 1f) / TS).toInt()
        val tx = floor(b.x / TS).toInt()
        fun safe(x: Int) = tileAt(x, ty) != SPIKES && solidAt(x, ty) && !solidAt(x, ty - 1)
        if (tileAt(tx, ty) != SPIKES) return if (tileAt(tx + 1, ty) == SPIKES) -1 else 1
        var dr = Float.MAX_VALUE
        var dl = Float.MAX_VALUE
        for (k in 1..8) if (safe(tx + k)) { dr = (tx + k) * TS - b.x; break }
        for (k in 1..8) if (safe(tx - k)) { dl = b.x - (tx - k + 1) * TS; break }
        return if (dr <= dl) 1 else -1
    }

    private fun groundBelow(x: Float, y: Float): Boolean {
        val tx = floor(x / TS).toInt()
        val ty = floor((y + 1f) / TS).toInt()
        return solidAt(tx, ty) || oneWayAt(tx, ty)
    }

    /** Ground an enemy is happy to walk or hop onto: not a gap, and not spikes. */
    private fun safeBelow(x: Float, y: Float): Boolean =
        groundBelow(x, y) && tileAt(floor(x / TS).toInt(), floor((y + 1f) / TS).toInt()) != SPIKES

    // =========================================================================== events
    fun bump(tx: Int, ty: Int) {
        if (tx !in 0 until cols || ty !in 0 until rows) return
        val i = ty * cols + tx
        val bx = tx * TS + 8f
        val by = ty * TS.toFloat()
        when (tile[i]) {
            BLOCK -> {
                bumpT[i] = 0.16f
                knockTop(tx, ty)
                when (content[i]) {
                    I_COIN -> { coinPop(bx, by); tile[i] = USED }
                    I_MULTI -> {
                        coinPop(bx, by)
                        val left = (multiLeft[i] ?: 8) - 1
                        multiLeft[i] = left
                        if (multiStart[i] == null) multiStart[i] = time
                        if (left <= 0 || time - (multiStart[i] ?: time) > 5f) tile[i] = USED
                    }
                    else -> {
                        val kind = when (content[i]) {
                            I_HEART -> Item.HEART
                            I_FEATHER -> Item.FEATHER
                            I_SUN -> Item.SUN
                            I_SHIELD -> Item.SHIELD
                            else -> Item.STAR
                        }
                        val it = Item(kind, bx, by + TS)
                        it.emerge = 0.5f
                        it.blockTop = by
                        it.baseY = by
                        items.add(it)
                        tile[i] = USED
                        audio.play(R.raw.sfx_appear)
                    }
                }
                game.addScore(10)
            }
            CRATE -> {
                tile[i] = EMPTY
                bumpT[i] = 0f
                knockTop(tx, ty)
                for (k in 0 until 10) {
                    val col = if (k % 3 == 0) 0xFF8A5A30.toInt() else if (k % 3 == 1) 0xFFC88B55.toInt() else 0xFFF1C27D.toInt()
                    chips.add(Chip(bx + Rnd.f(-6f, 6f), by + Rnd.f(2f, 14f), Rnd.f(-110f, 110f), Rnd.f(-320f, -140f), col, 2 + Rnd.i(2)))
                }
                fx.add(Fx(bx, by + 8f, G.S_POOF, 6, 22f))
                audio.play(R.raw.sfx_break)
                game.addScore(50)
            }
            else -> {
                bumpT[i] = 0f
                audio.play(R.raw.sfx_bump, 0.6f)
            }
        }
    }

    /** Anything standing on a bumped block gets knocked off. */
    private fun knockTop(tx: Int, ty: Int) {
        val l = tx * TS - 2f
        val r = (tx + 1) * TS + 2f
        val top = ty * TS.toFloat()
        for (e in enemies) if (e.alive && e.right > l && e.left < r && abs(e.y - top) < 3f) { knockOut(e, if (e.x < tx * TS + 8f) -1 else 1); game.addScore(100, e.x, e.top) }
        for (it in items) if (!it.taken && it.emerge <= 0f && it.kind == Item.COIN && it.right > l && it.left < r && abs(it.y - top) < 3f) collect(it)
    }

    private fun coinPop(x: Float, blockTop: Float) {
        game.addCoin()
        audio.play(R.raw.sfx_coin, 0.8f)
        fx.add(Fx(x, blockTop - 4f, G.S_COIN, 6, 26f, vy = -300f, grav = 1000f, loop = true, life = 0.42f))
        fx.add(Fx(x, blockTop - 38f, G.S_SPARK, 4, 16f).also { it.delay = 0.4f })
    }

    fun dust(x: Float, y: Float, small: Boolean) {
        if (small) fx.add(Fx(x, y - 5f, G.S_DUST + 1, 4, 18f, vx = Rnd.f(-10f, 10f), vy = -8f))
        else {
            fx.add(Fx(x - 5f, y - 6f, G.S_DUST, 5, 16f, vx = -26f, vy = -6f))
            fx.add(Fx(x + 5f, y - 6f, G.S_DUST, 5, 16f, vx = 26f, vy = -6f))
        }
    }

    fun featherBurst(x: Float, y: Float) {
        for (k in 0 until 3) fx.add(Fx(x + Rnd.f(-6f, 6f), y + Rnd.f(-2f, 6f), G.S_SPARK, 4, 12f, vx = Rnd.f(-30f, 30f), vy = Rnd.f(10f, 40f)))
        fx.add(Fx(x, y + 6f, G.S_DUST, 5, 18f, vy = 20f))
    }

    fun hurtHero(fromX: Float, spikes: Boolean = false) {
        val h = hero
        if (h.dead || h.invuln > 0f || h.starT > 0f || clearing) return
        if (h.shield) {
            h.shield = false
            h.invuln = 1.1f
            fx.add(Fx(h.x, h.y - 13f, G.S_POOF, 6, 20f))
            audio.play(R.raw.sfx_pop)
        } else {
            h.hearts--
            if (h.hearts <= 0) { killHero(false); return }
            h.invuln = Hero.INVULN
            audio.play(R.raw.sfx_hurt)
        }
        h.knockT = 0.28f
        val d = if (h.x < fromX) -1f else 1f
        h.vx = d * 130f
        h.vy = if (spikes) -260f else -210f
        h.onGround = false
        h.platform = null
        h.jumping = false
        game.shake(3f)
    }

    fun killHero(pit: Boolean) {
        val h = hero
        if (h.dead) return
        h.dead = true
        h.pitDeath = pit
        h.vx = 0f
        h.vy = if (pit) 0f else -330f
        h.hearts = 0
        h.starT = 0f
        game.onHeroDied()
    }

    fun knockOut(e: Enemy, dir: Int) {
        if (!e.alive) return
        e.state = Enemy.FALLING
        e.flipY = true
        e.vy = -230f
        e.vx = dir * 60f
        e.active = true
        audio.play(R.raw.sfx_kick)
        fx.add(Fx(e.x, e.cy, G.S_STOMP, 2, 14f))
    }

    private fun collect(it: Item) {
        if (it.taken) return
        it.taken = true
        val h = hero
        when (it.kind) {
            Item.COIN -> {
                game.addCoin()
                audio.play(R.raw.sfx_coin, 0.8f)
                fx.add(Fx(it.x, it.y - 8f, G.S_SPARK, 4, 18f))
            }
            Item.GEM -> {
                if (it.cell >= 0) game.gemsFound.add(it.cell)
                audio.play(R.raw.sfx_gem)
                for (k in 0 until 6) fx.add(Fx(it.x, it.y - 8f, G.S_SPARK, 4, 10f, vx = Rnd.f(-70f, 70f), vy = Rnd.f(-90f, 10f)))
                game.addScore(1000, it.x, it.y - 18f)
            }
            Item.HEART -> {
                if (h.hearts < 3) { h.hearts++; pop("HEART!", it.x, it.y - 18f) } else game.addScore(1000, it.x, it.y - 18f)
                audio.play(R.raw.sfx_heart)
            }
            Item.FEATHER -> {
                h.hasFeather = true
                if (!h.onGround) h.airJumps = 1
                audio.play(R.raw.sfx_powerup)
                pop("DOUBLE JUMP!", it.x, it.y - 18f)
                game.addScore(1000)
            }
            Item.SUN -> {
                h.hasSun = true
                game.input.fireEnabled = true
                audio.play(R.raw.sfx_powerup)
                pop("SUN POWER!", it.x, it.y - 18f)
                game.addScore(1000)
            }
            Item.SHIELD -> {
                h.shield = true
                audio.play(R.raw.sfx_powerup)
                pop("SHIELD!", it.x, it.y - 18f)
                game.addScore(1000)
            }
            Item.STAR -> {
                h.starT = 10f
                audio.play(R.raw.sfx_powerup)
                audio.music(R.raw.music_star)
                pop("STAR POWER!", it.x, it.y - 18f)
                game.addScore(1000)
            }
        }
        if (it.kind != Item.COIN) for (k in 0 until 4) fx.add(Fx(it.x + Rnd.f(-8f, 8f), it.y - Rnd.f(2f, 16f), G.S_SPARK, 4, 12f))
    }

    fun starEnded() {
        if (!hero.dead && !clearing) audio.music(R.raw.music_hills)
    }

    fun pop(text: String, x: Float, y: Float, gold: Boolean = true) {
        pops.add(Pop(text, x, y, gold))
    }

    private fun throwOrb() {
        val h = hero
        if (orbs.count { !it.dead } >= 2) return
        orbs.add(Orb(h.x + h.facing * 8f, h.y - 12f, h.facing))
        h.throwT = 0.18f
        audio.play(R.raw.sfx_fire, 0.8f)
    }

    // =========================================================================== update
    fun update(dt: Float) {
        time += dt
        val inp = game.input
        for (p in platforms) p.update(dt)
        for (s in springs) s.squash = max(0f, s.squash - dt)
        for (f in flags) f.t += dt
        portal?.let { it.t += dt }
        for (i in blockCells) if (bumpT[i] > 0f) bumpT[i] = max(0f, bumpT[i] - dt)
        for (b in butterflies) {
            b.t += dt
            b.x = b.hx + sin(b.t * b.sx) * 26f + sin(b.t * 2.3f) * 6f
            b.y = b.hy + sin(b.t * b.sy) * 9f
        }

        val h = hero
        if (clearing) updateClear(dt)
        else {
            if (!h.dead && h.hasSun && inp.firePressed) throwOrb()
            h.update(this, inp, dt)
            if (!h.dead) {
                if (h.onGround) stompCombo = 0
                if (h.top > pxH + 8f) killHero(true)
                if (h.starT > 0f) {
                    starFxT -= dt
                    if (starFxT <= 0f) { starFxT = 0.06f; fx.add(Fx(h.x + Rnd.f(-9f, 9f), h.y - Rnd.f(2f, 26f), G.S_SPARK, 4, 14f)) }
                }
                // checkpoints
                for ((k, f) in flags.withIndex()) {
                    if (!f.active && abs(h.x - f.x) < 12f && h.y > f.y - 34f && h.top < f.y) {
                        for (o in flags) o.active = false
                        f.active = true
                        game.checkpointCell = f.ty * cols + f.tx
                        audio.play(R.raw.sfx_checkpoint)
                        for (j in 0 until 5) fx.add(Fx(f.x + Rnd.f(-6f, 10f), f.y - Rnd.f(10f, 30f), G.S_SPARK, 4, 12f))
                        pop("CHECKPOINT", f.x, f.y - 40f, gold = false)
                        if (k >= 0) game.addScore(100)
                    }
                }
                // goal
                portal?.let { p -> if (abs(h.x - p.x) < 10f && h.y > p.y - 44f && h.top < p.y) startClear() }
            }
        }

        // secret area: fake ground goes see-through while you're inside it
        var inside = false
        if (!h.dead) {
            val tx0 = floor(h.left / TS).toInt(); val tx1 = floor(h.right / TS).toInt()
            val ty0 = floor(h.top / TS).toInt(); val ty1 = floor((h.y - 1f) / TS).toInt()
            loop@ for (ty in ty0..ty1) for (tx in tx0..tx1) if (tileAt(tx, ty) == FAKE) { inside = true; break@loop }
        }
        fakeAlpha = approach(fakeAlpha, if (inside) 0.28f else 1f, dt * 3.2f)

        if (!h.dead) updateEnemies(dt)
        updateOrbs(dt)
        updateItems(dt)
        updateFx(dt)
        if (!h.dead) updateCamera(dt)
        val f = h.frame()
        val kx = if (h.facing > 0) G.KNOT[f * 2] else 31 - G.KNOT[f * 2]
        h.ribbon.update(h.x.roundToInt() - 16 + kx + 0.5f, h.y.roundToInt() - 32 + G.KNOT[f * 2 + 1] + 0.5f, h.facing, h.vx, time)
    }

    private fun updateEnemies(dt: Float) {
        val h = hero
        for (e in enemies) {
            if (e.state == Enemy.GONE) continue
            if (!e.active) {
                if (e.x > camX - 40f && e.x < camX + game.vw + 40f) e.active = true else continue
            }
            e.t += dt
            when (e.state) {
                Enemy.SQUASHED -> {
                    e.stateT += dt
                    if (e.stateT > 0.5f) { e.state = Enemy.GONE; fx.add(Fx(e.x, e.y - 6f, G.S_POOF, 6, 20f)) }
                    continue
                }
                Enemy.FALLING -> {
                    e.vy = min(e.vy + 900f * dt, 420f)
                    e.x += e.vx * dt; e.y += e.vy * dt
                    if (e.top > pxH + 32f) e.state = Enemy.GONE
                    continue
                }
            }
            when (e.type) {
                G.E_BEETLE, G.E_HEDGEHOG -> walker(e, if (e.type == G.E_BEETLE) 30f else 20f, dt)
                G.E_HORNET -> {
                    val px = e.x
                    e.x = e.homeX + sin(e.t * 1.1f) * 30f
                    e.y = e.homeY + sin(e.t * 2.2f) * 7f
                    if (abs(e.x - px) > 0.01f) e.dir = if (e.x > px) 1 else -1
                }
                G.E_FROG -> frog(e, dt)
            }
            if (e.top > pxH + 16f) { e.state = Enemy.GONE; continue }
            // hero contact
            if (h.dead || clearing || !h.overlaps(e)) continue
            if (h.starT > 0f) {
                knockOut(e, if (e.x < h.x) -1 else 1)
                game.addScore(200, e.x, e.top)
                continue
            }
            val stomp = h.vy > 30f && h.prevBottom <= e.top + 7f
            if (stomp) {
                if (e.stompable) {
                    stompCombo++
                    val pts = when (stompCombo) { 1 -> 100; 2 -> 200; 3 -> 400; 4 -> 800; else -> 0 }
                    if (pts > 0) game.addScore(pts, e.x, e.top - 4f) else { game.addLife(); pop("1UP", e.x, e.top - 4f) }
                    audio.play(R.raw.sfx_stomp, 1f, 1f + min(0.5f, stompCombo * 0.08f))
                    fx.add(Fx(h.x, h.y, G.S_STOMP, 2, 12f))
                    when (e.type) {
                        G.E_BEETLE -> { e.state = Enemy.SQUASHED; e.stateT = 0f }
                        else -> { e.state = Enemy.FALLING; e.flipY = true; e.vy = 0f; e.vx = 0f }
                    }
                    h.y = e.top
                    if (e.type == G.E_FROG) { h.vy = -Hero.FROG_V; h.launched = true; h.jumping = false }
                    else { h.vy = -(if (game.input.jumpHeld) Hero.STOMP_HOLD_V else Hero.STOMP_V); h.jumping = false; h.launched = false }
                    h.airJumps = if (h.hasFeather) 1 else 0
                } else {
                    // hedgehog spikes: ouch, and a hop up off its back
                    hurtHero(e.x)
                    if (!h.dead) h.vy = -230f
                }
            } else {
                hurtHero(e.x)
            }
        }
    }

    private fun walker(e: Enemy, speed: Float, dt: Float) {
        e.vx = e.dir * speed
        e.vy = min(e.vy + 900f * dt, 300f)
        moveX(e, e.vx * dt)
        if (e.hitWall != 0) e.dir = -e.hitWall
        moveY(e, e.vy * dt, true)
        if (e.onGround && !safeBelow(e.x + e.dir * (e.w / 2f + 1f), e.y)) e.dir = -e.dir
    }

    private fun frog(e: Enemy, dt: Float) {
        val h = hero
        val was = e.onGround
        e.vy = min(e.vy + 900f * dt, 320f)
        moveX(e, e.vx * dt)
        if (e.hitWall != 0) { e.vx = -e.vx * 0.5f; e.dir = -e.hitWall }
        moveY(e, e.vy * dt, true)
        if (e.onGround) {
            if (!was) e.landT = 0.16f
            e.vx = 0f
            e.landT = max(0f, e.landT - dt)
            e.hopT -= dt
            if (e.hopT <= 0f) {
                val d = if (h.x < e.x) -1 else 1
                if (abs(h.x - e.x) < 190f && safeBelow(e.x + d * 34f, e.y) && safeBelow(e.x + d * 14f, e.y) && safeBelow(e.x + d * 46f, e.y)) {
                    e.dir = d
                    e.vx = d * 68f
                    e.vy = -255f
                    e.onGround = false
                    e.hopT = Rnd.f(1.0f, 1.7f)
                } else e.hopT = 0.4f
            }
        }
    }

    private fun updateOrbs(dt: Float) {
        for (o in orbs) {
            if (o.dead) continue
            o.t += dt
            o.life -= dt
            o.vy = min(o.vy + 900f * dt, 400f)
            moveX(o, o.vx * dt)
            if (o.hitWall != 0) { o.dead = true; fx.add(Fx(o.x, o.cy, G.S_POOF, 6, 24f)); continue }
            moveY(o, o.vy * dt, true)
            if (o.onGround) o.vy = -175f
            if (o.life <= 0f || o.top > pxH || o.x < camX - 24f || o.x > camX + game.vw + 24f) { o.dead = true; continue }
            for (e in enemies) {
                if (e.alive && e.active && o.overlaps(e)) {
                    knockOut(e, o.dir)
                    game.addScore(200, e.x, e.top)
                    o.dead = true
                    fx.add(Fx(o.x, o.cy, G.S_POOF, 6, 24f))
                    break
                }
            }
        }
        orbs.removeAll { it.dead }
    }

    private fun updateItems(dt: Float) {
        val h = hero
        for (it in items) {
            if (it.taken) continue
            it.t += dt
            if (it.emerge > 0f) {
                it.emerge = max(0f, it.emerge - dt)
                it.y = it.blockTop + TS * (it.emerge / 0.5f)
                continue
            }
            when (it.kind) {
                Item.STAR -> {
                    it.vy = min(it.vy + 900f * dt, 360f)
                    moveX(it, it.vx * dt)
                    if (it.hitWall != 0) it.vx = -it.hitWall * 55f
                    moveY(it, it.vy * dt, true)
                    if (it.onGround) it.vy = -235f
                    if (it.top > pxH) it.taken = true
                }
                Item.FEATHER, Item.SHIELD -> it.y = it.baseY - 5f + sin(it.t * 3f) * 3f
            }
            if (!h.dead && !clearing && h.overlaps(it.left - 1f, it.top - 1f, it.right + 1f, it.y + 1f)) collect(it)
        }
        items.removeAll { it.taken }
    }

    private fun updateFx(dt: Float) {
        for (f in fx) {
            if (f.delay > 0f) { f.delay -= dt; continue }
            f.t += dt
            f.vy += f.grav * dt
            f.x += f.vx * dt
            f.y += f.vy * dt
        }
        fx.removeAll { it.delay <= 0f && it.t >= it.life }
        for (c in chips) {
            c.t += dt
            c.vy += 900f * dt
            c.x += c.vx * dt
            c.y += c.vy * dt
            c.rot += 400f * dt
        }
        chips.removeAll { it.t > 1.6f || it.y > camY + game.vh + 20f }
        for (p in pops) { p.t += dt; p.y -= 28f * dt * (if (p.t < 0.4f) 1.4f else 0.5f) }
        pops.removeAll { it.t > 1.1f }
    }

    fun snapCamera() {
        camXf = (hero.x - game.vw * 0.4f).coerceIn(0f, max(0f, (pxW - game.vw).toFloat()))
        camYf = (hero.y - game.vh * 0.64f).coerceIn(0f, max(0f, (pxH - game.vh).toFloat()))
        camX = camXf.toInt(); camY = camYf.toInt()
    }

    private fun updateCamera(dt: Float) {
        val h = hero
        val vw = game.vw
        val vh = game.vh
        if (abs(h.vx) > 20f) lookX = approach(lookX, h.facing * 34f, 90f * dt)
        val tx = h.x + lookX - vw * 0.5f
        camXf += (tx - camXf) * min(1f, 7f * dt)
        camXf = camXf.coerceIn(0f, max(0f, (pxW - vw).toFloat()))
        val ty = h.y - vh * 0.64f
        val sy = h.y - camYf
        if (h.onGround || sy > vh * 0.84f || sy < vh * 0.3f || h.platform != null) {
            camYf += (ty - camYf) * min(1f, (if (sy > vh * 0.84f) 9f else 3.5f) * dt)
        }
        camYf = camYf.coerceIn(0f, max(0f, (pxH - vh).toFloat()))
        camX = camXf.toInt()
        camY = camYf.toInt()
    }

    // =========================================================================== clear
    private fun startClear() {
        if (clearing) return
        clearing = true
        clearT = 0f
        hero.frozen = true
        hero.starT = 0f
        game.onClear()
    }

    private fun updateClear(dt: Float) {
        clearT += dt
        val h = hero
        val p = portal ?: return
        // walk into the middle of the portal, then celebrate
        h.vy = min(h.vy + 1150f * dt, 330f)
        val d = p.x - h.x
        h.vx = if (abs(d) > 1.5f) (if (d > 0) 60f else -60f) else 0f
        if (abs(d) > 1.5f) h.facing = if (d > 0) 1 else -1 else h.facing = 1
        moveX(h, h.vx * dt)
        moveY(h, h.vy * dt, true)
        h.t += dt
        if (h.onGround && abs(h.vx) > 1f) h.runPhase += abs(h.vx) * dt / 6.2f
        if (clearT > 0.5f && Rnd.chance(0.3f)) fx.add(Fx(p.x + Rnd.f(-12f, 12f), p.y - Rnd.f(6f, 40f), G.S_SPARK, 4, 12f, vy = -20f))
        updateCamera(dt)
    }

    // =========================================================================== drawing
    fun render(c: Canvas) {
        val vw = game.vw
        val vh = game.vh
        drawBackground(c, vw, vh)
        src.set(camX, camY, camX + vw, camY + vh)
        dst.set(0, 0, vw, vh)
        c.drawBitmap(layer, src, dst, paint)
        val x0 = camX - 64
        val x1 = camX + vw + 64

        // the back wall of the secret cave (hidden behind its fake front until you walk in)
        if (fakeAlpha < 0.99f) {
            for (i in fakeCells) {
                val tx = i % cols
                val x = tx * TS
                if (x < x0 || x > x1) continue
                gfx.tile(c, G.T_GROUND + 15 * 3 + (tx * 7 + (i / cols) * 3) % 3, x - camX, (i / cols) * TS - camY, cavePaint)
            }
        }

        // animated scenery
        for (d in decor) {
            val x = d.x * TS
            if (x < x0 || x > x1) continue
            when (d.kind) {
                Decor.FLOWER -> gfx.spr(c, G.S_FLOWER + d.v * 2 + (((time + d.phase * 2f) * 1.6f).toInt() % 2), x - camX, d.y * TS - camY)
                Decor.TUFT -> gfx.spr(c, G.S_TUFT + (((time + d.phase * 3f) * 1.2f).toInt() % 2), x - camX, d.y * TS - camY + 1)
            }
        }
        for (b in butterflies) {
            if (b.x < x0 || b.x > x1) continue
            gfx.spr(c, G.S_BUTTERFLY + ((b.t * 10f).toInt() % 4), b.x.roundToInt() - 8 - camX, b.y.roundToInt() - 8 - camY)
        }

        // blocks
        for (i in blockCells) {
            val t = tile[i]
            if (t == EMPTY) continue
            val tx = i % cols
            val ty = i / cols
            val x = tx * TS
            if (x < x0 || x > x1) continue
            val off = if (bumpT[i] > 0f) -(sin(bumpT[i] / 0.16f * Math.PI.toFloat()) * 6f).roundToInt() else 0
            val idx = when (t) {
                BLOCK -> {
                    val ph = ((time * 7f).toInt() + tx * 3) % 14
                    G.T_PRIZE + if (ph < 4) ph else 0
                }
                USED -> G.T_USED
                CRATE -> G.T_CRATE
                else -> continue
            }
            gfx.tile(c, idx, x - camX, ty * TS - camY + off)
        }
        for (s in springs) gfx.tile(c, G.T_SPRING + if (s.squash > 0f) 1 else 0, s.tx * TS - camX, s.ty * TS - camY)
        for (p in platforms) {
            val px = p.x.roundToInt() - camX
            val py = p.y.roundToInt() - camY
            gfx.tile(c, G.T_RAFT, px, py)
            gfx.tile(c, G.T_RAFT + 1, px + 16, py)
            gfx.tile(c, G.T_RAFT + 2, px + 32, py)
        }
        for (f in flags) {
            val id = if (f.active) G.O_FLAG0 + ((f.t * 8f).toInt() % 4) else G.O_FLAG_OFF
            gfx.obj(c, id, f.tx * TS - camX, f.ty * TS - 16 - camY)
        }
        portal?.let { p -> gfx.obj(c, G.O_PORTAL0 + ((p.t * (if (clearing) 18f else 10f)).toInt() % 6), p.tx * TS - 8 - camX, p.ty * TS - 32 - camY) }

        // items
        for (it in items) {
            val ix = it.x.roundToInt() - 8 - camX
            val iy = it.y.roundToInt() - 16 - camY
            if (ix < -20 || ix > vw + 20) continue
            val id = when (it.kind) {
                Item.COIN -> G.S_COIN + ((it.t * 10f).toInt() % 6)
                Item.GEM -> G.S_GEM + (if (((it.t * 5f).toInt() % 10) < 4) (it.t * 5f).toInt() % 10 else 0)
                Item.HEART -> G.S_HEART
                Item.FEATHER -> G.S_FEATHER
                Item.SUN -> G.S_SUNFLOWER + ((it.t * 3f).toInt() % 2)
                Item.SHIELD -> G.S_SHIELD
                else -> G.S_STAR + ((it.t * 10f).toInt() % 4)
            }
            if (it.emerge > 0f) {
                c.save()
                c.clipRect(0f, -1000f, vw.toFloat(), it.blockTop - camY)
                gfx.spr(c, id, ix, iy)
                c.restore()
            } else gfx.spr(c, id, ix, iy)
        }

        // enemies
        for (e in enemies) {
            if (e.state == Enemy.GONE || !e.active && (e.x < x0 || e.x > x1)) continue
            val frame = when (e.type) {
                G.E_BEETLE -> if (e.state == Enemy.SQUASHED) 4 else ((e.t * 8f).toInt() % 4)
                G.E_HORNET -> (e.t * 16f).toInt() % 2
                G.E_HEDGEHOG -> (e.t * 6f).toInt() % 4
                else -> if (!e.onGround && e.state == Enemy.ALIVE) 2 else if (e.landT > 0f) 3 else ((e.t * 1.5f).toInt() % 2)
            }
            val ex = e.x.roundToInt() - 12 - camX
            val ey = e.y.roundToInt() - 20 - camY
            if (e.flipY) {
                c.save()
                c.scale(1f, -1f, 0f, ey + 10f)
                gfx.enemy(c, e.type, frame, e.dir < 0, ex, ey)
                c.restore()
            } else gfx.enemy(c, e.type, frame, e.dir < 0, ex, ey)
        }

        // sun orbs
        for (o in orbs) gfx.spr(c, G.S_ORB + ((o.t * 16f).toInt() % 4), o.x.roundToInt() - 8 - camX, o.y.roundToInt() - 12 - camY)

        drawHero(c)

        // effects
        for (f in fx) {
            if (f.delay > 0f) continue
            gfx.spr(c, f.base + f.frame, f.x.roundToInt() - 8 - camX, f.y.roundToInt() - 8 - camY)
        }
        for (ch in chips) {
            fillPaint.color = ch.color
            val x = ch.x.roundToInt() - camX
            val y = ch.y.roundToInt() - camY
            c.drawRect(x.toFloat(), y.toFloat(), (x + ch.size).toFloat(), (y + ch.size).toFloat(), fillPaint)
        }

        // secret area cover
        if (fakeAlpha > 0.01f) {
            alphaPaint.alpha = (fakeAlpha * 255f).toInt().coerceIn(0, 255)
            for (i in fakeCells) {
                val x = (i % cols) * TS
                if (x < x0 || x > x1) continue
                gfx.tile(c, fakeIndex[i] ?: G.T_GROUND, x - camX, (i / cols) * TS - camY, alphaPaint)
            }
        }

        for (p in pops) {
            if (p.t > 0.9f && ((p.t * 20f).toInt() % 2 == 0)) continue
            gfx.text(c, p.text, p.x.roundToInt() - camX, p.y.roundToInt() - camY, gold = p.gold, align = 1)
        }
    }

    private fun drawHero(c: Canvas) {
        val h = hero
        if (h.invuln > 0f && !h.dead && ((h.invuln * 18f).toInt() % 2 == 0)) return
        if (clearing && clearT > 2.2f) return
        val f = h.frame()
        val hx = h.x.roundToInt() - 16 - camX
        val hy = h.y.roundToInt() - 32 - camY
        // headband tails behind the head
        val r = h.ribbon
        for (k in 1 downTo 0) {
            fillPaint.color = if (k == 0) 0xFFEC3B3E.toInt() else 0xFFA81E2B.toInt()
            for (i in 0 until r.n - 1) {
                val thick = if (i < 2) 2 else 1
                line(c, r.xs[k][i] - camX, r.ys[k][i] - camY, r.xs[k][i + 1] - camX, r.ys[k][i + 1] - camY, thick)
            }
        }
        val p = if (h.starT > 0f && (h.starT > 2f || ((h.starT * 10f).toInt() % 2 == 0))) starPaints[((time * 14f).toInt()) % starPaints.size] else paint
        if (clearing && clearT > 1.6f) {
            // shrink into the portal
            val k = (1f - (clearT - 1.6f) / 0.6f).coerceIn(0.05f, 1f)
            c.save()
            c.scale(k, k, hx + 16f, hy + 24f)
            gfx.hero(c, if (((clearT * 6f).toInt() % 2) == 0) G.H_WIN0 else G.H_WIN1, false, hx, hy, p)
            c.restore()
            return
        }
        val frame = if (clearing && clearT > 0.6f && h.onGround && abs(h.vx) < 1f) {
            if (((clearT * 6f).toInt() % 2) == 0) G.H_WIN0 else G.H_WIN1
        } else f
        gfx.hero(c, frame, h.facing < 0, hx, hy, p)
        if (h.shield) gfx.obj(c, if (((time * 4f).toInt() % 2) == 0) G.O_BUBBLE0 else G.O_BUBBLE1, h.x.roundToInt() - 16 - camX, h.y.roundToInt() - 30 - camY)
    }

    private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, thick: Int) {
        val ax = x0.roundToInt(); val ay = y0.roundToInt()
        val bx = x1.roundToInt(); val by = y1.roundToInt()
        val n = max(abs(bx - ax), abs(by - ay))
        for (s in 0..n) {
            val x = if (n == 0) ax else ax + (bx - ax) * s / n
            val y = if (n == 0) ay else ay + (by - ay) * s / n
            c.drawRect(x.toFloat(), y.toFloat(), (x + thick).toFloat(), (y + thick).toFloat(), fillPaint)
        }
    }

    private fun tileLayer(c: Canvas, bmp: Bitmap, y: Int, scroll: Float, vw: Int) {
        val w = bmp.width
        var x = -((scroll.toInt() % w + w) % w)
        while (x < vw) {
            c.drawBitmap(bmp, x.toFloat(), y.toFloat(), paint)
            x += w
        }
    }

    private fun drawBackground(c: Canvas, vw: Int, vh: Int) {
        src.set(0, 0, gfx.sky.width, gfx.sky.height)
        dst.set(0, 0, vw, vh)
        c.drawBitmap(gfx.sky, src, dst, paint)
        // camera height (0 = as low as it goes): the scenery sinks a little as you climb
        val up = (max(0, pxH - vh) - camY).toFloat()
        val base = vh - 270
        c.drawBitmap(gfx.sun, (vw - 160 - camX * 0.01f).roundToInt().toFloat(), (18 + up * 0.04f).roundToInt().toFloat(), paint)
        tileLayer(c, gfx.cloudsFar, (8 + up * 0.06f).roundToInt(), camX * 0.08f + time * 3f, vw)
        tileLayer(c, gfx.mountains, base + 100 + (up * 0.12f).roundToInt(), camX * 0.16f, vw)
        tileLayer(c, gfx.cloudsNear, (20 + up * 0.1f).roundToInt(), camX * 0.26f + time * 7f, vw)
        tileLayer(c, gfx.hillsFar, base + 150 + (up * 0.22f).roundToInt(), camX * 0.38f, vw)
        tileLayer(c, gfx.hillsNear, base + 190 + (up * 0.34f).roundToInt(), camX * 0.55f, vw)
    }
}
