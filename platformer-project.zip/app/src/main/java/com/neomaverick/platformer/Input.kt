package com.neomaverick.platformer

/**
 * Touch controls in game pixels. Left thumb: a two-way pad (left / right) anywhere in the
 * lower-left area, sliding between them works. Right thumb: JUMP (big, bottom right) and
 * FIRE (to its left, only when the sun power is held). Pause at the top right.
 * Hardware keys / game pads feed the same flags.
 */
class Input {
    var vw = 585
    var vh = 270

    // current state
    var left = false; private set
    var right = false; private set
    var jumpHeld = false; private set
    var fireHeld = false; private set

    // edges, cleared by the game after reading
    var jumpPressed = false
    var firePressed = false
    var pausePressed = false
    var anyTap = false
    /** Where the last new finger went down (game pixels), for menus. */
    var tapX = -1f
    var tapY = -1f

    /** Whether the fire button is shown (sun power). */
    var fireEnabled = false

    private val zoneOf = HashMap<Int, Int>()
    private var keyLeft = false
    private var keyRight = false
    private var keyJump = false
    private var keyFire = false

    companion object {
        const val NONE = 0
        const val LEFT = 1
        const val RIGHT = 2
        const val JUMP = 3
        const val FIRE = 4
        const val PAUSE = 5
        const val OTHER = 6
    }

    // button centres (for drawing too)
    val leftX get() = 30
    val rightX get() = 82
    val padY get() = vh - 32
    val jumpX get() = vw - 34
    val jumpY get() = vh - 34
    val fireX get() = vw - 88
    val fireY get() = vh - 52
    val pauseX get() = vw - 20
    val pauseY get() = 20

    fun zone(x: Float, y: Float): Int {
        if (x > vw - 44 && y < 44) return PAUSE
        // left third (lower part) is the d-pad; anywhere on the right half jumps (or fires, near that button)
        if (x < vw * 0.36f && y > vh * 0.3f) return if (x < (leftX + rightX) / 2f) LEFT else RIGHT
        if (x > vw * 0.5f) {
            if (fireEnabled) {
                val dfx = x - fireX; val dfy = y - fireY
                val djx = x - jumpX; val djy = y - jumpY
                val df = dfx * dfx + dfy * dfy
                if (df < 34f * 34f && df < djx * djx + djy * djy) return FIRE
            }
            return JUMP
        }
        return OTHER
    }

    fun down(id: Int, x: Float, y: Float) {
        val z = zone(x, y)
        zoneOf[id] = z
        anyTap = true
        tapX = x
        tapY = y
        when (z) {
            JUMP -> jumpPressed = true
            FIRE -> firePressed = true
            PAUSE -> pausePressed = true
        }
        refresh()
    }

    fun move(id: Int, x: Float, y: Float) {
        val old = zoneOf[id] ?: return
        var z = zone(x, y)
        // a thumb on the pad stays on the pad while it slides
        if ((old == LEFT || old == RIGHT) && z != LEFT && z != RIGHT) z = if (x < (leftX + rightX) / 2f) LEFT else RIGHT
        // jump / fire keep their own finger (no accidental re-press)
        if (old == JUMP || old == FIRE) z = old
        if (old == PAUSE || old == OTHER) z = old
        zoneOf[id] = z
        refresh()
    }

    fun up(id: Int) {
        zoneOf.remove(id)
        refresh()
    }

    fun cancelAll() {
        zoneOf.clear()
        keyLeft = false; keyRight = false; keyJump = false; keyFire = false
        refresh()
    }

    fun key(code: Int, down: Boolean) {
        when (code) {
            KEY_LEFT -> keyLeft = down
            KEY_RIGHT -> keyRight = down
            KEY_JUMP -> { if (down && !keyJump) jumpPressed = true; keyJump = down }
            KEY_FIRE -> { if (down && !keyFire) firePressed = true; keyFire = down }
            KEY_PAUSE -> if (down) pausePressed = true
        }
        if (down) anyTap = true
        refresh()
    }

    private fun refresh() {
        left = keyLeft || zoneOf.values.any { it == LEFT }
        right = keyRight || zoneOf.values.any { it == RIGHT }
        jumpHeld = keyJump || zoneOf.values.any { it == JUMP }
        fireHeld = keyFire || zoneOf.values.any { it == FIRE }
    }

    fun clearEdges() {
        jumpPressed = false; firePressed = false; pausePressed = false; anyTap = false
        tapX = -1f; tapY = -1f
    }
}

const val KEY_LEFT = 1
const val KEY_RIGHT = 2
const val KEY_JUMP = 3
const val KEY_FIRE = 4
const val KEY_PAUSE = 5
