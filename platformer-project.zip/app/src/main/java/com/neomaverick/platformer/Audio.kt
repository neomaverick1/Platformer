package com.neomaverick.platformer

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool

/** Sound effects (SoundPool) and looping music (MediaPlayer), both on the media volume. */
class Audio(private val ctx: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(10)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()
    private val ids = HashMap<Int, Int>()
    private val loaded = HashSet<Int>()
    private var music: MediaPlayer? = null
    private var musicRes = 0
    private var paused = false
    var muted = ctx.getSharedPreferences("game", Context.MODE_PRIVATE).getBoolean("muted", false)
        private set

    init {
        pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) loaded.add(id) }
        for (r in intArrayOf(
            R.raw.sfx_jump, R.raw.sfx_djump, R.raw.sfx_land, R.raw.sfx_coin, R.raw.sfx_stomp, R.raw.sfx_hurt,
            R.raw.sfx_bump, R.raw.sfx_appear, R.raw.sfx_powerup, R.raw.sfx_heart, R.raw.sfx_fire, R.raw.sfx_pop,
            R.raw.sfx_break, R.raw.sfx_spring, R.raw.sfx_checkpoint, R.raw.sfx_gem, R.raw.sfx_kick, R.raw.sfx_pause,
            R.raw.sfx_portal, R.raw.jingle_clear, R.raw.jingle_die,
        )) {
            try { ids[r] = pool.load(ctx, r, 1) } catch (e: Exception) { }
        }
    }

    fun play(res: Int, vol: Float = 1f, rate: Float = 1f) {
        if (muted) return
        val id = ids[res] ?: return
        if (id in loaded) pool.play(id, vol, vol, 1, 0, rate.coerceIn(0.5f, 2f))
    }

    /** Start (or keep playing) a looping track. */
    fun music(res: Int, loop: Boolean = true, vol: Float = 0.55f) {
        if (musicRes == res && music != null) return
        stopMusic()
        musicRes = res
        if (muted) return
        try {
            val mp = MediaPlayer.create(ctx, res) ?: return
            mp.isLooping = loop
            mp.setVolume(vol, vol)
            if (!paused) mp.start()
            music = mp
        } catch (e: Exception) { }
    }

    fun stopMusic() {
        try { music?.stop(); music?.release() } catch (e: Exception) { }
        music = null
        musicRes = 0
    }

    fun pause() {
        paused = true
        try { music?.pause() } catch (e: Exception) { }
        pool.autoPause()
    }

    fun resume() {
        paused = false
        try { music?.start() } catch (e: Exception) { }
        pool.autoResume()
    }

    fun setMuted(m: Boolean) {
        muted = m
        ctx.getSharedPreferences("game", Context.MODE_PRIVATE).edit().putBoolean("muted", m).apply()
        if (m) {
            val r = musicRes
            stopMusic()
            musicRes = r
        } else if (musicRes != 0) {
            val r = musicRes
            musicRes = 0
            music(r)
        }
    }

    fun release() {
        stopMusic()
        pool.release()
    }
}
