package com.neomaverick.platformer

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * The hero. Tuned for a tight, forgiving feel: quick acceleration, a little skid when turning,
 * variable jump height (hold for higher), coyote time and a jump buffer, and corner correction
 * so clipping the edge of a block does not stop a jump.
 */
class Hero : Body(12f, 26f) {
    companion object {
        const val MAX_RUN = 112f
        const val ACCEL = 720f
        const val AIR_ACCEL = 540f
        const val TURN = 1500f
        const val FRICTION = 950f
        const val AIR_DRAG = 260f
        const val JUMP_V = 296f
        const val DJUMP_V = 265f
        const val G_HOLD = 600f
        const val G_CUT = 1650f
        const val G_FALL = 1150f
        const val MAX_FALL = 330f
        const val SPRING_V = 520f
        const val STOMP_V = 255f
        const val STOMP_HOLD_V = 320f
        const val FROG_V = 345f
        const val COYOTE = 0.09f
        const val BUFFER = 0.13f
        const val INVULN = 1.6f
    }

    var facing = 1
    var coyote = 0f
    var jumpBuf = 0f
    /** In a jump whose height is cut when the button is let go. */
    var jumping = false
    /** Launched by a spring or a stomp: height is not cut. */
    var launched = false
    var airJumps = 0
    var prevBottom = 0f

    // powers
    var hearts = 3
    var hasFeather = false
    var hasSun = false
    var shield = false
    var starT = 0f

    // timers
    var invuln = 0f
    var knockT = 0f
    var throwT = 0f
    var landT = 0f
    var tuckT = 0f
    var skidding = false
    var runPhase = 0f
    var idleT = 0f
    var t = 0f
    var dead = false
    var deadT = 0f
    var pitDeath = false
    var frozen = false
    var platform: Platform? = null
    val ribbon = Ribbon()

    /** Sprite frame for this moment. */
    fun frame(): Int {
        if (dead) return G.H_HURT
        if (knockT > 0f) return G.H_HURT
        if (throwT > 0f) return if (throwT > 0.1f) G.H_THROW0 else G.H_THROW1
        if (tuckT > 0f) return G.H_TUCK
        if (!onGround) {
            return when {
                vy < -90f -> G.H_JUMP
                vy < 70f -> G.H_PEAK
                else -> if ((t * 8f).toInt() % 2 == 0) G.H_FALL0 else G.H_FALL1
            }
        }
        if (landT > 0f) return G.H_LAND
        if (skidding) return G.H_SKID
        if (abs(vx) > 8f) return G.H_RUN0 + (runPhase.toInt() % 8)
        // idle: a slow breath, and a blink now and then
        val cycle = idleT % 3.6f
        if (cycle in 3.0f..3.14f) return G.H_BLINK
        return G.H_IDLE0 + ((idleT * 2.5f).toInt() % 4)
    }

    fun update(w: World, inp: Input, dt: Float) {
        t += dt
        if (dead) {
            deadT += dt
            if (!pitDeath && deadT > 0.35f) {
                vy = min(vy + 980f * dt, 420f)
                y += vy * dt
            }
            return
        }
        invuln = max(0f, invuln - dt)
        knockT = max(0f, knockT - dt)
        throwT = max(0f, throwT - dt)
        landT = max(0f, landT - dt)
        tuckT = max(0f, tuckT - dt)
        if (starT > 0f) {
            starT -= dt
            if (starT <= 0f) { starT = 0f; w.starEnded() }
        }

        // ride a moving platform
        platform?.let { p ->
            if (onGround) { x += p.dx; y = p.y }
        }

        val dir = if (frozen || knockT > 0f) 0 else (if (inp.right) 1 else 0) - (if (inp.left) 1 else 0)

        // ---------------- horizontal
        skidding = false
        if (dir != 0) {
            val target = dir * MAX_RUN
            val acc = if (onGround) {
                if (vx * dir < 0f && abs(vx) > 30f) { skidding = true; TURN } else ACCEL
            } else AIR_ACCEL
            vx = approach(vx, target, acc * dt)
            facing = dir
            if (skidding && Rnd.chance(0.35f)) w.dust(x - facing * 4f, y, small = true)
        } else if (knockT <= 0f) {
            vx = approach(vx, 0f, (if (onGround) FRICTION else AIR_DRAG) * dt)
        }

        // ---------------- jumping
        if (!frozen && inp.jumpPressed) jumpBuf = BUFFER
        if (onGround) {
            coyote = COYOTE
            airJumps = if (hasFeather) 1 else 0
        } else coyote -= dt
        if (jumpBuf > 0f && knockT <= 0f) {
            if (coyote > 0f) {
                vy = -JUMP_V
                jumping = true; launched = false
                coyote = 0f; jumpBuf = 0f
                onGround = false; platform = null
                w.audio.play(R.raw.sfx_jump, 0.7f)
                w.dust(x, y, small = false)
            } else if (airJumps > 0) {
                airJumps--
                vy = -DJUMP_V
                jumping = true; launched = false
                jumpBuf = 0f
                tuckT = 0.26f
                w.audio.play(R.raw.sfx_djump, 0.75f)
                w.featherBurst(x, y - 6f)
            }
        }
        jumpBuf -= dt

        // ---------------- gravity
        val g = if (vy < 0f) {
            if (launched || (jumping && inp.jumpHeld && !frozen)) G_HOLD else G_CUT
        } else G_FALL
        vy = min(vy + g * dt, MAX_FALL)
        if (vy >= 0f) { jumping = false; launched = false }

        // ---------------- move and collide
        prevBottom = y
        val wasGround = onGround
        val fallSpeed = vy
        w.moveX(this, vx * dt)
        if (hitWall != 0) vx = 0f
        moveVertical(w, vy * dt)
        if (!onGround) platform = null

        // platforms (one-way, from above)
        if (vy >= 0f) {
            for (p in w.platforms) {
                if (right > p.x + 1f && left < p.x + p.w - 1f && prevBottom <= p.prevY + 1.5f && y >= p.y) {
                    y = p.y; vy = 0f; onGround = true; platform = p
                    break
                }
            }
        }
        // springs: land on the plate, or walk onto it
        if (fallSpeed > 0f) {
            for (s in w.springs) {
                val onPlate = abs(x - s.x) < 9f && prevBottom <= s.top + 1.5f && y >= s.top
                val walkOn = onGround && abs(x - s.x) < 6f && abs(y - (s.ty + 1) * TS) < 1f
                if (onPlate || walkOn) {
                    y = s.top
                    vy = -SPRING_V
                    launched = true; jumping = false
                    onGround = false; platform = null
                    s.squash = 0.22f
                    airJumps = if (hasFeather) 1 else 0
                    w.audio.play(R.raw.sfx_spring)
                    w.dust(x, y, small = false)
                    break
                }
            }
        }

        if (onGround && !wasGround) {
            if (fallSpeed > 220f) { landT = 0.09f; w.dust(x, y, small = false); w.audio.play(R.raw.sfx_land, 0.45f) }
            tuckT = 0f
        }

        // ---------------- animation clocks
        if (onGround && abs(vx) > 8f) runPhase += abs(vx) * dt / 6.2f
        if (onGround && abs(vx) <= 8f) idleT += dt else idleT = 0f

        // spikes underfoot
        if (onGround && w.spikesUnder(this)) w.hurtHero(x - w.spikeEscapeDir(this) * 4f, spikes = true)
    }

    /** Vertical move with ceiling bumps and corner correction. */
    private fun moveVertical(w: World, dy: Float) {
        if (dy >= 0f) {
            w.moveY(this, dy, oneWay = true)
            return
        }
        // going up: check the row the head enters
        val newTop = top + dy
        val ty = floor(newTop / TS).toInt()
        val lx = floor((left + 0.01f) / TS).toInt()
        val rx = floor((right - 0.01f) / TS).toInt()
        val sl = w.solidAt(lx, ty)
        val sr = w.solidAt(rx, ty)
        if (sl || sr) {
            // corner correction: slide around a block edge we only clip by a few pixels
            if (sl && !sr && lx != rx) {
                val overlap = (lx + 1) * TS - left
                if (overlap <= 4.5f) {
                    val ox = x
                    w.moveX(this, overlap + 0.01f)
                    if (hitWall == 0) { y += dy; onGround = false; return }
                    x = ox; hitWall = 0
                }
            }
            if (sr && !sl && lx != rx) {
                val overlap = right - rx * TS
                if (overlap <= 4.5f) {
                    val ox = x
                    w.moveX(this, -(overlap + 0.01f))
                    if (hitWall == 0) { y += dy; onGround = false; return }
                    x = ox; hitWall = 0
                }
            }
            // head bump
            y = (ty + 1) * TS + h
            vy = 0f; jumping = false; launched = false
            hitCeil = true
            val hx = floor(x / TS).toInt()
            val bx = if (w.solidAt(hx, ty)) hx else if (sl) lx else rx
            w.bump(bx, ty)
            return
        }
        y += dy
        onGround = false
    }
}
